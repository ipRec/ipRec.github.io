#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<netdb.h>
#include <sys/ioctl.h>
#include <net/if.h>
/**
客户端实现广播
**/
//#define IP_FOUND "IP_FOUND"
#define IP_FOUND_ACK "IP_FOUND_ACK"
#define IFNAME "enp1s8"
//#define MCAST_PORT 9999

//static in_port_t port_find=51146;
//static char *message_ask="who's ipRec";


int main(int argc,char*argv[]){
	int port_find=51146;
	char *serialnumber="17040000";
	char *message_ask="who's ipRec";
	char *message="I'm ipRec ";

	int opt;
	while ((opt = getopt (argc, argv, "p:i:Dh")) != -1){
		switch(opt) {
		case 'p':
			port_find = atoi(optarg);
			break;
		case 'D':
			break;
		case 'i':
			break;
		case 'h':
			printf("ipRec-find -i [interface] -p [port]\n");
			exit(EXIT_SUCCESS);
		default:
			break;
		}
	}
	for(; optind < argc; optind++)
		printf("argument: %s\n",argv[optind]);

	printf("port: %d\n",port_find);

	int ret=-1;
	struct sockaddr_in from_addr;//服务端地址
	int from_len=sizeof(from_addr);
	int count=-1;
	fd_set readfd;//读文件描述符集合
	char buffer[1024];
	struct timeval timeout;
	timeout.tv_sec=2;//超时时间为2秒
	timeout.tv_usec=0;

	int sock=-1;
	sock=socket(AF_INET,SOCK_DGRAM,0);//建立数据报套接字
	if(sock<0){
		printf("HandleIPFound:sock init error\n");
		exit(EXIT_FAILURE);//return;
	}

	//将使用的网络接口名字复制到ifr.ifr_name中，由于不同的网卡接口的广播地址是不一样的，因此指定网卡接口
	struct ifreq ifr;
	strncpy(ifr.ifr_name,IFNAME,strlen(IFNAME));
	//发送命令，获得网络接口的广播地址
	if(ioctl(sock,SIOCGIFBRDADDR,&ifr)==-1){
		perror("ioctl error");
		exit(EXIT_FAILURE);//return;
	}

	//将获得的广播地址复制到broadcast_addr
	int so_broadcast=1;
	struct sockaddr_in broadcast_addr;//广播地址
	memcpy(&broadcast_addr,&ifr.ifr_broadaddr,sizeof(struct sockaddr_in));

	//设置广播端口号
	printf("broadcast IP is:%s\n",inet_ntoa(broadcast_addr.sin_addr));
	broadcast_addr.sin_family=AF_INET;
	broadcast_addr.sin_port=htons(port_find);

	//默认的套接字描述符sock是不支持广播，必须设置套接字描述符以支持广播
	ret=setsockopt(sock,SOL_SOCKET,SO_BROADCAST,&so_broadcast,sizeof(so_broadcast));

	//发送多次广播，看网络上是否有服务器存在
	int times=10;
	int i=0;
	for(i=0;i<times;i++){//一共发送10次广播，每次等待2秒是否有回应
		//广播发送服务器地址请求
		timeout.tv_sec=2;//超时时间为2秒
		timeout.tv_usec=0;
		ret=sendto(sock,message_ask,strlen(message_ask),0,
				(struct sockaddr*)&broadcast_addr,sizeof(broadcast_addr));
		if(ret==-1){
			continue;
		}
		//文件描述符清0
		FD_ZERO(&readfd);
		//将套接字文件描述符加入到文件描述符集合中
		FD_SET(sock,&readfd);
		//select侦听是否有数据到来
		ret=select(sock+1,&readfd,NULL,NULL,&timeout);
		switch(ret){
		case -1:
			break;
		case 0:
			printf("timeout\n");
			break;
		default:
			//接收到数据
			if(FD_ISSET(sock,&readfd)){
				count=recvfrom(sock,buffer,sizeof(buffer)-1,0,
						(struct sockaddr*)&from_addr,&from_len);//from_addr为服务器端地址
				buffer[count]='\0';

				printf("recvmsg is %s\n",buffer);
				if(strstr(buffer,"I'm ipRec")){
					printf("found server IP is:%s\n",inet_ntoa(from_addr.sin_addr));
					//服务器端的发送端口号
					printf("Server Port:%d\n",htons(from_addr.sin_port));
				}
				exit(EXIT_SUCCESS);//return;
			}
			break;
		}
	}
	return 0;
}
