#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>	// opt

/**
广播接收端代码
**/

#define VERSION_MAJOR 0
#define VERSION_MINOR 0
#define VERSION_MICRO 1


int main(int argc,char*argv[]){

	int port_find=51146;
	char *serialnumber="17040000";
	char *message_ask="who's ipRec";
	char *message="I'm ipRec ";

	int opt;
	while ((opt = getopt (argc, argv, "p:s:h")) != -1){
		switch(opt) {
		case 'p':
			port_find = atoi(optarg);
			break;
		case 's':
			memcpy(serialnumber,optarg,8);
			break;
		case 'h':
			printf("ipRec-find -p [port] -s [serial number]\n");
			printf("version: %d.%d.%d\n",VERSION_MAJOR,VERSION_MINOR,VERSION_MICRO);
			exit(EXIT_SUCCESS);
		default:
			break;
		}
	}
	for(; optind < argc; optind++)
		printf("argument: %s\n",argv[optind]);

	printf("ipRec-Find version: %d.%d.%d\n",VERSION_MAJOR,VERSION_MINOR,VERSION_MICRO);
	printf("port: %d\n",port_find);
	printf("serial number: %s\n",serialnumber);

	int ret=-1;
	int sock;
	struct sockaddr_in server_addr;//服务器端地址
	struct sockaddr_in from_addr;//客户端地址
	int from_len=sizeof(struct sockaddr_in);
	int count=-1;
	fd_set readfd;//读文件描述符集合
	char buffer[1024];
	struct timeval timeout;
	timeout.tv_sec=2;
	timeout.tv_usec=0;
	sock=socket(AF_INET,SOCK_DGRAM,0);//建立数据报套接字
	if(sock<0){
		perror("sock");
		exit(EXIT_FAILURE);//return;
	}
	//memset((void*)&server_addr,0,sizeof(struct sockaddr_in));
	server_addr.sin_family=AF_INET;
	server_addr.sin_addr.s_addr=htons(INADDR_ANY);
	server_addr.sin_port=htons(port_find);

	//将地址结构绑定到套接字上./
	ret=bind(sock,(struct sockaddr*)&server_addr,sizeof(server_addr));
	if(ret<0){
		perror("bind");
		exit(EXIT_FAILURE);//return;
	}

	while(1){
		timeout.tv_sec=2;
		timeout.tv_usec=0;
		//文件描述符集合清0
		FD_ZERO(&readfd);
		//将套接字描述符加入到文件描述符集合
		FD_SET(sock,&readfd);
		//select侦听是否有数据到来
		ret=select(/*sock+1*/FD_SETSIZE,&readfd,(fd_set *)0,(fd_set *)0,
				(struct timeval *)&timeout);//侦听是否可读
		//printf("ret=%d\n",ret);
		switch(ret){
		case -1://发生错误
			break;
		case 0://超时
			//printf("timeout\n");
			break;
		default:
			if(FD_ISSET(sock,&readfd)){
				count=recvfrom(sock,buffer,sizeof(buffer),0,
						(struct sockaddr*)&from_addr,&from_len);//接收客户端发送的数据
				buffer[count]='\0';

				//from_addr保存客户端的地址结构
				if(strstr(buffer,message_ask)){
					//响应客户端请求
					//printf("%s\n",buffer);
					//打印客户端的IP地址
					char tmp_sip[256];
					in_port_t tmp_port;
					inet_ntop(AF_INET, &from_addr.sin_addr,tmp_sip,128);
					printf("Client IP is %s\n",tmp_sip);
					//printf("Client IP is %s\n",inet_ntoa(from_addr.sin_addr));
					//打印客户端的端口号
					printf("Client Send Port:%d\n",ntohs(from_addr.sin_port));
					printf("recevie data: %s\n",buffer);
					strcpy(buffer,message);
					strcat(buffer,serialnumber);
					//memcpy(buffer,"I'm ipRec 17010000",strlen("I'm ipRec 17010000")+1);
					count=sendto(sock,buffer,strlen(buffer),0,(struct sockaddr*)&from_addr,from_len);//将数据发送给客户端
				}
			}
			break;
		}
	}
	return 0;
}
