// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifndef _Digi04MkIICommsEngineHostEther_h_Included
#define _Digi04MkIICommsEngineHostEther_h_Included

#include <stdio.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include "Digi04MkIICommsEngineHost.h"

// Run on Host PC
class Digi04MkIICommsEngineHostEther : public Digi04MkIICommsEngineHost
{
public:
	Digi04MkIICommsEngineHostEther(SOCKET *pSoc);
	virtual ~Digi04MkIICommsEngineHostEther();

	bool SendMessage(BYTE *pData, DWORD Length);
	bool ReceiveMessage(BYTE *pData, DWORD &Length);

private:
	SOCKET *m_pSoc;
};


#endif