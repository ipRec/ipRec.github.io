
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Digi04MkIICommsEngineEther.h"

Digi04MkIICommsEngineEther::Digi04MkIICommsEngineEther(SOCKET *pSoc)
{
		m_pSoc = pSoc;
		BYTE Mess[1024];
		DWORD Size=sizeof(Mess);
		while (ReceiveMessage(Mess, Size))
		{
			Size=sizeof(Mess);
#ifdef DIAG
			if (hDiag != NULL) fflush(hDiag);
#endif
		}
}

Digi04MkIICommsEngineEther::~Digi04MkIICommsEngineEther()
{
	// should really do
	// Call WSAAsyncSelect to register for FD_CLOSE notification. 
	// Call shutdown with how=SD_SEND. 
	// When FD_CLOSE received, call recv until zero returned, or SOCKET_ERROR. 
	// Call closesocket. 

	shutdown(*m_pSoc, SD_SEND);
	BYTE Mess[1024];
	int res = recv(*m_pSoc, (char *)Mess, 1024, 0);
	while ((res != SOCKET_ERROR) && (res >0))
	{
		res = recv(*m_pSoc, (char *)Mess, 1024, 0);
	}
	SleepEx(1000, TRUE);
	closesocket(*m_pSoc);
	delete m_pSoc;
}

bool Digi04MkIICommsEngineEther::SendMessage(BYTE *pData, DWORD Length)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "SendMessage: %02x, Length=%d\n", pData[0], Length);
#endif
	int res = send(*m_pSoc, (const char *)pData, Length, 0);
	if (res == SOCKET_ERROR)
	{
		int err = WSAGetLastError();
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "SendMessage: SOCKET_ERROR (%d)\n", err);
#endif
		return false;
	}
	if (res != (int)Length)
	{
		// do something
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "SendMessage: Not all message sent\n");
#endif
	}

	return true;
}


bool Digi04MkIICommsEngineEther::ReceiveMessage(BYTE *pData, DWORD &Length)
{
	// check how much data there is
	int res = recv(*m_pSoc, (char *)pData, Length, MSG_PEEK);
	if (res == SOCKET_ERROR)
	{
		int err = WSAGetLastError();
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: SOCKET_ERROR (%d)\n", err);
#endif
		return false;
	}
	res = recv(*m_pSoc, (char *)pData, res, 0);
	if (res == SOCKET_ERROR)
	{
		int err = WSAGetLastError();
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: SOCKET_ERROR (%d)\n", err);
#endif
		return false;
	}
	if (res == 0)
	{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: No Data\n");
#endif
		return false;
	}
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: %02x, Length=%d\n", pData[0], res);
#endif
	Length = res;
	return true; //DecodeBlock(pData, res);
}
