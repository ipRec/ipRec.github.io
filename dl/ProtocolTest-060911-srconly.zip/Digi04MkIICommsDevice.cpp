
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Digi04MkIICommsDevice.h"

Digi04MkIICommsDevice::Digi04MkIICommsDevice()
{
#ifdef DIAG
	hDiag = fopen("commsdiag.txt", "a+");
#endif
}

Digi04MkIICommsDevice::~Digi04MkIICommsDevice()
{
#ifdef DIAG
	if (hDiag != NULL)
	{
		fclose(hDiag);
		hDiag=NULL;
	}
#endif
}

bool Digi04MkIICommsDevice::DecodeBlock(BYTE *pData, DWORD Length)
{
	if ((pData == NULL) || (Length < 3))
	{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsDevice::DecodeBlock: Invalid block, pData=%p, MessageLen=%d\n", pData, Length);
#endif
		return false;
	}
	int MessageType = pData[0] & 0x3f; 
	int MessageLen = ((pData[0] & 0xC0)<<2) | pData[1];
	BYTE Channel = pData[2] & 0x3f;
	int Direction = (pData[2] & 0x80) >> 7;
	int Set=Direction;
	bool bRes=false;

	switch (MessageType)
	{
	case INITIALIZE:
		bRes = GotInitialize();
		break;
	case CONFIG:
		switch (Channel)
		{
		case FirmwareVersion:
			bRes = GotQueryFwVersion();
			break;
		case FPGAHardwareType:
			bRes = GotQueryFPGAHwType();
			break;
		case FPGAProgramVersion:
			bRes = GotQueryFPGAProgVersion();
			break;
		case FPGAProgramType:
			bRes = GotQueryFPGAProgType();
			break;
		case SerialNumber:
			bRes = GotQuerySerialNumber();
			break;
		case DaughterCards:
			bRes = GotQueryDaughterCards();
			break;
		case RTC:
			if (Set)
			{
				if (MessageLen == 17)
				{
					char szMessage[15];
					strncpy(szMessage, (const char *)&(pData[3]), 14);
					szMessage[14] = '\0';
					bRes = GotSetRTC(szMessage); 
				}
			} else bRes = GotQueryRTC();
			break;
		case MacAddress:
			if (Set) 
			{
				if ((MessageLen == 9) || (MessageLen == 11))
				{
					BYTE MacAddr[8];
					memcpy(MacAddr, &(pData[3]), MessageLen-3);
					bRes = GotSetMACAddress(MacAddr, MessageLen-3); 
				}
			} else bRes = GotQueryMACAddress();
			break;
		case TCPListenPort:
			if (Set) 
			{
				if (MessageLen == 5)
				{
					WORD Port;
					memcpy(&Port, &(pData[3]), sizeof(WORD));
					bRes = GotSetTCPListenPort(Port); 
				}
			} else bRes = GotQueryTCPListenPort();
			break;
		case EthernetStatus:
			if (Set) 
			{
			} else 
			{
				if (MessageLen == 4)
				{
					bRes = GotQueryEthernetStatus(pData[3]);
				}
			}
			break;
		case IPv4Address:
			if (Set)
			{
				if (MessageLen == 8)
				{
					BYTE IP[5];
					memcpy(IP, &(pData[3]), 5);
					bRes = GotSetIPv4Address(IP); 
				}
			} else bRes = GotQueryIPv4Address();
			break;
		case IPv4Gateway:
			if (Set) 
			{
				if (MessageLen == 7)
				{
					BYTE GW[4];
					memcpy(GW, &(pData[3]), 4);
					bRes = GotSetIPv4Gateway(GW); 
				}
			} else bRes = GotQueryIPv4Gateway();
			break;
		case IPv4DNSServer:
			if (Set)
			{
				if (MessageLen == 7)
				{
					BYTE DNS[4];
					memcpy(DNS, &(pData[3]), 4);
					bRes = GotSetIPv4DNSServer(DNS); 
				}
			} else bRes = GotQueryIPv4DNSServer();
			break;
		case IPv6Address:
			if (Set) 
			{
				if (MessageLen == 20)
				{
					BYTE IP[17];
					memcpy(IP, &(pData[3]), 17);
					bRes = GotSetIPv6Address(IP); 
				}
			} else bRes = GotQueryIPv6Address();
			break;
		case IPv6Gateway:
			if (Set) 
			{
				if (MessageLen == 19)
				{
					BYTE IP[16];
					memcpy(IP, &(pData[3]), 16);
					bRes = GotSetIPv6Gateway(IP); 
				}
			} else bRes = GotQueryIPv6Gateway();
			break;
		case IPv6DNSServer:
			if (Set)
			{
				if (MessageLen == 19)
				{
					BYTE IP[16];
					memcpy(IP, &(pData[3]), 16);
					bRes = GotSetIPv6DNSServer(IP); 
				}
			} else bRes = GotQueryIPv6DNSServer();
			break;
		case OperationMode:
			if (Set) 
			{
				if (MessageLen == 4)
				{
					bRes = GotSetOperationMode(pData[3]); 
				}
			} else bRes = GotQueryOperationMode();
			break;
		case DiagnosticLevel:
			if (Set) 
			{
				if (MessageLen == 4)
				{
					bRes = GotSetDiagLevel(pData[3]); 
				}
			} else bRes = GotQueryDiagLevel();
			break;
		case RunningServices:
			if (Set) 
			{
				if (MessageLen == 4)
				{
					bRes = GotSetRunningServices(pData[3]); 
				}
			} else bRes = GotQueryRunningServices();
			break;
		case LCDMessage:
			if (Set) 
			{
				if (MessageLen == 835)
				{
					BYTE Data[832];
					memcpy(Data, &(pData[3]), 832);
					bRes = GotSetLCDMessage(Data); 
				}
			}
			break;
		case EnableLine:
			if (Set)
			{
				if (MessageLen == 5)
				{
					bRes = GotSetLineStatus(pData[3], pData[4]);
				}
			} else 
			{
				if (MessageLen == 4)
				{
					bRes = GotQueryLineStatus(pData[3]);
				}
			}
			break;
		case NoChannels:
			if (Set==0)
			{
				bRes = GotQueryChannels();
			}
			break;
		case XTREncryption:
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szPassword = (char *)malloc(MessageLen-4+1);
					if (szPassword != NULL)
					{
						strncpy(szPassword, (const char *)&(pData[4]), MessageLen-4);
						szPassword[MessageLen-4] = '\0';
						bRes = GotSetXTREncryption(pData[3], szPassword); 
						free(szPassword);
					}
				}
			}
			break;
		case SSLEncryption:
			if (Set) 
			{
				if (MessageLen == 4)
				{
					bRes = GotSetSSLEncryption(pData[3]); 
				}
			}
			break;
		case TCPHosts:
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szHostname = (char *)malloc(MessageLen-4+1);
					if (szHostname != NULL)
					{
						strncpy(szHostname, (const char *)&(pData[4]), MessageLen-4);
						szHostname[MessageLen-4] = '\0';
						bRes = GotSetAllowedHosts(pData[3], szHostname); 
						free(szHostname);
					}
				}
			} else 
			{
				if (MessageLen == 4)
				{
					bRes = GotQueryAllowedHosts(pData[3]);
				}
			}
			break;
		case SMTPServer:
			if (Set) 
			{
				if (MessageLen >= 5)
				{
					char *szHostname = (char *)malloc(MessageLen-5+1);
					if (szHostname != NULL)
					{
						WORD Port;
						memcpy(&Port, &(pData[3]), sizeof(WORD));
						strncpy(szHostname, (const char *)&(pData[5]), MessageLen-5);
						szHostname[MessageLen-5] = '\0';
						bRes = GotSetSMTPServer(Port, szHostname); 
						free(szHostname);
					}
				}
			} else bRes = GotQuerySMTPServer();
			break;
		case SMTPLogin: 
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szLogin = (char *)malloc(MessageLen-3+1);
					if (szLogin != NULL)
					{
						strncpy(szLogin, (const char *)&(pData[3]), MessageLen-3);
						szLogin[MessageLen-3] = '\0';
						bRes = GotSetSMTPLoginName(szLogin); 
						free(szLogin);
					}
				}
			} else bRes = GotQuerySMTPLoginName();
			break;
		case SMTPPassword: 
			if (Set)
			{
				if (MessageLen >= 4)
				{
					char *szPassword = (char *)malloc(MessageLen-3+1);
					if (szPassword != NULL)
					{
						strncpy(szPassword, (const char *)&(pData[3]), MessageLen-3);
						szPassword[MessageLen-3] = '\0';
						bRes = GotSetSMTPLoginPassword(szPassword); 
						free(szPassword);
					}
				}
			} else bRes = GotQuerySMTPLoginPassword();
			break;
		case SMTPDestAddr:
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szAddress = (char *)malloc(MessageLen-4+1);
					if (szAddress != NULL)
					{
						strncpy(szAddress, (const char *)&(pData[4]), MessageLen-4);
						szAddress[MessageLen-4] = '\0';
						bRes = GotSetSMTPAddress(pData[3], szAddress); 
						free(szAddress);
					}
				}
			} else 
			{
				if (MessageLen == 4)
				{
					bRes = GotQuerySMTPAddress(pData[3]);
				}
			}
			break;
		case SNTPHostname:
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szAddress = (char *)malloc(MessageLen-4+1);
					if (szAddress != NULL)
					{
						strncpy(szAddress, (const char *)&(pData[4]), MessageLen-4);
						szAddress[MessageLen-4] = '\0';
						bRes = GotSetSNTPHostname(pData[3], szAddress); 
						free(szAddress);
					}
				}
			} else 
			{
				if (MessageLen == 4)
				{
					bRes = GotQuerySNTPHostname(pData[3]);
				}
			}
			break;
		case SNTPPollInterval:
			if (Set) 
			{
				if (MessageLen == 5)
				{
					WORD Interval;
					memcpy(&Interval, &(pData[3]), sizeof(WORD));
					bRes = GotSetSNTPPollInterval(Interval);
				}
			} else bRes = GotQuerySNTPPollInterval();
			break;
		case MacAddressFilter:
			if (Set) 
			{
				if ((MessageLen == 10) || (MessageLen == 12))
				{
					BYTE MacAddr[8];
					memcpy(MacAddr, &(pData[4]), MessageLen-4);
					bRes = GotSetMACAddressFilter(pData[3], MacAddr, MessageLen-3); 
				}
			} else bRes = GotQueryMACAddressFilter(pData[3]);
			break;
		case SIPPortFilter:
			if (Set) 
			{
				if (MessageLen == 6)
				{
					WORD SIPPort;
					memcpy(&SIPPort, &(pData[4]), sizeof(WORD));
					bRes = GotSetSIPPortFilter(pData[3], SIPPort); 
				}
			} else bRes = GotQuerySIPPortFilter(pData[3]);
			break;
		case SIPIPv4AddressFilter:
			if (Set)
			{
				if (MessageLen == 9)
				{
					BYTE IP[5];
					memcpy(IP, &(pData[4]), 5);
					bRes = GotSetSIPIPv4AddressFilter(pData[3], IP); 
				}
			} else bRes = GotQuerySIPIPv4AddressFilter(pData[3]);
			break;
		case SIPIPv6AddressFilter:
			if (Set) 
			{
				if (MessageLen == 21)
				{
					BYTE IP[17];
					memcpy(IP, &(pData[4]), 17);
					bRes = GotSetSIPIPv6AddressFilter(pData[3], IP); 
				}
			} else bRes = GotQuerySIPIPv6AddressFilter(pData[3]);
			break;
		case VLANFilter:
			if (Set) 
			{
				if (MessageLen == 6)
				{
					WORD VLAN;
					memcpy(&VLAN, &(pData[4]), sizeof(WORD));
					bRes = GotSetVLANFilter(pData[3], VLAN); 
				}
			} else bRes = GotQueryVLANFilter(pData[3]);
			break;
		case SIPURIFilter:
			if (Set) 
			{
				if (MessageLen >= 4)
				{
					char *szSIPURI = (char *)malloc(MessageLen-4+1);
					if (szSIPURI != NULL)
					{
						strncpy(szSIPURI, (const char *)&(pData[4]), MessageLen-4);
						szSIPURI[MessageLen-4] = '\0';
						bRes = GotSetSIPURIFilter(pData[3], szSIPURI); 
						free(szSIPURI);
					}
				}
			} else bRes = GotQuerySIPURIFilter(pData[3]);
			break;
		case RTPPortFilter:
			if (Set) 
			{
				if (MessageLen == 6)
				{
					WORD RTPPort;
					memcpy(&RTPPort, &(pData[4]), sizeof(WORD));
					bRes = GotSetRTPPortFilter(pData[3], RTPPort); 
				}
			} else bRes = GotQueryRTPPortFilter(pData[3]);
			break;
		case RTCPPortFilter:
			if (Set) 
			{
				if (MessageLen == 6)
				{
					WORD RTCPPort;
					memcpy(&RTCPPort, &(pData[4]), sizeof(WORD));
					bRes = GotSetRTCPPortFilter(pData[3], RTCPPort); 
				}
			} else bRes = GotQueryRTCPPortFilter(pData[3]);
			break;
		case RTPIPv4AddressFilter:
			if (Set)
			{
				if (MessageLen == 9)
				{
					BYTE IP[5];
					memcpy(IP, &(pData[4]), 5);
					bRes = GotSetRTPIPv4AddressFilter(pData[3], IP); 
				}
			} else bRes = GotQueryRTPIPv4AddressFilter(pData[3]);
			break;
		case RTPIPv6AddressFilter:
			if (Set) 
			{
				if (MessageLen == 21)
				{
					BYTE IP[17];
					memcpy(IP, &(pData[4]), 17);
					bRes = GotSetRTPIPv6AddressFilter(pData[3], IP); 
				}
			} else bRes = GotQueryRTPIPv6AddressFilter(pData[3]);
			break;
		default:
			break;
		}
		break;
	case FIRMWARE:
		switch (Channel)
		{
			case FirmwareInit:
				if (MessageLen == 7)
				{
					DWORD Len;
					memcpy(&Len, &(pData[3]), sizeof(DWORD));
					bRes = GotSendFirmwareInit(Len);
				}
				break;
			case FirmwareBlock: 
				if (MessageLen == 519)
				{
					DWORD Offset;
					BYTE Data[512];
					memcpy(&Offset, &(pData[3]), sizeof(DWORD));
					memcpy(Data, &(pData[7]), 512);
					bRes = GotSendFirmwareBlock(Offset, Data);
				}
				break;
			case FirmwareChecksum: 
				bRes = GotRequestFwChecksum();
				break;
			case FPGAInit:
				if (MessageLen == 7)
				{
					DWORD Len;
					memcpy(&Len, &(pData[3]), sizeof(DWORD));
					bRes = GotSendFPGAInit(Len);
				}
				break;
			case FPGABlock: 
				if (MessageLen == 519)
				{
					DWORD Offset;
					BYTE Data[512];
					memcpy(&Offset, &(pData[3]), sizeof(DWORD));
					memcpy(Data, &(pData[7]), 512);
					bRes = GotSendFPGABlock(Offset, Data);
				}
				break;
			case FPGAChecksum: 
				bRes = GotRequestFPGAChecksum();
				break;
			case Reboot:
				bRes = GotRequestReboot();
				break;
			default:
				break;
		}
		break;
	case QUERYDCHANCONF:
		bRes = GotQueryDChannelStatus(Channel);
		break;
	case SETDCHANCONF:
		if (MessageLen == 4)
		{
			bRes = GotSetDChannelStatus(Channel, pData[3]);
		}
		break;
	case QUERYBCHANCONF:
		bRes = GotQueryBChannelStatus(Channel);
		break;
	case SETBCHANCONF:
		if (MessageLen == 4)
		{
			bRes = GotSetBChannelStatus(Channel, pData[3]);
		}
		break;
	case SDCARD:
		switch (Channel)
		{
		case SDCopyToCardInit:
			if (MessageLen >= 4)
			{
				char *szFilename = (char *)malloc(MessageLen-3+1);
				if (szFilename != NULL)
				{
					strncpy(szFilename, (const char *)&(pData[3]), MessageLen-3);
					szFilename[MessageLen-3] = '\0';
					bRes = GotCopyFileToSDCard(szFilename); 
					free(szFilename);
				}
			}
			break;
		case SDCopyToCardLength:
			if (MessageLen == 11)
			{
				QWORD Len;
				memcpy(&Len, &(pData[3]), sizeof(QWORD));
				bRes = GotCopyFileToSDCardLen(Len);
			}
			break;
		case SDCopyToCardBlock:
			if (MessageLen == 523)
			{
				QWORD Offset;
				BYTE Data[512];
				memcpy(&Offset, &(pData[3]), sizeof(QWORD));
				memcpy(Data, &(pData[11]), 512);
				bRes = GotCopyFileToSDCardBlock(Offset, Data);
			}
			break;
		case SDCopyFromCardInit:
			if (MessageLen >= 4)
			{
				char *szFilename = (char *)malloc(MessageLen-3+1);
				if (szFilename != NULL)
				{
					strncpy(szFilename, (const char *)&(pData[3]), MessageLen-3);
					szFilename[MessageLen-3] = '\0';
					bRes = GotCopyFileFromSDCard(szFilename); 
					free(szFilename);
				}
			}
			break;
		case SDCopyFromCardBlock:
			if (MessageLen == 4)
			{
				bRes = GotCopyFileFromSDCardComplete(pData[3]);
			}
			break;
		case SDDeleteFile:
			if (MessageLen >= 4)
			{
				char *szFilename = (char *)malloc(MessageLen-3+1);
				if (szFilename != NULL)
				{
					strncpy(szFilename, (const char *)&(pData[3]), MessageLen-3);
					szFilename[MessageLen-3] = '\0';
					bRes = GotDeleteFileFromSDCard(szFilename); 
					free(szFilename);
				}
			}
			break;
		case SDIsCardInserted:
			bRes = GotIsSDCardInserted();
			break;
		case SDFreeSpace:
			bRes = GotQuerySDCardFreeSpace();
			break;
		default:
			break;
		}
		break;
	case BCHANDATA:
		break;
	case DCHANDATA:
		break;
	case DCHANEVENT:
		break;
	case DEBUGDATA:
		break;
	case ERRORMESS:
#ifdef DIAG
		if (hDiag != NULL)
		{
			fprintf(hDiag, "Digi04MkIICommsDevice::DecodeBlock: Error Message\n");
		}
#endif
		break;
	default:
		break;
	}
	if (!bRes)
	{
#ifdef DIAG
		if (hDiag != NULL)
		{
			fprintf(hDiag, "Digi04MkIICommsDevice::DecodeBlock: Error decoding block, MessageLen=%d:\n\t", pData, MessageLen);
			for(int i=0; i<MessageLen; i++)
			{
				fprintf(hDiag, "%02x ", pData[i]);
				if ((i%16)==15)
				{
					fprintf(hDiag, "\n\t");
				}
			}
			fprintf(hDiag, "\n");
		}
#endif
	}

	return bRes;
}