// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifndef _Digi04MkIICommsEngine_h_Included
#define _Digi04MkIICommsEngine_h_Included

#include "Digi04MkIICommsDevice.h"

#define BOOTLOADER_VERSION "01.00"
#define FIRMWARE_VERSION "01.00"
#define FPGA_HW_TYPE "A3P400"
#define FPGA_PROG_VERSION "04.00"
#define FPGA_PROG_TYPE "BRIUK"
#define FAKE_SERIAL_NUMBER "1000000064"
#define FAKE_DCARD_TYPE 4


// Run on hardware
class Digi04MkIICommsEngine : public Digi04MkIICommsDevice
{
public:
	Digi04MkIICommsEngine();
	~Digi04MkIICommsEngine();

	bool GotInitialize(void);

	bool GotQueryFwVersion(void);
	bool GotQueryFPGAHwType(void);
	bool GotQueryFPGAProgVersion(void);
	bool GotQueryFPGAProgType(void);
	bool GotQuerySerialNumber(void);
	bool GotQueryDaughterCards(void);

	bool GotSendFirmwareInit(DWORD Length);
	bool GotSendFirmwareBlock(DWORD Offset, BYTE Data[512]);

	bool GotRequestFwChecksum(void);

	bool GotSendFPGAInit(DWORD Length);
	bool GotSendFPGABlock(DWORD Offset, BYTE Data[512]);

	bool GotRequestFPGAChecksum(void);

	bool GotRequestReboot(void);

	bool GotQueryRTC(void);
	bool GotSetRTC(char *szTime);

	// IP Parameters
	bool GotQueryMACAddress(void);
	bool GotSetMACAddress(BYTE MacAddress[8], int Length);
	bool GotQueryTCPListenPort(void);
	bool GotSetTCPListenPort(WORD Port);
	bool GotQueryEthernetStatus(BYTE Port);

	// IPv4 Parameters
	bool GotQueryIPv4Address(void);
	bool GotSetIPv4Address(BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	bool GotQueryIPv4Gateway(void);
	bool GotSetIPv4Gateway(BYTE IPAddr[4]); 
	bool GotQueryIPv4DNSServer(void);
	bool GotSetIPv4DNSServer(BYTE IPAddr[4]); 

	// IPv6 Parameters
	bool GotQueryIPv6Address(void);
	bool GotSetIPv6Address(BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)
	bool GotQueryIPv6Gateway(void);
	bool GotSetIPv6Gateway(BYTE IPAddr[16]); 
	bool GotQueryIPv6DNSServer(void);
	bool GotSetIPv6DNSServer(BYTE IPAddr[16]); 

	bool GotQueryOperationMode(void);
	bool GotSetOperationMode(BYTE Flag);

	bool GotQueryDiagLevel(void);
	bool GotSetDiagLevel(BYTE Flag);

	bool GotQueryRunningServices(void);
	bool GotSetRunningServices(BYTE Services);

	bool GotQueryDChannelStatus(BYTE Channel);
	bool GotSetDChannelStatus(BYTE Channel, BYTE Status);

	bool GotQueryBChannelStatus(BYTE Channel);
	bool GotSetBChannelStatus(BYTE Channel, BYTE Status);

	bool GotSetLCDMessage(BYTE Data[832]);

	bool GotQueryLineStatus(BYTE Line);
	bool GotSetLineStatus(BYTE Line, BYTE Flag);

	// SD Card Functions
	bool GotCopyFileToSDCard(char *szFilename);
	bool GotCopyFileToSDCardLen(QWORD Length);
	bool GotCopyFileToSDCardBlock(QWORD Offset, BYTE Data[512]);

	bool GotCopyFileFromSDCard(char *szFilename);
	bool GotCopyFileFromSDCardComplete(BYTE Flag);

	bool GotDeleteFileFromSDCard(char *szFilename);
	bool GotIsSDCardInserted(void);
	bool GotQuerySDCardFreeSpace(void);

	bool GotQueryChannels(void);

	// Security Options
	bool GotSetXTREncryption(BYTE Enable, char *szPassphrase);
	bool GotSetSSLEncryption(BYTE Enable);
	bool GotQueryAllowedHosts(BYTE Host);
	bool GotSetAllowedHosts(BYTE Host, char *szHostname);

	// SMTP
	bool GotQuerySMTPServer(void);
	bool GotSetSMTPServer(WORD ServerPort, char *szServerName);
	bool GotQuerySMTPLoginName(void);
	bool GotSetSMTPLoginName(char *szLoginName);
	bool GotQuerySMTPLoginPassword(void);
	bool GotSetSMTPLoginPassword(char *szPassword);
	bool GotQuerySMTPAddress(BYTE AddrIndex);
	bool GotSetSMTPAddress(BYTE AddrIndex, char *szEmailAddress);

	// SNTP
	bool GotQuerySNTPHostname(BYTE AddressIndex);
	bool GotSetSNTPHostname(BYTE AddressIndex, char *szHostname);
	bool GotQuerySNTPPollInterval(void);
	bool GotSetSNTPPollInterval(WORD Interval);

	// IPTAP Specific Parameters
	bool GotQueryMACAddressFilter(BYTE Port);
	bool GotSetMACAddressFilter(BYTE Port, BYTE MacAddress[8], int Length);
	bool GotQuerySIPPortFilter(BYTE Port);
	bool GotSetSIPPortFilter(BYTE Port, WORD SIPPort);
	bool GotQuerySIPIPv4AddressFilter(BYTE Port);
	bool GotSetSIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	bool GotQuerySIPIPv6AddressFilter(BYTE Port);
	bool GotSetSIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)
	bool GotQueryVLANFilter(BYTE Port);
	bool GotSetVLANFilter(BYTE Port, WORD VLAN);
	bool GotQuerySIPURIFilter(BYTE Port);
	bool GotSetSIPURIFilter(BYTE Port, char *szSIPURI);
	bool GotQueryRTPPortFilter(BYTE Port);
	bool GotSetRTPPortFilter(BYTE Port, WORD RTPPort);
	bool GotQueryRTCPPortFilter(BYTE Port);
	bool GotSetRTCPPortFilter(BYTE Port, WORD RTCPPort);
	bool GotQueryRTPIPv4AddressFilter(BYTE Port);
	bool GotSetRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	bool GotQueryRTPIPv6AddressFilter(BYTE Port);
	bool GotSetRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)

	bool EncodeMessage(int MessageType, int Channel, int Dir, BYTE *pData, int Length);

private:
	DWORD m_FirmwareLength, m_FPGALength;
	BYTE *m_pFirmwareImage, *m_pFPGAImage;
	DWORD m_FirmwareChecksum, m_FPGAChecksum;

	BYTE m_MACAddress[8];
	WORD m_TCPListenPort;

	BYTE m_TCPIPv4Address[5];
	BYTE m_TCPIPv4Gateway[4];
	BYTE m_TCPIPv4DNSAddress[4];

	BYTE m_TCPIPv6Address[17];
	BYTE m_TCPIPv6Gateway[16];
	BYTE m_TCPIPv6DNSAddress[16];

	BYTE m_OperationsMode;
	BYTE m_DiagLevel;
	BYTE m_Services;

	BYTE m_DChannelStatus[64];
	BYTE m_BChannelStatus[64];
	BYTE m_LCDMessage[832];
	BYTE m_LineEnabled[2];

	char m_szFromFilename[260];
	QWORD m_FromFileLen, m_FromOffset;

	char m_szToFilename[260];
	QWORD m_ToFileLen;

	BYTE m_nChannels;
	
	char *m_szTCPHost[3];

	WORD m_ServerPort;
	char m_szSMTPServer[256];
	char m_szSMTPLogin[256];
	char m_szSMTPPasswd[256];
	char *m_szSMTPDestAddr[3];

	char *m_szSNTPHostname[3];
	WORD m_SNTPInterval;

	BYTE m_MACAddressFilter[8][8];

	WORD m_SIPPortFilter[8];

	BYTE m_SIPIPv4AddressFilter[8][5];

	BYTE m_SIPIPv6AddressFilter[8][17];

	WORD m_VLANFilter[8];

	char m_szSIPURIFilter[8][256];

	WORD m_RTPPortFilter[8];
	WORD m_RTCPPortFilter[8];

	BYTE m_RTPIPv4AddressFilter[8][5];

	BYTE m_RTPIPv6AddressFilter[8][17];
};

#endif