// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifndef _Digi04MkIICommsEngineHostUSB_h_Included
#define _Digi04MkIICommsEngineHostUSB_h_Included

#include <stdio.h>
#include <string.h>
#include <string>
#include "usb.h"

#include "Digi04MkIICommsEngineHost.h"

#define VID 0x075f
#ifdef IPTAP
// IPTap
#define IPTAP_PID 0x1008 
#define IPTAP_ID_STR "\\\\?\\USB#VID_075F&PID_1008"
#else
// Digi04 mkII
#define DIGI04MKII_PID 0x100A 
#define DIGI04MKII_ID_STR "\\\\?\\USB#VID_075F&PID_100A"
#endif

#define CONFIGURATION 1
#define INTFACE 0

#define INT_EP_OUT 1
#define BULK_EP_OUT 2
#define ISO_EP_OUT 3
#define INT_EP_IN 0x84
#define BULK_EP_IN 0x85
#define ISO_EP_IN 0x86

#define ERRNOTFOUND -5
#define ERRTIMEOUT -116

#define BUFSIZE 2048
#define TIMEOUT 1000
#define INTTIMEOUT 1

#define NBUFFERS 2

// Run on Host PC
class Digi04MkIICommsEngineHostUSB : public Digi04MkIICommsEngineHost
{
public:
	Digi04MkIICommsEngineHostUSB(struct usb_device *pDev);
	virtual ~Digi04MkIICommsEngineHostUSB();

	bool SendMessage(BYTE *pData, DWORD Length);
	bool ReceiveMessage(BYTE *pData, DWORD &Length);
	bool ReceiveIntMessage(BYTE *pData, DWORD &Length);

	void ExitThread(void);
	bool HasExited(void);

	std::string m_szFilename;
	
private:	
	usb_dev_handle *m_pDev;
	BYTE m_IntReadBuffer[NBUFFERS][BUFSIZE];
	BYTE m_ReadBuffer[NBUFFERS][BUFSIZE];
	BYTE m_WriteBuffer[2][BUFSIZE];
	void *m_IntReadContext[NBUFFERS];
	void *m_ReadContext[NBUFFERS];
	void *m_WriteContext[2];
	int m_WriteCont, m_ReadCont, m_IntReadCont;
	HANDLE m_hStopEvent;
};


#endif