#include <WinSock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#define WIN32_LEAN_AND_MEAN
//#include <windows.h>

#include "Digi04MkIICommsEngineHost.h"
#include "UDPPacketFilter.h"

Digi04MkIICommsEngineHost::Digi04MkIICommsEngineHost()
{

	bFirstPacket=true;
	InitialPacket, ThisPacket;
	LastBFlag=0;
	LastDFlag=0;
	BPos=0, DPos=0;
	m_RebootReason = 255;
	m_szFirmwareVersion[0] = '\0';
	m_szSerialNo[0] = '\0';
	m_nChannels = 0;
	m_bEnabled = false;
}

Digi04MkIICommsEngineHost::~Digi04MkIICommsEngineHost()
{
}


bool Digi04MkIICommsEngineHost::GotInitialize(BYTE RebootReason, char *szBootLoaderVersion)
{
	m_RebootReason = RebootReason;
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotInitialize, Reboot Reason=%d, szBootLoaderVersion='%s'\n", RebootReason, szBootLoaderVersion);
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryFwVersion(char *szFirmwareVersion)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryFwVersion, szFirmwareVersion='%s'\n", szFirmwareVersion);
#endif
	strncpy(m_szFirmwareVersion, szFirmwareVersion, 5);
	m_szFirmwareVersion[5] = '\0';
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryFPGAHwType(char *szFPGAHwType)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryFPGAHwType, szFPGAHwType='%s'\n", szFPGAHwType);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryFPGAProgVersion(char *szFPGAProgVersion)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryFPGAProgVersion, szFPGAProgVersion='%s'\n", szFPGAProgVersion);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryFPGAProgType(char *szFPGAProgType)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryFPGAProgType, szFPGAProgType='%s'\n", szFPGAProgType);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySerialNumber(char *szSerialNumber)
{
	strncpy(m_szSerialNo, szSerialNumber, 10);
	m_szSerialNo[10] = '\0';
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySerialNumber, szSerialNumber='%s'\n", szSerialNumber);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryDaughterCards(BYTE DaughterCards[4])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryDaughterCards = [%d, %d, %d, %d]\n", DaughterCards[0], DaughterCards[1], DaughterCards[2], DaughterCards[3]);
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotSendFirmwareInit()
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFirmwareInit\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSendFirmwareBlock(BYTE Flag)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFirmwareBlock %s\n", (Flag==1)?"Ok":"Resend");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSendFirmwareComplete(BYTE Flag)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFirmwareComplete %s\n", (Flag==0)?"Complete":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotRequestFwChecksum(DWORD Checksum)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotRequestFwChecksum=0x%04x\n", Checksum);
		printf("Digi04MkIICommsEngineHost::GotRequestFwChecksum=0x%04x\n", Checksum);
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotSendFPGAInit(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFPGAInit\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSendFPGABlock(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFPGABlock %s\n", (Flag==1)?"Ok":"Resend");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSendFPGAComplete(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSendFPGAComplete %s\n", (Flag==0)?"Complete":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotRequestFPGAChecksum(DWORD Checksum)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotRequestFPGAChecksum=0x%04x\n", Checksum);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotReadNVRAMInit(DWORD Checksum)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotReadNVRAMInit Checksum=0x%04x\n", Checksum);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotReadNVRAMBlock(DWORD Offset, BYTE *pData, int nBytes)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotReadNVRAMBlock Offset=0x%04x, nBytes=%d\n", Offset, nBytes);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotWriteNVRAMInit(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotWriteNVRAMInit\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotWriteNVRAMBlock(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotWriteNVRAMBlock Flag=%d\n", Flag);
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotWriteNVRAMComplete(BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotWriteNVRAMComplete Status=%d\n", Status);
#endif
	return true;
}

/*
bool Digi04MkIICommsEngineHost::GotRequestReboot(BYTE Reason)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotRequestReboot, Reason=%d\n", Reason);
#endif
	return true;
} */


bool Digi04MkIICommsEngineHost::GotQueryRTC(char *szTime)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRTC\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRTC(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRTC=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


	// IP Parameters
bool Digi04MkIICommsEngineHost::GotQueryMACAddress(BYTE MacAddress[8], int Length)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryMACAddress\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetMACAddress(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetMACAddress=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryTCPListenPort(WORD Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryTCPListenPort\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetTCPListenPort(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetTCPListenPort=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryEthernetStatus(BYTE Port, BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryEthernetStatus Port=%d, Status=%d\n", Port, Status);
#endif
	return true;
}


	// IPv4 Parameters
bool Digi04MkIICommsEngineHost::GotQueryIPv4Address(BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv4Address\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv4Address(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv4Address=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 
bool Digi04MkIICommsEngineHost::GotQueryIPv4Gateway(BYTE IPAddr[4])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv4Gateway\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv4Gateway(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv4Gateway=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 
bool Digi04MkIICommsEngineHost::GotQueryIPv4DNSServer(BYTE IPAddr[4])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv4DNSServer\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv4DNSServer(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv4DNSServer=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 

	// IPv6 Parameters
bool Digi04MkIICommsEngineHost::GotQueryIPv6Address(BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv6Address\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv6Address(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv6Address=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 
bool Digi04MkIICommsEngineHost::GotQueryIPv6Gateway(BYTE IPAddr[16])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv6Gateway\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv6Gateway(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv6Gateway=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 
bool Digi04MkIICommsEngineHost::GotQueryIPv6DNSServer(BYTE IPAddr[16])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryIPv6DNSServer\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetIPv6DNSServer(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetIPv6DNSServer=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 

bool Digi04MkIICommsEngineHost::GotQueryOperationMode(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryOperationMode\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetOperationMode(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetOperationMode=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryDiagLevel(BYTE Level)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryDiagLevel\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetDiagLevel(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetDiagLevel=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryRunningServices(BYTE Services)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRunningServices\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRunningServices(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRunningServices=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryDChannelStatus(BYTE Channel, BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryDChannelStatus\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetDChannelStatus(BYTE Channel, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetDChannelStatus=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryBChannelStatus(BYTE Channel, BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryBChannelStatus\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetBChannelStatus(BYTE Channel, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetBChannelStatus=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotSetLCDMessage(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetLCDMessage=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryLineStatus(BYTE Enabled)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryLineStatus\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetLineStatus(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetLineStatus=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


	// SD Card Functions
bool Digi04MkIICommsEngineHost::GotCopyFileToSDCard(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileToSDCard\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotCopyFileToSDCardLen(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileToSDCardLen\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotCopyFileToSDCardBlock(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileToSDCardBlock=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotCopyFileToSDCardComplete(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileToSDCardComplete=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotCopyFileFromSDCard(BYTE Flag, QWORD MessageLen)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileFromSDCard\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotCopyFileFromSDCardBlock(QWORD Offset, BYTE Data[512])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotCopyFileFromSDCardBlock\n");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotDeleteFileFromSDCard(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotDeleteFileFromSDCard=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotIsSDCardInserted(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotIsSDCardInserted\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySDCardFreeSpace(QWORD FreeSpace)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySDCardFreeSpace\n");
#endif
	return true;
}

extern CUDPPacketFilter *pPacketFilter;


bool Digi04MkIICommsEngineHost::GotBChannelData(BYTE Channel, WORD MessageLen, BYTE *pData, int Extended)
{
#ifdef DIAG
		if (hDiag != NULL)
		{
			if (LastBFlag==0)
			{
				ThisPacket=clock();
				double diff=0.0;
				if (bFirstPacket)
				{
					InitialPacket=ThisPacket;
					bFirstPacket=false;
				} else
				{
					diff =(ThisPacket-InitialPacket)/(double)(CLOCKS_PER_SEC);
				}
				fprintf(hDiag, "Digi04MkIICommsEngineHost::GotBChannelData Time=%.3f\n", diff);	
			}
		}
#endif
	//printf("BChannel (%d bytes)\n", MessageLen);
	if (MessageLen > 0)
	{
#ifdef DIAG
		if (hDiag != NULL)
		{
			if (LastBFlag==0)
			{
			fprintf(hDiag, "Digi04MkIICommsHost::GotBChannelData: MessageLen=%d Src=%d.%d.%d.%d:%d Dst=%d.%d.%d.%d:%d\n\t", MessageLen,
				(unsigned int)pData[26], (unsigned int)pData[27], (unsigned int)pData[28], (unsigned int)pData[29], (((unsigned int)pData[34])<<8)+pData[35],
				(unsigned int)pData[30], (unsigned int)pData[31], (unsigned int)pData[32], (unsigned int)pData[33], (((unsigned int)pData[36])<<8)+pData[37]);
			
			/*printf("Digi04MkIICommsHost::GotBChannelData: MessageLen=%d Src=%d.%d.%d.%d:%d Dst=%d.%d.%d.%d:%d\n\t", MessageLen,
				(unsigned int)pData[26], (unsigned int)pData[27], (unsigned int)pData[28], (unsigned int)pData[29], (((unsigned int)pData[34])<<8)+pData[35],
				(unsigned int)pData[30], (unsigned int)pData[31], (unsigned int)pData[32], (unsigned int)pData[33], (((unsigned int)pData[36])<<8)+pData[37]);*/
			} else
			{
				fprintf(hDiag, "Digi04MkIICommsHost::GotBChannelData: MessageLen=%d\n", MessageLen);
				//printf("Digi04MkIICommsHost::GotBChannelData: MessageLen=%d\n", MessageLen);
			}
			/*for(int i=0; i<MessageLen; i++)
			{
				fprintf(hDiag, "%02x ", pData[i]);
				if ((i%16)==15)
				{
					fprintf(hDiag, "\n\t");
				}
			}
			fprintf(hDiag, "\n");*/
		}
#endif
		if (LastBFlag == 0)
		{
			
		
			/* Swap src/dst ip and ports */
			int version = (pData[14] & 0xf0) >> 4;
			int hdrlen = (pData[14] & 0x0f);
			DWORD srcip, dstip;
			WORD srcport, dstport;
			BYTE srcmac[6], dstmac[6];

			// swap src/dst mac
			memcpy(&srcmac, &(pData[6]), 6);
			memcpy(&dstmac, &(pData[0]), 6);

			memcpy(&(pData[6]), &dstmac, 6);
			memcpy(&(pData[0]), &srcmac, 6);

			memcpy(&srcip, &(pData[12+14]), sizeof(DWORD));
			memcpy(&dstip, &(pData[16+14]), sizeof(DWORD));

			memcpy(&(pData[12+14]), &dstip, sizeof(DWORD));
			memcpy(&(pData[16+14]), &srcip, sizeof(DWORD));

			memcpy(&srcport, &(pData[hdrlen*4+14]), sizeof(WORD));
			memcpy(&dstport, &(pData[hdrlen*4+2+14]), sizeof(WORD));

			memcpy(&(pData[hdrlen*4+14]), &dstport, sizeof(WORD));
			memcpy(&(pData[hdrlen*4+2+14]), &srcport, sizeof(WORD));
		}

		memcpy(&(BData[BPos]), pData, MessageLen);
		BPos += MessageLen;
		LastBFlag = Extended;
		
		if (Extended == 0)
		{
			BPos=0;
			if ((pPacketFilter != NULL) && (m_bEnabled)) CUDPPacketFilter::PcapHandler((u_char *)pPacketFilter, NULL, BData);
		}
	}
	return true;
}

bool Digi04MkIICommsEngineHost::GotDChannelData(BYTE Channel, WORD MessageLen, BYTE *pData, int Extended)
{
#ifdef DIAG
		if (hDiag != NULL)
		{
			fprintf(hDiag, "DChannel (%d bytes) Extended=%d, LastDFlag=%d, DPos=%d\n", MessageLen, Extended, LastDFlag, DPos);
			if (LastDFlag == 0)
			{
				ThisPacket=clock();
				double diff=0.0;
				if (bFirstPacket)
				{
					InitialPacket=ThisPacket;
					bFirstPacket=false;
				} else
				{
					diff =(ThisPacket-InitialPacket)/(double)(CLOCKS_PER_SEC);
				}
				fprintf(hDiag, "Digi04MkIICommsEngineHost::GotDChannelData Time=%.3f\n", diff);	
			}	
		}
#endif
	
	if (MessageLen > 0)
	{
#ifdef DIAG
		if (hDiag != NULL)
		{
			if (LastDFlag == 0)
			{
				char *pos = strchr((char *)&(pData[42]), 0x0d);
				if (pos != NULL) *pos = '\0';
				fprintf(hDiag, "Digi04MkIICommsHost::GotDChannelData: MessageLen=%d Src=%d.%d.%d.%d:%d Dst=%d.%d.%d.%d:%d\n\t'%s'\n", MessageLen,
					(unsigned int)pData[26], (unsigned int)pData[27], (unsigned int)pData[28], (unsigned int)pData[29], (((unsigned int)pData[34])<<8)+pData[35],
					(unsigned int)pData[30], (unsigned int)pData[31], (unsigned int)pData[32], (unsigned int)pData[33], (((unsigned int)pData[36])<<8)+pData[37],
					(pos == NULL)?"NULL":(char *)&(pData[42])); 
				if (pos != NULL)  *pos = 0x0d;
				/*printf("Digi04MkIICommsHost::GotDChannelData: MessageLen=%d Src=%d.%d.%d.%d:%d Dst=%d.%d.%d.%d:%d\n\t", MessageLen,
					(unsigned int)pData[26], (unsigned int)pData[27], (unsigned int)pData[28], (unsigned int)pData[29], (((unsigned int)pData[34])<<8)+pData[35],
					(unsigned int)pData[30], (unsigned int)pData[31], (unsigned int)pData[32], (unsigned int)pData[33], (((unsigned int)pData[36])<<8)+pData[37]);*/
			} else
			{
				fprintf(hDiag, "Digi04MkIICommsHost::GotDChannelData: MessageLen=%d\n", MessageLen);
				//printf("Digi04MkIICommsHost::GotDChannelData: MessageLen=%d\n", MessageLen);
			}
			/*for(int i=0; i<MessageLen; i++)
			{
				fprintf(hDiag, "%02x ", pData[i]);
				if ((i%16)==15)
				{
					fprintf(hDiag, "\n\t");
				}
			}
			fprintf(hDiag, "\n");*/
		}
#endif
		if (LastDFlag == 0)
		{
			/* Swap src/dst ip and ports */
			int version = (pData[14] & 0xf0) >> 4;
			int hdrlen = (pData[14] & 0x0f);
			DWORD srcip, dstip;
			WORD srcport, dstport;
			BYTE srcmac[6], dstmac[6];

			// swap src/dst mac
			memcpy(&srcmac, &(pData[6]), 6);
			memcpy(&dstmac, &(pData[0]), 6);

			memcpy(&(pData[6]), &dstmac, 6);
			memcpy(&(pData[0]), &srcmac, 6);

			memcpy(&srcip, &(pData[12+14]), sizeof(DWORD));
			memcpy(&dstip, &(pData[16+14]), sizeof(DWORD));

			memcpy(&(pData[12+14]), &dstip, sizeof(DWORD));
			memcpy(&(pData[16+14]), &srcip, sizeof(DWORD));

			memcpy(&srcport, &(pData[hdrlen*4+14]), sizeof(WORD));
			memcpy(&dstport, &(pData[hdrlen*4+2+14]), sizeof(WORD));

			memcpy(&(pData[hdrlen*4+14]), &dstport, sizeof(WORD));
			memcpy(&(pData[hdrlen*4+2+14]), &srcport, sizeof(WORD));
		}

		memcpy(&(DData[DPos]), pData, MessageLen);
		DPos += MessageLen;
		LastDFlag = Extended;

		if (Extended == 0)
		{
#ifdef DIAG
			if (hDiag != NULL)
			{
				fprintf(hDiag, "Digi04MkIICommsEngineHost::GotDChannelData Processing Packet, Len = %d\n", DPos);
			}
#endif
			DPos = 0;
			if ((pPacketFilter != NULL) && (m_bEnabled)) CUDPPacketFilter::PcapHandler((u_char *)pPacketFilter, NULL, DData);
			
		}

		
	}
	return true;
}

bool Digi04MkIICommsEngineHost::GotDChannelEvent(BYTE Channel, BYTE Event, char *szInfo)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotDChannelEvent\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotDebugData(BYTE Channel, WORD MessageLen, BYTE *pData)
{
#ifdef DIAG
		if (hDiag != NULL)
		{
			fprintf(hDiag, "Digi04MkIICommsEngineHost::GotDebugData\n");
			//fprintf(hDiag, "Digi04MkIICommsHost::GotDebugData: MessageLen=%d, Level=0x%02x\n", MessageLen, pData[0]);
			//printf("Digi04MkIICommsHost::GotDebugData: MessageLen=%d, Level=0x%02x\n", MessageLen, pData[0]);
			pData[MessageLen] = '\0';
			//fprintf(hDiag, "'%s'\n",&(pData[1])); 
			//printf("'%s'\n",&(pData[1])); 
			
			/*for(int i=0; i<MessageLen; i++)
			{
				fprintf(hDiag, "%02x ", pData[i]);
				printf("%02x ", pData[i]);
				if ((i%16)==15)
				{
					fprintf(hDiag, "\n\t");
					printf("\n\t");
				}
			}
			fprintf(hDiag, "\n");
			printf("\n");*/
		}
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryChannels(BYTE nChannels)
{
		m_nChannels = nChannels;
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryChannels=%d\n", nChannels);
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotSetXTREncryption(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetXTREncryption=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSSLEncryption(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSSLEncryption=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryAllowedHosts(char *szHostname)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryAllowedHosts\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetAllowedHosts(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetAllowedHosts=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


	// SMTP
bool Digi04MkIICommsEngineHost::GotQuerySMTPServer(WORD ServerPort, char *szServerName)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySMTPServer\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSMTPServer(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSMTPServer=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySMTPLoginName(char *szLoginName)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySMTPLoginName\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSMTPLoginName(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSMTPLoginName=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySMTPLoginPassword(char *szPassword)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySMTPLoginPassword\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSMTPLoginPassword(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSMTPLoginPassword=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySMTPAddress(char *szAddress)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySMTPAddress\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSMTPAddress(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSMTPAddress=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

	// SNTP
bool Digi04MkIICommsEngineHost::GotQuerySNTPHostname(char *szHostname)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySNTPHostname\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSNTPHostname(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSNTPHostname=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySNTPPollInterval(WORD Interval)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySNTPPollInterval\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSNTPPollInterval(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSNTPPollInterval=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

// IPTap Specific Parameters
bool Digi04MkIICommsEngineHost::GotQueryMACAddressFilter(BYTE Port, BYTE MacAddress[8], int Length)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryMACAddressFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetMACAddressFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetMACAddressFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySIPPortFilter(BYTE Port, WORD SIPPort)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySIPPortFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSIPPortFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSIPPortFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySIPIPv4AddressFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSIPIPv4AddressFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSIPIPv4AddressFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySIPIPv6AddressFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSIPIPv6AddressFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSIPIPv6AddressFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryVLANFilter(BYTE Port, WORD VLAN)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryVLANFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetVLANFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetVLANFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQuerySIPURIFilter(BYTE Port, char *szSIPURI)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQuerySIPURIFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetSIPURIFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetSIPURIFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryRTPPortFilter(BYTE Port, WORD RTPPort)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRTPPortFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRTPPortFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRTPPortFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryRTCPPortFilter(BYTE Port, WORD RTCPPort)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRTCPPortFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRTCPPortFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRTCPPortFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}


bool Digi04MkIICommsEngineHost::GotQueryRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRTPIPv4AddressFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRTPIPv4AddressFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRTPIPv4AddressFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotQueryRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotQueryRTPIPv6AddressFilter\n");
#endif
	return true;
}

bool Digi04MkIICommsEngineHost::GotSetRTPIPv6AddressFilter(BYTE Port, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHost::GotSetRTPIPv6AddressFilter=%s\n", (Flag==1)?"OK":"Error");
#endif
	return true;
}
 

bool Digi04MkIICommsEngineHost::EncodeMessage(int MessageType, int Channel, int Dir, BYTE *pData, int Length)
{
	pData[0] = (BYTE)((MessageType & 0x3f) | ((Length & 0x300) >> 2));
	pData[1] = (Length & 0xff);
	pData[2] = (Channel & 0x3f) | ((Dir & 1) << 7);
	return true; //SendMessage(pData, Length);
}

char * Digi04MkIICommsEngineHost::GetFirmwareVersion(void)
{
	return m_szFirmwareVersion;
}