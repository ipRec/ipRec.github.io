
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Digi04MkIICommsEngine.h"



Digi04MkIICommsEngine::Digi04MkIICommsEngine()
{
	m_FirmwareLength = 0;
	m_pFirmwareImage = NULL;
	m_FirmwareChecksum = 0;
	m_FPGALength = 0;
	m_pFPGAImage = NULL;
	m_FPGAChecksum = 0;

	m_MACAddress[0] = 0x00; 
	m_MACAddress[1] = 0x03; 
	m_MACAddress[2] = 0x0d; 
	m_MACAddress[3] = 0xf3; 
	m_MACAddress[4] = 0xd0; 
	m_MACAddress[5] = 0xbc; 

	m_TCPListenPort = 51148;

	m_TCPIPv4Address[0] = 192;
	m_TCPIPv4Address[1] = 168;
	m_TCPIPv4Address[2] = 0;
	m_TCPIPv4Address[3] = 2;
	m_TCPIPv4Address[4] = 24;

	m_TCPIPv4Gateway[0] = 192;
	m_TCPIPv4Gateway[1] = 168;
	m_TCPIPv4Gateway[2] = 0;
	m_TCPIPv4Gateway[3] = 1;

	m_TCPIPv4DNSAddress[0] = 192;
	m_TCPIPv4DNSAddress[1] = 168;
	m_TCPIPv4DNSAddress[2] = 0;
	m_TCPIPv4DNSAddress[3] = 1;

	memset(m_TCPIPv6Address, 0, 17);
	memset(m_TCPIPv6Gateway, 0, 16);
	memset(m_TCPIPv6DNSAddress, 0, 16);

	m_OperationsMode = 0;
	m_DiagLevel = 0;
	m_Services = 0;

	memset(m_DChannelStatus, 5, sizeof(m_DChannelStatus));
	memset(m_BChannelStatus, 7, sizeof(m_BChannelStatus));

	memset(m_LCDMessage, 0, sizeof(m_LCDMessage));

	m_LineEnabled[0] = 1;
	m_LineEnabled[1] = 1;

	m_szFromFilename[0] = '\0';
	m_FromFileLen = 0;

	m_szToFilename[0] = '\0';
	m_ToFileLen = 0;

	m_nChannels = 4; // supports 4 channels

	m_szTCPHost[0] = NULL;
	m_szTCPHost[1] = NULL;
	m_szTCPHost[2] = NULL;

	m_ServerPort=25;
	m_szSMTPServer[0] = '\0';;
	m_szSMTPLogin[0] = '\0';
	m_szSMTPPasswd[0] = '\0';
	m_szSMTPDestAddr[0] = NULL;
	m_szSMTPDestAddr[1] = NULL;
	m_szSMTPDestAddr[2] = NULL;

	m_szSNTPHostname[0] = NULL;
	m_szSNTPHostname[1] = NULL;
	m_szSNTPHostname[2] = NULL;
	m_SNTPInterval = 36003;

	memset(m_MACAddressFilter, 0xff, sizeof(m_MACAddressFilter)); 

	memset(m_SIPPortFilter, 0xff, sizeof(m_SIPPortFilter));

	memset(m_SIPIPv4AddressFilter, 0xff, sizeof(m_SIPIPv4AddressFilter));

	memset(m_SIPIPv6AddressFilter, 0xff, sizeof(m_SIPIPv6AddressFilter));

	memset(m_RTPIPv4AddressFilter, 0xff, sizeof(m_RTPIPv4AddressFilter));

	memset(m_RTPIPv6AddressFilter, 0xff, sizeof(m_RTPIPv6AddressFilter));

	memset(m_VLANFilter, 0xff, sizeof(m_VLANFilter));

	memset(m_RTPPortFilter, 0x00, sizeof(m_RTPPortFilter));
	memset(m_RTCPPortFilter, 0x00, sizeof(m_RTCPPortFilter));

	memset(m_szSIPURIFilter[0], 0, 256);
	memset(m_szSIPURIFilter[1], 0, 256);
	memset(m_szSIPURIFilter[2], 0, 256);
	memset(m_szSIPURIFilter[3], 0, 256);
	memset(m_szSIPURIFilter[4], 0, 256);
	memset(m_szSIPURIFilter[5], 0, 256);
	memset(m_szSIPURIFilter[6], 0, 256);
	memset(m_szSIPURIFilter[7], 0, 256);
}

Digi04MkIICommsEngine::~Digi04MkIICommsEngine()
{
	if (m_szTCPHost[0] != NULL) free(m_szTCPHost[0]);
	if (m_szTCPHost[1] != NULL) free(m_szTCPHost[1]);
	if (m_szTCPHost[2] != NULL) free(m_szTCPHost[2]);

	if (m_szSMTPDestAddr[0] != NULL) free(m_szSMTPDestAddr[0]);
	if (m_szSMTPDestAddr[1] != NULL) free(m_szSMTPDestAddr[1]);
	if (m_szSMTPDestAddr[2] != NULL) free(m_szSMTPDestAddr[2]);

	if (m_szSNTPHostname[0] != NULL) free(m_szSNTPHostname[0]);
	if (m_szSNTPHostname[1] != NULL) free(m_szSNTPHostname[1]);
	if (m_szSNTPHostname[2] != NULL) free(m_szSNTPHostname[2]);

	if (m_pFirmwareImage != NULL)
	{
		free(m_pFirmwareImage);
		m_pFirmwareImage = NULL;
	}
}

bool Digi04MkIICommsEngine::GotInitialize(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotInitialize\n");
#endif
	BYTE Mess[8];
	strncpy((char *)&(Mess[3]), BOOTLOADER_VERSION, 5);
	return EncodeMessage(0, 0, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryFwVersion(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryFwVersion\n");
#endif
	BYTE Mess[8];
	strncpy((char *)&(Mess[3]), FIRMWARE_VERSION, 5);
	return EncodeMessage(1, 0, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryFPGAHwType(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryFPGAHwType\n");
#endif
	bool bRes = false;
	int len=strlen(FPGA_HW_TYPE);
	BYTE *pMess = (BYTE *) malloc(len+3);
	if (pMess != NULL)
	{
		strncpy((char *)&(pMess[3]), FPGA_HW_TYPE, len);
		bRes =  EncodeMessage(1, 1, 0, pMess, len+3);
		free(pMess);
	}
	return bRes;
}

bool Digi04MkIICommsEngine::GotQueryFPGAProgVersion(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryFPGAProgVersion\n");
#endif
	BYTE Mess[8];
	strncpy((char *)&(Mess[3]), FPGA_PROG_VERSION, 5);
	return EncodeMessage(1, 2, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryFPGAProgType(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryFPGAProgType\n");
#endif
	BYTE Mess[8];
	strncpy((char *)&(Mess[3]), FPGA_PROG_TYPE, 5);
	return EncodeMessage(1, 3, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySerialNumber(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySerialNumber\n");
#endif
	BYTE Mess[13];
	strncpy((char *)&(Mess[3]), FAKE_SERIAL_NUMBER, 10);
	return EncodeMessage(1, 4, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryDaughterCards(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryDaughterCards\n");
#endif
	BYTE Mess[7];
	Mess[3] = FAKE_DCARD_TYPE;
	Mess[4] = FAKE_DCARD_TYPE;
	Mess[5] = FAKE_DCARD_TYPE;
	Mess[6] = FAKE_DCARD_TYPE;
	return EncodeMessage(1, 5, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotSendFirmwareInit(DWORD MessageLen)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSendFirmwareInit\n");
#endif
	m_FirmwareChecksum = 0;
	m_FirmwareLength = MessageLen;
	m_pFirmwareImage = (BYTE *)malloc(MessageLen);
	BYTE Mess[3];
	return EncodeMessage(2, 0, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSendFirmwareBlock(DWORD Offset, BYTE Data[512])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSendFirmwareBlock\n");
#endif
	if (m_pFirmwareImage != NULL)
	{
		int i=0;
		while (((Offset+i) <m_FirmwareLength) && (i<512))
		{
			m_pFirmwareImage[Offset+i] = Data[i];
			// Also calc checksum here...
			i++;
		}
	}
	BYTE Mess[4];
	Mess[3] = 1; // OK
	bool bRes = EncodeMessage(2, 1, 0, Mess, sizeof(Mess));
	if ((Offset+512) >= m_FirmwareLength)
	{
		// Do something with it...
		if (m_pFirmwareImage != NULL)
		{
			free(m_pFirmwareImage);
			m_pFirmwareImage = NULL;
		}
		Mess[3] = 0; // Load Complete
		bRes = bRes | EncodeMessage(2, 2, 0, Mess, sizeof(Mess));
	}
	return bRes;
}


bool Digi04MkIICommsEngine::GotRequestFwChecksum(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotRequestFwChecksum\n");
#endif
	BYTE Mess[7];
	memcpy(&(Mess[3]), &m_FirmwareChecksum, sizeof(DWORD));
	return EncodeMessage(2, 3, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotSendFPGAInit(DWORD MessageLen)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSendFPGAInit\n");
#endif
	m_FPGAChecksum = 0;
	m_FPGALength = MessageLen;
	m_pFPGAImage = (BYTE *)malloc(MessageLen);
	BYTE Mess[3];
	return EncodeMessage(2, 4, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSendFPGABlock(DWORD Offset, BYTE Data[512])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSendFPGABlock\n");
#endif
	if (m_pFPGAImage != NULL)
	{
		int i=0;
		while (((Offset+i) <m_FPGALength) && (i<512))
		{
			m_pFPGAImage[Offset+i] = Data[i];
			// Also calc checksum here...
			i++;
		}
	}
	BYTE Mess[4];
	Mess[3] = 1; // OK
	bool bRes = EncodeMessage(2, 5, 0, Mess, 4);
	if ((Offset+512) >= m_FPGALength)
	{
		// Do something with it...
		if (m_pFPGAImage != NULL)
		{
			free(m_pFPGAImage);
			m_pFPGAImage = NULL;
		}
		Mess[3] = 0; // Load Complete
		bRes = bRes | EncodeMessage(2, 6, 0, Mess, sizeof(Mess));
	}
	return bRes;
}


bool Digi04MkIICommsEngine::GotRequestFPGAChecksum(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotRequestFPGAChecksum\n");
#endif
	BYTE Mess[7];
	memcpy(&(Mess[3]), &m_FPGAChecksum, sizeof(DWORD));
	return EncodeMessage(2, 7, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotRequestReboot(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotRequestReboot\n");
#endif
	BYTE Mess[4];
	Mess[3] = 0;
	return EncodeMessage(2, 8, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryRTC(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRTC\n");
#endif
	time_t t = time(NULL);
	tm *ptm = localtime(&t);
	char szDt[15];
	BYTE Mess[17];
	if (ptm != NULL)
	{
	   sprintf(szDt, "%4d%2d%2d%2d%2d%2d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
	} else
	{
		sprintf(szDt, "19700101000000");
	}
	strncpy((char *)&(Mess[3]), szDt, 14);
	return EncodeMessage(1, 6, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRTC(char *szTime)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRTC\n");
#endif
	int year, month, day, hr, min, sec;
	BYTE Mess[4];
	Mess[3]  = 0; // Invalid
	if (sscanf(szTime, "%4d%2d%2d%2d%2d%2d", &year, &month, &day, &min, &hr, &sec) == 6)
	{
		// Set time
		Mess[3]  = 1; // Ok
	}
	return EncodeMessage(1, 6, 1, Mess, sizeof(Mess));
}


	// IP Parameters
bool Digi04MkIICommsEngine::GotQueryMACAddress(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryMACAddress\n");
#endif
	BYTE Mess[9];
	// Get MAC address
	memcpy(&(Mess[3]), m_MACAddress, 6); // assume 6 byte MAC

	return EncodeMessage(1, 7, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetMACAddress(BYTE MacAddress[8], int MessageLen)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetMACAddress\n");
#endif

	memcpy(m_MACAddress, MacAddress, MessageLen-3);

	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 7, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryTCPListenPort(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryTCPListenPort\n");
#endif
	BYTE Mess[5];

	memcpy(&(Mess[3]), &m_TCPListenPort, sizeof(WORD));
	return EncodeMessage(1, 8, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetTCPListenPort(WORD Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetTCPListenPort\n");
#endif
	m_TCPListenPort = Port;
	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 8, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryEthernetStatus(BYTE Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryEthernetStatus\n");
#endif
	BYTE Mess[5];
	// Get Status
	Mess[3] = Port;
	Mess[4] = 3; // Link active at 10Mbps

	return EncodeMessage(1, 40, 0, Mess, sizeof(Mess));
}

	// IPv4 Parameters
bool Digi04MkIICommsEngine::GotQueryIPv4Address(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv4Address\n");
#endif
	BYTE Mess[8];
	memcpy(&(Mess[3]), m_TCPIPv4Address, 5);
	return EncodeMessage(1, 9, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv4Address(BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)

{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv4Address\n");
#endif
	memcpy(m_TCPIPv4Address, IPAddr, 5);

	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 9, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryIPv4Gateway(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv4Gateway\n");
#endif
	BYTE Mess[7];
	memcpy(&(Mess[3]), m_TCPIPv4Gateway, 4);
	return EncodeMessage(1, 10, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv4Gateway(BYTE IPAddr[4])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv4Gateway\n");
#endif
	memcpy(m_TCPIPv4Gateway, IPAddr, 4);

	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 10, 1, Mess, sizeof(Mess));
}
 
bool Digi04MkIICommsEngine::GotQueryIPv4DNSServer(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv4DNSServer\n");
#endif
	BYTE Mess[7];
	memcpy(&(Mess[3]), m_TCPIPv4DNSAddress, 4);
	return EncodeMessage(1, 11, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv4DNSServer(BYTE IPAddr[4])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv4DNSServer\n");
#endif
	memcpy(m_TCPIPv4DNSAddress, IPAddr, 4);

	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 11, 1, Mess, sizeof(Mess));
}
 

	// IPv6 Parameters
bool Digi04MkIICommsEngine::GotQueryIPv6Address(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv6Address\n");
#endif
	BYTE Mess[20];
	memcpy(&(Mess[3]), m_TCPIPv6Address, 17);
	return EncodeMessage(1, 12, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv6Address(BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv6Address\n");
#endif
	memcpy(m_TCPIPv6Address, IPAddr, 17);
	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 12, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryIPv6Gateway(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv6Gateway\n");
#endif
	BYTE Mess[19];
	memcpy(&(Mess[3]), m_TCPIPv6Gateway, 16);
	return EncodeMessage(1, 13, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv6Gateway(BYTE IPAddr[16])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv6Gateway\n");
#endif
	memcpy(m_TCPIPv6Gateway, IPAddr, 16);
	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 13, 1, Mess, sizeof(Mess));
}
 
bool Digi04MkIICommsEngine::GotQueryIPv6DNSServer(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryIPv6DNSServer\n");
#endif
	BYTE Mess[19];
	memcpy(&(Mess[3]), m_TCPIPv6DNSAddress, 16);
	return EncodeMessage(1, 14, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetIPv6DNSServer(BYTE IPAddr[16])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetIPv6DNSServer\n");
#endif
	memcpy(m_TCPIPv6DNSAddress, IPAddr, 16);
	BYTE Mess[4];
	Mess[3] = 1; // Ok;
	return EncodeMessage(1, 14, 1, Mess, sizeof(Mess));
}
 

bool Digi04MkIICommsEngine::GotQueryOperationMode(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryOperationMode\n");
#endif

	BYTE Mess[4];
	Mess[3] = m_OperationsMode;
	return EncodeMessage(1, 15, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetOperationMode(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetOperationMode\n");
#endif
	
	BYTE Mess[4];
	m_OperationsMode = Flag;
	Mess[3] = 1;
	return EncodeMessage(1, 15, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryDiagLevel(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryDiagLevel\n");
#endif
		
	BYTE Mess[4];
	Mess[3] = m_DiagLevel;
	return EncodeMessage(1, 16, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetDiagLevel(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetDiagLevel\n");
#endif
	BYTE Mess[4];
	m_DiagLevel = Flag;
	Mess[3] = 1;
	return EncodeMessage(1, 16, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryRunningServices(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRunningServices\n");
#endif
		
	BYTE Mess[4];
	Mess[3] = m_Services;
	return EncodeMessage(1, 17, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRunningServices(BYTE Services)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRunningServices\n");
#endif
	BYTE Mess[4];
	m_Services = Services;
	Mess[3] = 1;
	return EncodeMessage(1, 17, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryDChannelStatus(BYTE Channel)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryDChannelStatus\n");
#endif
	BYTE Mess[4];
	Mess[3] = m_DChannelStatus[Channel];
	return EncodeMessage(3, Channel, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetDChannelStatus(BYTE Channel, BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetDChannelStatus\n");
#endif
	BYTE Mess[4];
	m_DChannelStatus[Channel] = Status;
	Mess[3] = 1;
	return EncodeMessage(4, Channel, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryBChannelStatus(BYTE Channel)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryBChannelStatus\n");
#endif
	BYTE Mess[4];
	Mess[3] = m_BChannelStatus[Channel];
	return EncodeMessage(5, Channel, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetBChannelStatus(BYTE Channel, BYTE Status)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetBChannelStatus\n");
#endif
	BYTE Mess[4];
	m_BChannelStatus[Channel] = Status;
	Mess[3] = 1;
	return EncodeMessage(6, Channel, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotSetLCDMessage(BYTE Data[832])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetLCDMessage\n");
#endif
	memcpy(m_LCDMessage, Data, sizeof(m_LCDMessage));
	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(1, 18, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryLineStatus(BYTE Line)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryLineStatus\n");
#endif
	BYTE Mess[4];
	Mess[3] = m_LineEnabled[Line];
	return EncodeMessage(1, 19, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetLineStatus(BYTE Line, BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetLineStatus\n");
#endif
	BYTE Mess[4];
	m_LineEnabled[Line] = Flag;
	Mess[3] = 1;
	return EncodeMessage(1, 19, 1, Mess, sizeof(Mess));
}

	// SD Card Functions
bool Digi04MkIICommsEngine::GotCopyFileToSDCard(char *szFilename)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotCopyFileToSDCard\n");
#endif

	strncpy(m_szToFilename, szFilename, 260);
	m_szToFilename[259] = '\0';

	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(7, 0, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotCopyFileToSDCardLen(QWORD MessageLen)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotCopyFileToSDCardLen\n");
#endif
	m_ToFileLen = MessageLen;
	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(7, 1, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotCopyFileToSDCardBlock(QWORD Offset, BYTE Data[512])
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotCopyFileToSDCardBlock\n");
#endif
	BYTE Mess[4];
	Mess[3] = 1;
	bool bRes = EncodeMessage(7, 2, 0, Mess, sizeof(Mess));
	if ((Offset + 512) >= m_ToFileLen)
	{
		Mess[3] = 0;
		bRes = EncodeMessage(7, 3, 0, Mess, sizeof(Mess));
	}
	return bRes;
}


bool Digi04MkIICommsEngine::GotCopyFileFromSDCard(char *szFilename)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotCopyFileFromSDCard\n");
#endif
	strncpy(m_szFromFilename, szFilename, 260);
	m_szFromFilename[259] = '\0';

	m_FromFileLen = 1045;

	BYTE Mess[12];
	memcpy(&(Mess[4]), &m_FromFileLen, sizeof(QWORD));
	Mess[3] = 1;
	EncodeMessage(7, 4, 0, Mess, sizeof(Mess));
	BYTE Mess2[523];

	// Send First block
	m_FromOffset=0;
	memcpy(&(Mess2[3]), &m_FromOffset, sizeof(QWORD));
	// copy file data here also...
	
	return  EncodeMessage(7, 5, 0, Mess2, sizeof(Mess2));
}

bool Digi04MkIICommsEngine::GotCopyFileFromSDCardComplete(BYTE Flag)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotCopyFileFromSDCardComplete\n");
#endif
	BYTE Mess2[523];

	if (Flag == 1) // Ok, move on to next block, else resend current block
	{
		m_FromOffset += 512;
	}
	bool bRes = false;
	if (m_FromOffset < m_FromFileLen)
	{
		memcpy(&(Mess2[3]), &m_FromOffset, sizeof(QWORD));
		// copy data here also...
		bRes = EncodeMessage(7, 5, 0, Mess2, sizeof(Mess2));
	}
	return bRes; 
}


bool Digi04MkIICommsEngine::GotDeleteFileFromSDCard(char *szFilename)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotDeleteFileFromSDCard\n");
#endif
	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(7, 6, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotIsSDCardInserted(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotIsSDCardInserted\n");
#endif
	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(7, 7, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySDCardFreeSpace(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySDCardFreeSpace\n");
#endif
	QWORD FreeSpace=0;
	BYTE Mess[11];
	memcpy(&(Mess[3]), &FreeSpace, sizeof(QWORD));
	return EncodeMessage(7, 8, 0, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryChannels(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryChannels\n");
#endif
	BYTE Mess[4];
	Mess[3] = m_nChannels; // supports 4 channels
	return EncodeMessage(1, 20, 0, Mess, sizeof(Mess));
}


	// Security Options
bool Digi04MkIICommsEngine::GotSetXTREncryption(BYTE Enable, char *szPassphrase)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetXTREncryption\n");
#endif
	BYTE Mess[4];
	Mess[3] = 1;

	return EncodeMessage(1, 21, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetSSLEncryption(BYTE Enable)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSSLEncryption\n");
#endif
	BYTE Mess[4];
	Mess[3] = 1;

	return EncodeMessage(1, 22, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryAllowedHosts(BYTE Host)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryAllowedHosts\n");
#endif
	bool bRes = false;
	if ((Host >= 3) || (m_szTCPHost[Host] == NULL))
	{
		BYTE Mess[3];
		bRes = EncodeMessage(1, 23, 0, Mess, sizeof(Mess));
	} else
	{
		int l = 3+strlen(m_szTCPHost[Host]);
		BYTE *pMess = (BYTE *)malloc(l);
		strncpy((char *)&(pMess[3]), m_szTCPHost[Host], l-3);
		bRes = EncodeMessage(1, 23, 0, pMess, l);
		free(pMess);
	}
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetAllowedHosts(BYTE Host, char *szHostname)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetAllowedHosts\n");
#endif
	bool bRes = false;
	BYTE Mess[4];
	if (Host <3)
	{
		if (m_szTCPHost[Host] != NULL)
		{
			free(m_szTCPHost[Host]);
			m_szTCPHost[Host] = NULL;
		}
		m_szTCPHost[Host] = (char *)malloc(strlen(szHostname)+1);
		strcpy(m_szTCPHost[Host], szHostname);
		
		Mess[3] = 1;	
	} else
	{
		Mess[3] = 0;
	}
	bRes = EncodeMessage(1, 23, 1, Mess, sizeof(Mess));
	return bRes;
}

	// SMTP
bool Digi04MkIICommsEngine::GotQuerySMTPServer(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySMTPServer\n");
#endif
	int l = 5+strlen(m_szSMTPServer);
	BYTE *pMess = (BYTE *)malloc(l);
	memcpy(&(pMess[3]), &m_ServerPort, sizeof(WORD));
	strncpy((char *)&(pMess[5]), m_szSMTPServer, l-5);

	bool bRes =  EncodeMessage(1, 24, 0, pMess, l);
	free(pMess);
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetSMTPServer(WORD ServerPort, char *szServerName)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSMTPServer\n");
#endif
	m_ServerPort = ServerPort;
	strncpy(m_szSMTPServer, szServerName, 255);
	m_szSMTPServer[255] = '\0';
	BYTE Mess[4];
	Mess[3] = 1;

	return EncodeMessage(1, 24, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySMTPLoginName(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySMTPLoginName\n");
#endif
	int l = 3+strlen(m_szSMTPLogin);
	BYTE *pMess = (BYTE *)malloc(l);
	strncpy((char *)&(pMess[3]), m_szSMTPLogin, l-3);

	bool bRes = EncodeMessage(1, 25, 0, pMess, l);
	free(pMess);
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetSMTPLoginName(char *szLoginName)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSMTPLoginName\n");
#endif
	strncpy(m_szSMTPLogin, szLoginName, 255);
	m_szSMTPLogin[255] = '\0';
	BYTE Mess[4];
	Mess[3] = 1;

	return EncodeMessage(1, 25, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySMTPLoginPassword(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySMTPLoginPassword\n");
#endif
	int l = 3+strlen(m_szSMTPPasswd);
	BYTE *pMess = (BYTE *)malloc(l);
	strncpy((char *)&(pMess[3]), m_szSMTPPasswd, l-3);

	bool bRes = EncodeMessage(1, 26, 0, pMess, l);
	free(pMess);
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetSMTPLoginPassword(char *szPassword)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSMTPLoginPassword\n");
#endif
	strncpy(m_szSMTPPasswd, szPassword, 255);
	m_szSMTPPasswd[255] = '\0';
	BYTE Mess[4];
	Mess[3] = 1;

	return EncodeMessage(1, 26, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySMTPAddress(BYTE AddrIndex)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySMTPAddress\n");
#endif

	bool bRes = false;
	if ((AddrIndex >= 3) || (m_szSMTPDestAddr[AddrIndex] == NULL))
	{
		BYTE Mess[3];
		bRes = EncodeMessage(1, 27, 0, Mess, sizeof(Mess));
	} else
	{
		int l = 3+strlen(m_szSMTPDestAddr[AddrIndex]);
		BYTE *pMess = (BYTE *)malloc(l);
		strncpy((char *)&(pMess[3]), m_szSMTPDestAddr[AddrIndex], l-3);
		bRes = EncodeMessage(1, 27, 0, pMess, l);
		free(pMess);
	}
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetSMTPAddress(BYTE AddrIndex, char *szEmailAddress)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSMTPAddress\n");
#endif
	bool bRes = false;
	BYTE Mess[4];
	if (AddrIndex <3)
	{
		if (m_szSMTPDestAddr[AddrIndex] != NULL)
		{
			free(m_szSMTPDestAddr[AddrIndex]);
			m_szSMTPDestAddr[AddrIndex] = NULL;
		}
		m_szSMTPDestAddr[AddrIndex] = (char *)malloc(strlen(szEmailAddress)+1);
		strcpy(m_szSMTPDestAddr[AddrIndex], szEmailAddress);
		
		Mess[3] = 1;	
	} else
	{
		Mess[3] = 0;
	}
	bRes = EncodeMessage(1, 27, 1, Mess, sizeof(Mess));
	return bRes;
}


	//SNTP
bool Digi04MkIICommsEngine::GotQuerySNTPHostname(BYTE AddressIndex)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySNTPHostname\n");
#endif
	bool bRes = false;
	if ((AddressIndex >= 3) || (m_szSNTPHostname[AddressIndex] == NULL))
	{
		BYTE Mess[3];
		bRes = EncodeMessage(1, 28, 0, Mess, sizeof(Mess));
	} else
	{
		int l = 3+strlen(m_szSNTPHostname[AddressIndex]);
		BYTE *pMess = (BYTE *)malloc(l);
		strncpy((char *)&(pMess[3]), m_szSNTPHostname[AddressIndex], l-3);
		bRes = EncodeMessage(1, 28, 0, pMess, l);
		free(pMess);
	}
	return bRes;
}

bool Digi04MkIICommsEngine::GotSetSNTPHostname(BYTE AddressIndex, char *szHostname)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSNTPHostname\n");
#endif
	bool bRes = false;
	BYTE Mess[4];
	if (AddressIndex <3)
	{
		if (m_szSNTPHostname[AddressIndex] != NULL)
		{
			free(m_szSNTPHostname[AddressIndex]);
			m_szSNTPHostname[AddressIndex] = NULL;
		}
		m_szSNTPHostname[AddressIndex] = (char *)malloc(strlen(szHostname)+1);
		strcpy(m_szSNTPHostname[AddressIndex], szHostname);
		
		Mess[3] = 1;	
	} else
	{
		Mess[3] = 0;
	}
	bRes = EncodeMessage(1, 28, 1, Mess, sizeof(Mess));
	return bRes;
}

bool Digi04MkIICommsEngine::GotQuerySNTPPollInterval(void)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySNTPPollInterval\n");
#endif
	BYTE Mess[5];
	memcpy(&(Mess[3]), &m_SNTPInterval, sizeof(WORD));
	return EncodeMessage(1, 29, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetSNTPPollInterval(WORD Interval)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSNTPPollInterval\n");
#endif
	if (Interval < 60) Interval = 60;
	m_SNTPInterval = Interval;
	BYTE Mess[4];
	Mess[3] = 1;
	return EncodeMessage(1, 29, 1, Mess, sizeof(Mess));
}

// IPTap Specific Parameters
bool Digi04MkIICommsEngine::GotQueryMACAddressFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryMACAddressFilter\n");
#endif
	BYTE Mess[10];
	// Get MAC address
	Mess[3] = Port;
	memcpy(&(Mess[4]), m_MACAddressFilter[Port], 6); // assume 6 byte MAC

	return EncodeMessage(1, 30, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetMACAddressFilter(BYTE Port, BYTE MacAddress[8], int MessageLen)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetMACAddressFilter\n");
#endif

	memcpy(m_MACAddressFilter[Port], MacAddress, MessageLen-4);

	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 30, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySIPPortFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySIPPortFilter\n");
#endif
	BYTE Mess[6];

	Mess[3] = Port;
	memcpy(&(Mess[4]), &(m_SIPPortFilter[Port]), sizeof(WORD));
	return EncodeMessage(1, 31, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetSIPPortFilter(BYTE Port, WORD SIPPort)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSIPPortFilter\n");
#endif
	m_SIPPortFilter[Port] = SIPPort;
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 31, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySIPIPv4AddressFilter(BYTE Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySIPIPv4AddressFilter\n");
#endif
	BYTE Mess[9];
	Mess[3] = Port;
	memcpy(&(Mess[4]), m_SIPIPv4AddressFilter[Port], 5);
	return EncodeMessage(1, 32, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetSIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)

{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSIPIPv4AddressFilter\n");
#endif
	memcpy(m_SIPIPv4AddressFilter[Port], IPAddr, 5);

	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 32, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySIPIPv6AddressFilter(BYTE Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySIPIPv6AddressFilter\n");
#endif
	BYTE Mess[21];
	Mess[3] = Port;
	memcpy(&(Mess[4]), m_SIPIPv6AddressFilter[Port], 17);
	return EncodeMessage(1, 33, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetSIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSIPIPv6AddressFilter\n");
#endif
	memcpy(m_SIPIPv6AddressFilter[Port], IPAddr, 17);
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 33, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryVLANFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryVLANFilter\n");
#endif
	BYTE Mess[6];

	Mess[3] = Port;
	memcpy(&(Mess[4]), &(m_VLANFilter[Port]), sizeof(WORD));
	return EncodeMessage(1, 34, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetVLANFilter(BYTE Port, WORD VLAN)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetVLANFilter\n");
#endif
	m_VLANFilter[Port] = VLAN;
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 34, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQuerySIPURIFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQuerySIPURIFilter\n");
#endif
	BYTE Mess[64];

	Mess[3] = Port;
	memcpy(&(Mess[4]), &(m_szSIPURIFilter[Port]), strlen(m_szSIPURIFilter[Port]));
	return EncodeMessage(1, 35, 0, Mess, strlen(m_szSIPURIFilter[Port])+4);
}

bool Digi04MkIICommsEngine::GotSetSIPURIFilter(BYTE Port, char *szSIPURIFilter)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetSIPURIFilter\n");
#endif
	strcpy(m_szSIPURIFilter[Port], szSIPURIFilter);
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 35, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryRTPPortFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRTPPortFilter\n");
#endif
	BYTE Mess[6];

	Mess[3] = Port;
	memcpy(&(Mess[4]), &(m_RTPPortFilter[Port]), sizeof(WORD));
	return EncodeMessage(1, 36, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRTPPortFilter(BYTE Port, WORD RTPPort)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRTPPortFilter\n");
#endif
	m_RTPPortFilter[Port] = RTPPort;
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 36, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryRTCPPortFilter(BYTE Port)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRTCPPortFilter\n");
#endif
	BYTE Mess[6];

	Mess[3] = Port;
	memcpy(&(Mess[4]), &(m_RTCPPortFilter[Port]), sizeof(WORD));
	return EncodeMessage(1, 37, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRTCPPortFilter(BYTE Port, WORD RTCPPort)
{
#ifdef DIAG
	if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRTCPPortFilter\n");
#endif
	m_SIPPortFilter[Port] = RTCPPort;
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 37, 1, Mess, sizeof(Mess));
}


bool Digi04MkIICommsEngine::GotQueryRTPIPv4AddressFilter(BYTE Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRTPIPv4AddressFilter\n");
#endif
	BYTE Mess[9];
	Mess[3] = Port;
	memcpy(&(Mess[4]), m_RTPIPv4AddressFilter[Port], 5);
	return EncodeMessage(1, 32, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]) // Final byte is routing prefix (number of bits in netmask)

{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRTPIPv4AddressFilter\n");
#endif
	memcpy(m_RTPIPv4AddressFilter[Port], IPAddr, 5);

	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 32, 1, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotQueryRTPIPv6AddressFilter(BYTE Port)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotQueryRTPIPv6AddressFilter\n");
#endif
	BYTE Mess[21];
	Mess[3] = Port;
	memcpy(&(Mess[4]), m_RTPIPv6AddressFilter[Port], 17);
	return EncodeMessage(1, 33, 0, Mess, sizeof(Mess));
}

bool Digi04MkIICommsEngine::GotSetRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]) // Final byte is routing prefix (number of bits in netmask)
{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngine::GotSetRTPIPv6AddressFilter\n");
#endif
	memcpy(m_RTPIPv6AddressFilter[Port], IPAddr, 17);
	BYTE Mess[5];
	Mess[3] = Port;
	Mess[4] = 1; // Ok;
	return EncodeMessage(1, 33, 1, Mess, sizeof(Mess));
}



bool Digi04MkIICommsEngine::EncodeMessage(int MessageType, int Channel, int Dir, BYTE *pData, int Length)
{
	pData[0] = (BYTE)((MessageType & 0x3f) | ((Length & 0x300) >> 2));
	pData[1] = (Length & 0xff);
	pData[2] = (Channel & 0x3f) | ((Dir & 1) << 7);
	return true; //SendMessage(pData, Length);
}

