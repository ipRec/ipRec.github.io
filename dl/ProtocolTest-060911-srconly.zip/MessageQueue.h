#include <vector>

#include "Digi04MkIICommsEngineHostUSB.h"

class CommsMessage
{
public:
	CommsMessage();
	CommsMessage(const CommsMessage &other);
	CommsMessage(BYTE *pMess, unsigned int Length);
	~CommsMessage();

	CommsMessage& operator=(const CommsMessage& other);

	unsigned int m_Length;
	BYTE m_pMess[BUFSIZE];
};

class MessageQueue
{
public:
	MessageQueue();
	MessageQueue(const MessageQueue &other);
	~MessageQueue();
	bool PushElement(const CommsMessage &Element);
	bool PopElement(CommsMessage &Element);
	MessageQueue& operator=(const MessageQueue& other);
private:
	typedef std::vector<CommsMessage> MessageQueue_t;
	volatile int m_Read;
	volatile int m_Write;
	static const int m_Size=64;
	MessageQueue_t m_MessageQueue;
};