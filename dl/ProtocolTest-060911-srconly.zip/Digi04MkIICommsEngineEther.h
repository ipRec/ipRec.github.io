// Digi04MkIICommsEngineEther.h : 
//
#ifndef _Digi04MkIICommsEngineEther_h_Included
#define _Digi04MkIICommsEngineEther_h_Included

#include <stdio.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "Digi04MkIICommsEngine.h"

// Run on hardware
class Digi04MkIICommsEngineEther : public Digi04MkIICommsEngine
{
public:

	Digi04MkIICommsEngineEther(SOCKET *pSoc);
	~Digi04MkIICommsEngineEther();

	bool SendMessage(BYTE *pData, DWORD Length);
	bool ReceiveMessage(BYTE *pData, DWORD &Length);

private:
	SOCKET *m_pSoc;
};

#endif