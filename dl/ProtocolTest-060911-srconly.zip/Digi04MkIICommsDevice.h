// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifndef _Digi04MkIICommsDevice_h_Included
#define _Digi04MkIICommsDevice_h_Included

#ifdef WIN32
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#pragma warning (disable:4100)
#include <stdio.h>
#include <string.h>
#include <windows.h>
typedef DWORD64 QWORD;

#else
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint64_t QWORD;
typedef uint32_t DWORD;
typedef uint16_t WORD;
typedef unsigned char BYTE;
#endif

#ifndef DIAG
#define DIAG 1
#endif



// Run on hardware
class Digi04MkIICommsDevice
{
public:
	enum {INITIALIZE=0, CONFIG=1, FIRMWARE=2, QUERYDCHANCONF=3, SETDCHANCONF=4, QUERYBCHANCONF=5, SETBCHANCONF=6, SDCARD=7, BCHANDATA=8, DCHANDATA=9, DCHANEVENT=10, DEBUGDATA=11, ERRORMESS=63 };
	enum {FirmwareVersion=0, FPGAHardwareType=1, FPGAProgramVersion=2, FPGAProgramType=3, SerialNumber=4, DaughterCards=5, RTC=6, MacAddress=7, TCPListenPort=8, 
	IPv4Address=9, IPv4Gateway=10, IPv4DNSServer=11, IPv6Address=12, IPv6Gateway=13, IPv6DNSServer=14, OperationMode=15, DiagnosticLevel=16, RunningServices=17, 
	LCDMessage=18, EnableLine=19, NoChannels=20, XTREncryption=21, SSLEncryption=22, TCPHosts=23, SMTPServer=24, SMTPLogin=25, SMTPPassword=26, SMTPDestAddr=27, 
	SNTPHostname=28, SNTPPollInterval=29, MacAddressFilter=30, SIPPortFilter=31, SIPIPv4AddressFilter=32, SIPIPv6AddressFilter=33, VLANFilter=34, SIPURIFilter=35,
	RTPPortFilter=36, RTCPPortFilter=37, RTPIPv4AddressFilter=38, RTPIPv6AddressFilter=39, EthernetStatus=40};
	enum {FirmwareInit=0, FirmwareBlock=1, FirmwareComplete=2, FirmwareChecksum=3, FPGAInit=4, FPGABlock=5, FPGAComplete=6, FPGAChecksum=7, Reboot=8, ReadNVInit=9, ReadNVAck=10, ReadNVBlock=11, ReadNVComplete=12,
		WriteNVInit=13, WriteNVBlock=14, WriteNVComplete=15};
	enum {SDCopyToCardInit=0, SDCopyToCardLength=1, SDCopyToCardBlock=2, SDCopyToCardComplete=3, SDCopyFromCardInit=4, SDCopyFromCardBlock=5, SDDeleteFile=6, SDIsCardInserted=7, SDFreeSpace=8};
	enum {Query=0, Set=1};
	enum {ToKeySet=0, ToSwitch=1};

	Digi04MkIICommsDevice();
	virtual ~Digi04MkIICommsDevice();

	bool DecodeBlock(BYTE *pData, DWORD Length);

	virtual bool SendMessage(BYTE *pData, DWORD Length)=0;
	virtual bool ReceiveMessage(BYTE *pData, DWORD &Length)=0;

	virtual bool GotInitialize(void)=0;

	virtual bool GotQueryFwVersion(void)=0;
	virtual bool GotQueryFPGAHwType(void)=0;
	virtual bool GotQueryFPGAProgVersion(void)=0;
	virtual bool GotQueryFPGAProgType(void)=0;
	virtual bool GotQuerySerialNumber(void)=0;
	virtual bool GotQueryDaughterCards(void)=0;

	virtual bool GotSendFirmwareInit(DWORD Length)=0;
	virtual bool GotSendFirmwareBlock(DWORD Offset, BYTE Data[512])=0;

	virtual bool GotRequestFwChecksum(void)=0;

	virtual bool GotSendFPGAInit(DWORD Length)=0;
	virtual bool GotSendFPGABlock(DWORD Offset, BYTE Data[512])=0;

	virtual bool GotRequestFPGAChecksum(void)=0;

	virtual bool GotRequestReboot(void)=0;

	virtual bool GotQueryRTC(void)=0;
	virtual bool GotSetRTC(char *szTime)=0;

	// IP Parameters
	virtual bool GotQueryMACAddress(void)=0;
	virtual bool GotSetMACAddress(BYTE MacAddress[8], int Length)=0;
	virtual bool GotQueryTCPListenPort(void)=0;
	virtual bool GotSetTCPListenPort(WORD Port)=0;
	virtual bool GotQueryEthernetStatus(BYTE Port)=0;

	// IPv4 Parameters
	virtual bool GotQueryIPv4Address(void)=0;
	virtual bool GotSetIPv4Address(BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotQueryIPv4Gateway(void)=0;
	virtual bool GotSetIPv4Gateway(BYTE IPAddr[4])=0; 
	virtual bool GotQueryIPv4DNSServer(void)=0;
	virtual bool GotSetIPv4DNSServer(BYTE IPAddr[4])=0; 

	// IPv6 Parameters
	virtual bool GotQueryIPv6Address(void)=0;
	virtual bool GotSetIPv6Address(BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotQueryIPv6Gateway(void)=0;
	virtual bool GotSetIPv6Gateway(BYTE IPAddr[16])=0; 
	virtual bool GotQueryIPv6DNSServer(void)=0;
	virtual bool GotSetIPv6DNSServer(BYTE IPAddr[16])=0; 

	virtual bool GotQueryOperationMode(void)=0;
	virtual bool GotSetOperationMode(BYTE Flag)=0;

	virtual bool GotQueryDiagLevel(void)=0;
	virtual bool GotSetDiagLevel(BYTE Flag)=0;

	virtual bool GotQueryRunningServices(void)=0;
	virtual bool GotSetRunningServices(BYTE Services)=0;

	virtual bool GotQueryDChannelStatus(BYTE Channel)=0;
	virtual bool GotSetDChannelStatus(BYTE Channel, BYTE Status)=0;

	virtual bool GotQueryBChannelStatus(BYTE Channel)=0;
	virtual bool GotSetBChannelStatus(BYTE Channel, BYTE Status)=0;

	virtual bool GotSetLCDMessage(BYTE Data[832])=0;

	virtual bool GotQueryLineStatus(BYTE Line)=0;
	virtual bool GotSetLineStatus(BYTE Line, BYTE Flag)=0;

	// SD Card Functions
	virtual bool GotCopyFileToSDCard(char *szFilename)=0;
	virtual bool GotCopyFileToSDCardLen(QWORD Length)=0;
	virtual bool GotCopyFileToSDCardBlock(QWORD Offset, BYTE Data[512])=0;

	virtual bool GotCopyFileFromSDCard(char *szFilename)=0;
	virtual bool GotCopyFileFromSDCardComplete(BYTE Flag)=0;

	virtual bool GotDeleteFileFromSDCard(char *szFilename)=0;
	virtual bool GotIsSDCardInserted(void)=0;
	virtual bool GotQuerySDCardFreeSpace(void)=0;

	virtual bool GotQueryChannels(void)=0;

	// Security Options
	virtual bool GotSetXTREncryption(BYTE Enable, char *szPassphrase)=0;
	virtual bool GotSetSSLEncryption(BYTE Enable)=0;
	virtual bool GotQueryAllowedHosts(BYTE Host)=0;
	virtual bool GotSetAllowedHosts(BYTE Host, char *szHostname)=0;

	// SMTP
	virtual bool GotQuerySMTPServer(void)=0;
	virtual bool GotSetSMTPServer(WORD ServerPort, char *szServerName)=0;
	virtual bool GotQuerySMTPLoginName(void)=0;
	virtual bool GotSetSMTPLoginName(char *szLoginName)=0;
	virtual bool GotQuerySMTPLoginPassword(void)=0;
	virtual bool GotSetSMTPLoginPassword(char *szPassword)=0;
	virtual bool GotQuerySMTPAddress(BYTE AddrIndex)=0;
	virtual bool GotSetSMTPAddress(BYTE AddrIndex, char *szEmailAddress)=0;

	//SNTP
	virtual bool GotQuerySNTPHostname(BYTE AddressIndex)=0;
	virtual bool GotSetSNTPHostname(BYTE AddressIndex, char *szHostname)=0;
	virtual bool GotQuerySNTPPollInterval(void)=0;
	virtual bool GotSetSNTPPollInterval(WORD Interval)=0;

	// IPTAP Specific Parameters
	virtual bool GotQueryMACAddressFilter(BYTE Port)=0;
	virtual bool GotSetMACAddressFilter(BYTE Port, BYTE MacAddress[8], int Length)=0;
	virtual bool GotQuerySIPPortFilter(BYTE Port)=0;
	virtual bool GotSetSIPPortFilter(BYTE Port, WORD SIPPort)=0;
	virtual bool GotQuerySIPIPv4AddressFilter(BYTE Port)=0;
	virtual bool GotSetSIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotQuerySIPIPv6AddressFilter(BYTE Port)=0;
	virtual bool GotSetSIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotQueryVLANFilter(BYTE Port)=0;
	virtual bool GotSetVLANFilter(BYTE Port, WORD VLAN)=0;
	virtual bool GotQuerySIPURIFilter(BYTE Port)=0;
	virtual bool GotSetSIPURIFilter(BYTE Port, char *szSIPURI)=0;
	virtual bool GotQueryRTPPortFilter(BYTE Port)=0;
	virtual bool GotSetRTPPortFilter(BYTE Port, WORD RTPPort)=0;
	virtual bool GotQueryRTCPPortFilter(BYTE Port)=0;
	virtual bool GotSetRTCPPortFilter(BYTE Port, WORD RTCPPort)=0;
	virtual bool GotQueryRTPIPv4AddressFilter(BYTE Port)=0;
	virtual bool GotSetRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotQueryRTPIPv6AddressFilter(BYTE Port)=0;
	virtual bool GotSetRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)

#ifdef DIAG
	FILE *hDiag;
#endif
};

#endif
