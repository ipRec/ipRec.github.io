
#include "stdafx.h"
#include <winsock2.h>
#include "UDPPacketFilter.h"
#include <stdio.h>
#include <string.h>
#include <ws2tcpip.h>
#include <Dbt.h>
#include <setupapi.h>

#include <string>
#include <map>

#define HOST 1
#define USB 1

#include "Digi04MkIICommsDevice.h"
#ifdef HOST
#ifdef USB
#include "Digi04MkIICommsEngineHostUSB.h"
#include "usb.h"
#include "MessageQueue.h"

#include "MultiXtR.h"
#else
#include "Digi04MkIICommsEngineHostEther.h"
#endif
#else
#include "Digi04MkIICommsEngineEther.h"
#endif

#ifndef HOST

DWORD WINAPI DeviceSocketHandler(void *lpParameter)
{
	SOCKET *pSoc = (SOCKET *)lpParameter;

	Digi04MkIICommsEngineEther commsengine(pSoc);

	return 0;
}


DWORD WINAPI  TCPServerThread(void *lpParameter)
{
	// Listen for incoming connections on port 51148
	// connect socket
	SOCKET ListenSoc = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ListenSoc == INVALID_SOCKET)
	{
		 int err = WSAGetLastError();
		 printf("\tFailed to create socket, err=%d\n", err);
		 WSACleanup();
		 return 1;
	}
	sockaddr_in service;
	service.sin_family = AF_INET;
	service.sin_addr.s_addr = inet_addr("127.0.0.1");
	service.sin_port = htons(51148);
	if (bind( ListenSoc, (SOCKADDR*) &service, sizeof(service)) == SOCKET_ERROR) 
	{
		printf("bind() failed.\n");
		closesocket(ListenSoc);
		WSACleanup();
		return 1;
	}

	if (listen( ListenSoc, SOMAXCONN ) == SOCKET_ERROR)
	{
		printf("Error listening on socket.\n");
		closesocket(ListenSoc);
		WSACleanup();
		return 1;
	}

	while(true)
	{
		printf("waiting for a connection\n");
		SOCKET *pAcceptSocket = new SOCKET; 
		struct sockaddr_in sadr;
		int addr_size;
		//if(((*pAcceptSocket) = accept( ListenSoc, (SOCKADDR*)&sadr, &addr_size))!= INVALID_SOCKET )
		if(((*pAcceptSocket) = accept( ListenSoc, NULL, NULL))!= INVALID_SOCKET )
		{
			//printf("Received connection from %s\n",inet_ntoa(sadr.sin_addr));
			printf("Received connection\n");
			CreateThread(0, 0, &DeviceSocketHandler, (void*)pAcceptSocket , 0, 0);
		}
		else
		{
			fprintf(stderr, "Error accepting %d\n",WSAGetLastError());
		}
	}

	return 0;
}

DWORD WINAPI  UDPServerThread(void *lpParameter)
{

	return 0;
}

#else

#ifdef USB

#ifdef DIAG
FILE *hAppDiag=NULL;
#endif
DWORD WINAPI USBClientFast(LPVOID pParam);
DWORD WINAPI USBClientIntFast(LPVOID pParam);
DWORD WINAPI USBClientSlow(LPVOID pParam);

class USBDev
{
public: 
	USBDev();
	USBDev(const USBDev &other);
	~USBDev();

	std::string m_szName;
	Digi04MkIICommsEngineHostUSB *m_pDevEngine;
	bool m_bFound;
	HANDLE m_hFastThread, m_hFastIntThread, m_hSlowThread;
	MessageQueue m_RxQueue, m_RxIntQueue;
	MessageQueue m_TxQueue;
	HANDLE m_hQueueEvent;

	bool operator <(const  USBDev& other) const;
	USBDev& operator=(const USBDev& other);
};

USBDev::USBDev()
{
	m_szName = "";
	m_pDevEngine = NULL;
	m_bFound = false;
	m_hFastThread=NULL;
	m_hFastIntThread=NULL;
	m_hSlowThread=NULL;
	m_hQueueEvent=NULL;
}

USBDev::~USBDev()
{
}

USBDev::USBDev(const USBDev &other)
{
	m_szName = other.m_szName;
	m_pDevEngine = other.m_pDevEngine;
	m_bFound = other.m_bFound;
	m_hFastThread = other.m_hFastThread;
	m_hFastIntThread = other.m_hFastIntThread;
	m_hSlowThread = other.m_hSlowThread;
	m_TxQueue = other.m_TxQueue;
	m_RxQueue = other.m_RxQueue;
	m_RxIntQueue = other.m_RxIntQueue;
	m_hQueueEvent = other.m_hQueueEvent;

}

bool USBDev::operator <(const  USBDev& other) const
{
	return m_szName < other.m_szName;
}

USBDev& USBDev::operator=(const USBDev& other)
{
	m_szName = other.m_szName;
	m_pDevEngine = other.m_pDevEngine;
	m_bFound = other.m_bFound;
	m_hFastThread = other.m_hFastThread;
	m_hFastIntThread = other.m_hFastIntThread;
	m_hSlowThread = other.m_hSlowThread;
	m_TxQueue = other.m_TxQueue;
	m_RxQueue = other.m_RxQueue;
	m_RxIntQueue = other.m_RxIntQueue;
	m_hQueueEvent = other.m_hQueueEvent;
	return *this;
}

typedef std::map<std::string, USBDev> USBDevMap_t;

USBDevMap_t USBDevMap;
volatile int bSuspending=false;

void ScanBusses(void)
{
	struct usb_bus *busses;
	struct usb_device *dev;
	struct usb_bus * bus;

	// Mark all devices as not found
	for(USBDevMap_t::iterator pos = USBDevMap.begin(); pos != USBDevMap.end(); ++pos)
	{
		pos->second.m_bFound = false;
	}

    usb_find_busses();
    usb_find_devices();

	busses = usb_get_busses();

	for (bus = busses; bus; bus = bus->next) 
	{
		for (dev = bus->devices; dev; dev = dev->next) 
		{
#ifdef DIAG
			if (hAppDiag != NULL) { fprintf(hAppDiag, "VID=%04x PID=%04x\n", dev->descriptor.idVendor, dev->descriptor.idProduct); fflush(hAppDiag); }
#endif
#ifdef IPTAP
			if ((dev->descriptor.idVendor == VID) && (dev->descriptor.idProduct == IPTAP_PID)) // our device
#else
			if ((dev->descriptor.idVendor == VID) && (dev->descriptor.idProduct == DIGI04MKII_PID)) // our device
#endif
			{
#ifdef DIAG
				if (hAppDiag != NULL) { 
#ifdef IPTAP
					fprintf(hAppDiag, "\tFound IP Tap: %s\n", dev->filename); fflush(hAppDiag); 
					printf("\tFound IP Tap: %s\n", dev->filename); fflush(hAppDiag); 
#else
					fprintf(hAppDiag, "\tFound Digi04MkII: %s\n", dev->filename); fflush(hAppDiag); 
					printf("\tFound Digi04MkII: %s\n", dev->filename); fflush(hAppDiag); 
#endif
				}
#endif
				std::string szName(dev->filename);
				USBDevMap_t::iterator pos = USBDevMap.find(szName);
				if (pos != USBDevMap.end())
				{
#ifdef DIAG
					if (hAppDiag != NULL) { 
						fprintf(hAppDiag, "Device already exists, ignoring\n"); fflush(hAppDiag); 
						printf("Device already exists, ignoring\n"); fflush(hAppDiag); 
					}
#endif
					pos->second.m_bFound = true;
				} else
				{
#ifdef DIAG
					if (hAppDiag != NULL) { 
						fprintf(hAppDiag, "New device adding\n"); fflush(hAppDiag); 
						printf("New device adding\n"); fflush(hAppDiag); 
					}
#endif
					std::pair<USBDevMap_t::iterator, bool> ret;
					USBDev client;
					client.m_szName = szName;
					client.m_pDevEngine = new Digi04MkIICommsEngineHostUSB(dev);
					client.m_bFound = true;
					client.m_hFastThread = CreateThread(0, 0, USBClientFast, LPVOID(client.m_pDevEngine) , CREATE_SUSPENDED, 0);
					SetThreadPriority(client.m_hFastThread, THREAD_PRIORITY_ABOVE_NORMAL);
					client.m_hFastIntThread = CreateThread(0, 0, USBClientIntFast, LPVOID(client.m_pDevEngine) , CREATE_SUSPENDED, 0);
					SetThreadPriority(client.m_hFastIntThread, THREAD_PRIORITY_ABOVE_NORMAL);
					client.m_hSlowThread = CreateThread(0, 0, USBClientSlow, LPVOID(client.m_pDevEngine) , CREATE_SUSPENDED, 0);
					SetThreadPriority(client.m_hSlowThread, THREAD_PRIORITY_NORMAL);
					client.m_hQueueEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
					ret = USBDevMap.insert(std::make_pair(szName, client));
					// only start when added to map...
					ResumeThread(client.m_hFastThread);
					ResumeThread(client.m_hFastIntThread);
					ResumeThread(client.m_hSlowThread);
				}
			}
		}
	}
	// Find all devices which have been removed, and remove from map
	bool bFound = false;
	do
	{
		bFound = false;
		for(USBDevMap_t::iterator pos = USBDevMap.begin(); pos != USBDevMap.end(); ++pos)
		{
			if (pos->second.m_bFound == false)
			{
#ifdef DIAG
				if (hAppDiag != NULL) { 
					fprintf(hAppDiag, "Device removed '%s'\n", pos->second.m_szName.c_str()); fflush(hAppDiag);
					printf("Device removed '%s'\n", pos->second.m_szName.c_str()); fflush(hAppDiag);
				}
#endif
				pos->second.m_pDevEngine->ExitThread();
				HANDLE ThreadIds[3] = {pos->second.m_hFastThread, pos->second.m_hFastIntThread, pos->second.m_hSlowThread};
				WaitForMultipleObjects(3, ThreadIds, TRUE, INFINITE);
				CloseHandle(pos->second.m_hQueueEvent);
				pos->second.m_hQueueEvent = NULL;
				delete pos->second.m_pDevEngine;
				pos->second.m_pDevEngine = NULL;
				USBDevMap.erase(pos);
				bFound = true;
				break;
			}
		}
	} while (bFound);
}

void ReloadAllDevices(void)
{
	// Close and reopen all devices (after power saving)
	bool bFound = false;
	do
	{
		bFound = false;
		for(USBDevMap_t::iterator pos = USBDevMap.begin(); pos != USBDevMap.end(); ++pos)
		{
			{
#ifdef DIAG
				if (hAppDiag != NULL) { 
					fprintf(hAppDiag, "Device removed '%s'\n", pos->second.m_szName.c_str()); fflush(hAppDiag); 
					printf("Device removed '%s'\n", pos->second.m_szName.c_str());
				}
#endif
				pos->second.m_pDevEngine->ExitThread();
				HANDLE ThreadIds[3] = {pos->second.m_hFastThread, pos->second.m_hFastIntThread, pos->second.m_hSlowThread};
				WaitForMultipleObjects(3, ThreadIds, TRUE, INFINITE);
				CloseHandle(pos->second.m_hQueueEvent);
				pos->second.m_hQueueEvent = NULL;
				delete pos->second.m_pDevEngine;
				pos->second.m_pDevEngine = NULL;
				USBDevMap.erase(pos);
				bFound = true;
				break;
			}
		}
	} while (bFound);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
		case WM_DEVICECHANGE:
		{
			PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR) lParam;
			switch (wParam)
			{
				case DBT_DEVICEARRIVAL:
					if (pHdr->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
					{
						PDEV_BROADCAST_DEVICEINTERFACE pDevHdr = (PDEV_BROADCAST_DEVICEINTERFACE) pHdr;
#ifdef IPTAP
						if (strncmp(pDevHdr->dbcc_name, IPTAP_ID_STR, 25) == 0)
						{
#ifdef DIAG
							if (hAppDiag != NULL) { fprintf(hAppDiag, "IP Tap Inserted (%s)\n", pDevHdr->dbcc_name);  fflush(hAppDiag); }
#endif
							ScanBusses();
						}
#else
						if (strncmp(pDevHdr->dbcc_name, DIGI04MKII_ID_STR, 25) == 0)
						{
#ifdef DIAG
							if (hAppDiag != NULL) { fprintf(hAppDiag, "Digi04MkII Inserted (%s)\n", pDevHdr->dbcc_name);  fflush(hAppDiag); }
#endif
							ScanBusses();
						}
#endif
					}
					break;
				case DBT_DEVICEREMOVECOMPLETE:
				if (pHdr->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
					{
						PDEV_BROADCAST_DEVICEINTERFACE pDevHdr = (PDEV_BROADCAST_DEVICEINTERFACE) pHdr;
#ifdef IPTAP
						if (strncmp(pDevHdr->dbcc_name, IPTAP_ID_STR, 25) == 0)
						{
#ifdef DIAG
							if (hAppDiag != NULL) { fprintf(hAppDiag, "IP Tap Removed (%s)\n", pDevHdr->dbcc_name);  fflush(hAppDiag); }
#endif
							ScanBusses();
						}
#else
						if (strncmp(pDevHdr->dbcc_name, DIGI04MKII_ID_STR, 25) == 0)
						{
#ifdef DIAG
							if (hAppDiag != NULL) { fprintf(hAppDiag, "Digi04MkII Removed (%s)\n", pDevHdr->dbcc_name);  fflush(hAppDiag); }
#endif
							ScanBusses();
						}
#endif
					}
					break;
			}
			return TRUE;
		}
		break;
		case WM_POWERBROADCAST:
			switch (wParam)
			{
			case PBT_APMPOWERSTATUSCHANGE:
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_APMPOWERSTATUSCHANGE\n");  fflush(hAppDiag); }
#endif
				break;
			case PBT_APMRESUMEAUTOMATIC:
				bSuspending = false;
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_APMRESUMEAUTOMATIC\n");  fflush(hAppDiag); }
#endif
				break;
			case PBT_APMRESUMESUSPEND:
				bSuspending = false;			
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_APMRESUMESUSPEND\n");  fflush(hAppDiag); }
#endif
				ScanBusses();
				break;
			case PBT_APMRESUMECRITICAL:
				bSuspending = false;		
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_APMRESUMECRITICAL\n");  fflush(hAppDiag); }
#endif
				ScanBusses();
				break;
			case PBT_APMSUSPEND:
				bSuspending = true;
				ReloadAllDevices(); // Can't tell Sleep from Hibernate reload all devices regardless
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_APMSUSPEND\n");  fflush(hAppDiag); }
#endif
				break;
			case PBT_POWERSETTINGCHANGE:
#ifdef DIAG
				if (hAppDiag != NULL) { fprintf(hAppDiag, "PBT_POWERSETTINGCHANGE\n");  fflush(hAppDiag); }
#endif
				break;
			}
			break;
        case WM_CLOSE:
#ifdef DIAG
			if (hAppDiag != NULL) { fprintf(hAppDiag, "WM_CLOSE\n");  fflush(hAppDiag); }
#endif
            DestroyWindow(hwnd);
        break;
        case WM_DESTROY:
#ifdef DIAG
			if (hAppDiag != NULL) { fprintf(hAppDiag, "WM_DESTROY\n");  fflush(hAppDiag); }
#endif
            PostQuitMessage(0);
        break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// Generic USB Guid
static const GUID GUID_DEVINTERFACE_USB =
{ 0xA5DCBF10L, 0x6530, 0x11D2, { 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED } };

DWORD WINAPI  USBDetectThread(void *lpParameter)
{
	HINSTANCE hInstance = *((HINSTANCE *)lpParameter);
	const char g_szClassName[] = "IRLUMDriver";

	WNDCLASSEX wc;
    HWND wn;
    MSG Msg;

    //Step 1: Registering the Window Class
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = 0;
    wc.lpfnWndProc   = WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = g_szClassName;
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if(!RegisterClassEx(&wc))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!",
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    // Step 2: Creating the Window
    wn = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        g_szClassName,
        "The title of my window",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 240, 120,
        NULL, NULL, hInstance, NULL);

    if (wn == NULL)
    {
        printf("Window Creation Failed!\n");
        return 0;
    }

    ShowWindow(wn, SW_HIDE);
    UpdateWindow(wn);

	DEV_BROADCAST_DEVICEINTERFACE NotificationFilter;
	ZeroMemory( &NotificationFilter, sizeof(NotificationFilter) );
	NotificationFilter.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
	NotificationFilter.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
	NotificationFilter.dbcc_classguid = GUID_DEVINTERFACE_USB;
	HDEVNOTIFY hDevNotify = RegisterDeviceNotification(wn, &NotificationFilter, DEVICE_NOTIFY_WINDOW_HANDLE);
	if( !hDevNotify ) 
	{
		printf("RegisterDeviceNotification Failed\n");
	}

#ifdef DIAG
	hAppDiag = fopen("appdiag.txt", "w");
#endif
	usb_init();
	ScanBusses();

    // Step 3: The Message Loop
    while(GetMessage(&Msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }
	UnregisterDeviceNotification(hDevNotify);

#ifdef DIAG
	if (hAppDiag != NULL) fclose(hAppDiag);
#endif

    return Msg.wParam;
}

BYTE *LoadIntelHexFile(char *szFilename, DWORD &Length, DWORD &ELAR, DWORD &SLAR)
{
	char szLine[256];
	BYTE *pData = NULL;
	Length=0;
	FILE *hIn = fopen(szFilename, "r");
	if (hIn == NULL)
	{
		return NULL;
	}
	SLAR=0;
	ELAR=0;
	int bad=0;
	bool bFirst = true;
	while (!feof(hIn))
	{
		if (fgets(szLine, 255, hIn) != NULL)
		{
			if (szLine[0] == ':')
			{
				int count=0, addrlow=0, type=0;
				int checksum=0, filechecksum=0, v;
				sscanf(&(szLine[1]), "%02x%04x%02x", &count, &addrlow, &type);
				if (type == 0)
				{
					if (bFirst)
					{
						bFirst = false;
						ELAR += addrlow;
					}
					pData = (BYTE *)realloc(pData, (Length+count));
					for(int i=0; i<(count+4); i++)
					{
						sscanf(&(szLine[(i*2)+1]), "%02x", &v);
						if (i>=4) pData[Length++] = (BYTE)v;
						checksum += v;
					}
				} else
				{
					for(int i=0; i<(count+4); i++)
					{
						sscanf(&(szLine[(i*2)+1]), "%02x", &v);
						checksum += v;
					}
				}
				sscanf(&(szLine[(count+4)*2+1]), "%02x", &filechecksum);
				checksum = checksum & 0xff;
				checksum = (0x100-checksum) & 0xff;
				if (checksum != filechecksum) bad++;
				switch (type)
				{
				case 0: // data
					break;
				case 1: // eof
					break;
				case 2: // Extended Segment Address Record
					break;
				case 3: // Start segment address record
					break;
				case 4: // Extended linear address record
					sscanf(&(szLine[9]), "%04x", &ELAR);
					ELAR = ELAR << 16;
					break;
				case 5: // Start linear address record
					sscanf(&(szLine[9]), "%08x", &SLAR);
					break;
				}

			}
		}
	}

	fclose(hIn);
	if (bad > 0)
	{
		free(pData);
		Length = 0;
		return NULL;
	}
	return pData;
}



void ReceiveMess(USBDevMap_t::iterator pos, Digi04MkIICommsEngineHostUSB *pCommsengine, CommsMessage &Mess)
{
	CommsMessage MessBulk, MessInt;
	bool bBulk=false, bInt=false;
	while(!pCommsengine->HasExited())
	{
		bInt = pos->second.m_RxIntQueue.PopElement(MessInt);
		bBulk = pos->second.m_RxQueue.PopElement(MessBulk);
		if (bBulk || bInt)
		{
			break;
		}
		Sleep(1);
	}
	if (!(pCommsengine->HasExited()) && bInt)
	{
		Mess = MessInt;
		pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
	}
	if (!(pCommsengine->HasExited()) && bBulk)
	{
		Mess = MessBulk;
		pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
	}
}


void ReceiveAllMess(USBDevMap_t::iterator pos, Digi04MkIICommsEngineHostUSB *pCommsengine, CommsMessage &Mess)
{
	CommsMessage MessBulk, MessInt;
	bool bBulk=true, bInt=true;
	while(!pCommsengine->HasExited() && (bBulk || bInt))
	{
		bInt = pos->second.m_RxIntQueue.PopElement(MessInt);
		bBulk = pos->second.m_RxQueue.PopElement(MessBulk);
		if (bInt)
		{
			pCommsengine->DecodeBlock(MessInt.m_pMess, MessInt.m_Length);
		}
		if (bBulk)
		{
			pCommsengine->DecodeBlock(MessBulk.m_pMess, MessBulk.m_Length);
		}
	}
}

int ReceiveAndDisgardAllMess(USBDevMap_t::iterator pos, Digi04MkIICommsEngineHostUSB *pCommsengine, CommsMessage &Mess)
{
	int RetCode= -1;
	BYTE m[3] = {Digi04MkIICommsDevice::FIRMWARE, 4, Digi04MkIICommsDevice::Reboot};
	while((!(pCommsengine->HasExited())) && ((pos->second.m_RxQueue.PopElement(Mess) == true) || (pos->second.m_RxIntQueue.PopElement(Mess) == true)))
	{
		if (memcmp(m, Mess.m_pMess, 3)==0)
		{
			RetCode = Mess.m_pMess[3];
#ifdef DIAG
			if (hAppDiag != NULL) fprintf(hAppDiag, "ReceiveAndDisgardAllMess: Got Reboot code=%d\n", Mess.m_pMess[3]);
#endif
		}
		//pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
	}
	return RetCode;
}

typedef void RTPPORTCALLBACK(void *pUserData, int DevicePort, unsigned __int64 RTPPort, unsigned __int64 RTCPPort);
extern CUDPPacketFilter *pPacketFilter=NULL;
extern "C++" __declspec(dllimport) void *RegisterPacketFilter(void);
extern "C++" __declspec(dllimport) void RegisterRTPCallback(RTPPORTCALLBACK *MyProc, void *pUserData);

class CPort
{
public: 
	CPort();
	CPort(const CPort &other);
	~CPort();

	int m_Port;
	FILE *m_hFile;
	int m_Length;
	std::string m_szFilename;
	std::string m_szCallerId;

	bool operator <(const  CPort& other) const;
	CPort& operator=(const CPort& other);
};

CPort::CPort()
{
	m_Port= -1;
	m_hFile = NULL;
	m_Length = 0;
}

CPort::~CPort()
{
}

CPort::CPort(const CPort &other)
{
	m_Port= other.m_Port;
	m_hFile = other.m_hFile;
	m_Length = other.m_Length;
	m_szFilename = other.m_szFilename;
	m_szCallerId = other.m_szCallerId;
}

bool CPort::operator <(const  CPort& other) const
{
	return m_Port < other.m_Port;
}

CPort& CPort::operator=(const CPort& other)
{
	m_Port= other.m_Port;
	m_hFile = other.m_hFile;
	m_Length = other.m_Length;
	m_szFilename = other.m_szFilename;
	m_szCallerId = other.m_szCallerId;
	return *this;
}

typedef std::map<int, CPort> CPortMap_t;

CPortMap_t PortMap;
unsigned char *m_pAudioBuffer=NULL;
int m_AudioLen=0, m_AudioPos=0;

void XtRCallback( int Port, int Event, int Data )
{
	CPortMap_t::iterator pos = PortMap.find(Port);
	int Length;
	switch(Event)
	{
	case MP_STATUS:
		printf("MP_STATUS=%d\n", Data);
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_STATUS=%d\n", Data);
#endif
		break;
	case MP_BCHANNELDATA:	
		Length = MP_GetAudioData( Port, 0, NULL, NULL, NULL );
		//printf("MP_BCHANNELDATA=%d bytes\n", Length);
#ifdef DIAG
		//if (hAppDiag != NULL) fprintf(hAppDiag, "MP_BCHANNELDATA=%d bytes\n", Length);
#endif
		{
			if (Length > (m_AudioLen-m_AudioPos))
			{
				if (m_AudioLen >= Length*10)
				{
					if (pos != PortMap.end())
					{
						fwrite(m_pAudioBuffer, sizeof(unsigned char), m_AudioPos, pos->second.m_hFile);
						pos->second.m_Length += m_AudioPos;
					}
					m_AudioPos = 0;
				} else
				{
					m_AudioLen = Length*10;
					m_pAudioBuffer = (unsigned char *)realloc(m_pAudioBuffer, Length*10);
				}
			}
			MP_GetAudioData( Port, Length, NULL, NULL, (char *)&(m_pAudioBuffer[m_AudioPos]) );	
			m_AudioPos += Length;
			if ((m_AudioLen - m_AudioPos) < Length)
			{
				if (pos != PortMap.end())
				{
					fwrite(m_pAudioBuffer, sizeof(unsigned char), m_AudioPos, pos->second.m_hFile);
					pos->second.m_Length += m_AudioPos;
				}
				m_AudioPos = 0;
			}
		}
		break;
	case MP_DCHANNELDATAPBX:		
		Length = MP_GetControlDataPBX(Port, 0, NULL );
		printf("MP_DCHANNELDATAPBX=%d bytes\n", Length);
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_DCHANNELDATAPBX=%d bytes\n", Length);
#endif
		MP_GetControlDataPBX( Port, Length, NULL );
		break;
	case MP_DCHANNELDATAPHONE:	
		Length = MP_GetControlDataPhone(Port, 0, NULL );
		printf("MP_DCHANNELDATAPBX=%d bytes\n", Length);
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_DCHANNELDATAPBX=%d bytes\n", Length);
#endif
		MP_GetControlDataPhone( Port, Length, NULL );
		break;
	case MP_BCHANNELOVERFLOW:
		printf("MP_BCHANNELOVERFLOW\n");
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_BCHANNELOVERFLOW\n");
#endif
		break;
	case MP_DCHANNELOVERFLOWPBX:
		printf("MP_DCHANNELOVERFLOWPBX\n");
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_DCHANNELOVERFLOWPBX\n");
#endif
		break;
	case MP_DCHANNELOVERFLOWPHONE:
		printf("MP_DCHANNELOVERFLOWPHONE\n");
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_DCHANNELOVERFLOWPHONE\n");
#endif
		break;
	case MP_CALLSTATE:
		switch( Data )
		{
		case CALL_ACTIVE:
		case CALL_INCOMING:	
		case CALL_OUTGOING:
		case CALL_INCOMING_INTERNAL:
		case CALL_INCOMING_EXTERNAL:
		case CALL_OUTGOING_INTERNAL:
		case CALL_OUTGOING_EXTERNAL:
			printf("MP_CALLSTATE ACTIVE(%d)\n", Data);
#ifdef DIAG
			if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CALLSTATE ACTIVE(%d)\n", Data);
#endif
			if (pos == PortMap.end())
			{
				CPort port;
				port.m_Port = Port;
				char szPath[256];
				time_t t = time(NULL);
				struct tm *now=localtime(&t);
				char *szMonths[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
				sprintf(szPath, "%d-%04d-%s-%02d-%02d.%02d.%02d.xtr", Port, now->tm_year+1900, szMonths[now->tm_mon], now->tm_mday, now->tm_hour, now->tm_min, now->tm_sec);
				port.m_szFilename = szPath;
				port.m_hFile = fopen(szPath, "w+b");
				if (port.m_hFile != NULL)
				{
					int i=4; // version
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					i=1440; // hdr len
					fwrite(&i, sizeof(int), 1, port.m_hFile);		
					i=MP_GetDataFormat(); // format
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					i=0; // important
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					i=0; // callerid
					for(int j=0; j<(128/4); j++)
					{
						fwrite(&i, sizeof(int), 1, port.m_hFile);
					}
					i=0; // comment
					for(int j=0; j<(1024/4); j++)
					{
						fwrite(&i, sizeof(int), 1, port.m_hFile);
					}
					__time32_t t = _time32(NULL);
					fwrite(&t, sizeof(__time32_t), 1, port.m_hFile);
					i=0; // length
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					i=0; // partial
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					char szMyId[128];
					memset(szMyId, 0, 128);
					sprintf(szMyId, "%s", MP_GetCallInfo(Port, INFO_VOIP_TERM_URI));
					fwrite(szMyId, sizeof(char), 128, port.m_hFile);
					i=1; // calltype
					fwrite(&i, sizeof(int), 1, port.m_hFile);
					memset(szMyId, 0, 128);
					sprintf(szMyId, "IpTap"); // System + ringtime + checksum
					fwrite(szMyId, sizeof(char), 128, port.m_hFile);
				}
				
				PortMap.insert(std::make_pair(Port, port));
				Sleep(500);
				MP_AudioMonitor(Port, TRUE); //may need to pause 1/3 second before doing this
			} 
			break;
		case CALL_IDLE:
			MP_AudioMonitor(Port, FALSE);
			printf("MP_CALLSTATE IDLE\n");
#ifdef DIAG
			if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CALLSTATE IDLE\n");
#endif
			if (pos != PortMap.end())
			{
				if (pos->second.m_hFile != NULL)
				{
					if ( m_AudioPos > 0)
					{
						fwrite(m_pAudioBuffer, sizeof(unsigned char), m_AudioPos, pos->second.m_hFile);
						pos->second.m_Length += m_AudioPos;
						m_AudioPos = 0;
					}

					fseek(pos->second.m_hFile, 16, SEEK_SET);
					char szTmp[128];
					memset(szTmp, 0, 128);
					strcpy(szTmp, pos->second.m_szCallerId.c_str());
					fwrite(szTmp, sizeof(char), 128, pos->second.m_hFile);

					fseek(pos->second.m_hFile, 1172, SEEK_SET);
					int l = pos->second.m_Length/8000;
					fwrite(&l, sizeof(int), 1, pos->second.m_hFile);
					fclose(pos->second.m_hFile);
				}
				PortMap.erase(pos);
			}
			if (m_pAudioBuffer)
			{
				free(m_pAudioBuffer);
				m_pAudioBuffer = NULL;
				m_AudioLen = 0;
				m_AudioPos = 0;
			}
			break;
		case CALL_PAGE:
			printf("MP_CALLSTATE PAGE\n");
#ifdef DIAG
			if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CALLSTATE PAGE\n");
#endif
			break;
		};
		break;
	case MP_CALLERIDUPDATE:
		printf("MP_CALLERIDUPDATE=%s\n", MP_GetCallerID(Port));
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CALLERIDUPDATE=%s\n", MP_GetCallerID(Port));
#endif
		if (pos != PortMap.end())
		{
			pos->second.m_szCallerId = MP_GetCallerID(Port);	
		}
		break;
	case MP_UUIUPDATE:
		printf("MP_UUIUPDATE=%s\n", MP_GetCallInfo(Port, INFO_UUI));
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_UUIUPDATE=%s\n", MP_GetCallInfo(Port, INFO_UUI));
#endif
		break;
	case MP_CALLEDPARTYIDUPDATE:
		printf("MP_CALLEDPARTYIDUPDATE=%s\n", MP_GetCallInfo(Port, INFO_CALLEDPARTY));
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CALLEDPARTYIDUPDATE=%s\n", MP_GetCallInfo(Port, INFO_CALLEDPARTY));
#endif
		break;
	case MP_CONNECTEDNODUPDATE:
		printf("MP_CONNECTEDNODUPDATE=%s\n", MP_GetCallInfo(Port, INFO_CONNECTEDNO));
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_CONNECTEDNODUPDATE=%s\n", MP_GetCallInfo(Port, INFO_CONNECTEDNO));
#endif
		break;
	case MP_WARNING:
		printf("MP_WARNING\n");
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_WARNING\n");
#endif
		break;
	case MP_VOIP_TERMINAL_IP:
		{
			char szTmp[64];
			strncpy(szTmp, MP_GetCallInfo(Port, INFO_VOIP_TERM_IP), 63);
			szTmp[63] = '\0';
			__int64 ip64=0;
			sscanf(szTmp, "%I64d", &ip64);
			int port = ip64 & 0xffff;
			uint32 ip = (uint32)(ip64 >> 16);
#ifdef DIAG
			if (hAppDiag != NULL) fprintf(hAppDiag, "MP_VOIP_TERMINAL_IP=%d.%d.%d.%d:%d\n", (ip >> 24) & 0xff, (ip >> 16) & 0xff, (ip >> 8) & 0xff, ip & 0xff, port);
#endif
		}
		break;
	case MP_VOID_TERMINAL_URI:
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_VOID_TERMINAL_URI=%s\n", MP_GetCallInfo(Port, INFO_VOIP_TERM_URI));
#endif
		break;
	case MP_VOIP_SESSION_ENCODING:
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MP_VOIP_SESSION_ENCODING=%s\n", MP_GetCallInfo(Port, INFO_VOIP_SESS_ENC));
#endif
		break;
	default:
		break;
	}
#ifdef DIAG
	if (hAppDiag != NULL) fflush(hAppDiag);
#endif
}

void RTPPortCallback(void *pUserData, int DevicePort, unsigned __int64 inRTPPort, unsigned __int64 inRTCPPort)
{
	uint16 RTPPort, RTCPPort;
	uint32 RTPIP, RTCPIP;

	RTPPort = ntohs((uint16)(inRTPPort & 0xffff));
	RTCPPort = ntohs((uint16)(inRTCPPort & 0xffff));
	RTPIP = ntohl((uint32)((inRTPPort >> 16) & 0xffffffff));
	RTCPIP = ntohl((uint32)((inRTCPPort >> 16) & 0xffffffff));
	printf("*** RTPPortCallback RTP IP=%d.%d.%d.%d:%hu, RTCP IP=%d.%d.%d.%d:%hu\n", 
		(RTPIP >> 24) & 0xff, (RTPIP >> 16) & 0xff, (RTPIP >> 8) & 0xff, RTPIP & 0xff, RTPPort, 
		(RTCPIP >> 24) & 0xff, (RTCPIP >> 16) & 0xff, (RTCPIP >> 8) & 0xff, RTCPIP & 0xff, RTCPPort);
#ifdef DIAG
	if (hAppDiag != NULL)  {fprintf(hAppDiag, "*** RTPPortCallback RTP IP=%d.%d.%d.%d:%hu, RTCP IP=%d.%d.%d.%d:%hu\n", 
		(RTPIP >> 24) & 0xff, (RTPIP >> 16) & 0xff, (RTPIP >> 8) & 0xff, RTPIP & 0xff, RTPPort, 
		(RTCPIP >> 24) & 0xff, (RTCPIP >> 16) & 0xff, (RTCPIP >> 8) & 0xff, RTCPIP & 0xff, RTCPPort);  fflush(hAppDiag);}
#endif
	CommsMessage Mess;
	Digi04MkIICommsEngineHostUSB *pCommsengine = (Digi04MkIICommsEngineHostUSB *)pUserData;
	USBDevMap_t::iterator pos = USBDevMap.find(pCommsengine->m_szFilename);
	if (pos == USBDevMap.end())
	{
		return;
	}

	Mess.m_Length = 6;
	Mess.m_pMess[3] = 0; // Port 
	Mess.m_pMess[4] = RTPPort & 0xff;
	Mess.m_pMess[5] = (RTPPort>>8) & 0xff;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTPPortFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTP Port
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveMess(pos, pCommsengine, Mess);

	Mess.m_Length = 6;
	Mess.m_pMess[3] = 0; // Port 
	Mess.m_pMess[4] = RTCPPort & 0xff; 
	Mess.m_pMess[5] = (RTCPPort>>8) & 0xff;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTCPPortFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTCP Port
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveMess(pos, pCommsengine, Mess);

	
	Mess.m_Length = 9;
	Mess.m_pMess[3] = 0; // Port
	Mess.m_pMess[4] = (RTPIP >> 24) & 0xff; Mess.m_pMess[5] = (RTPIP >> 16) & 0xff; Mess.m_pMess[6] = (RTPIP >> 8) & 0xff; Mess.m_pMess[7] = RTPIP & 0xff; Mess.m_pMess[8] = 24;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTPIPv4AddressFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTP IP Address
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveMess(pos, pCommsengine, Mess);
}

/* Win PCap .pcap file structure */
typedef struct pcap_hdr_s {
        uint32 magic_number;   // magic number 
        uint16 version_major;  // major version number 
        uint16 version_minor;  // minor version number 
        int  thiszone;       // GMT to local correction 
        uint32 sigfigs;        // accuracy of timestamps 
        uint32 snaplen;        // max length of captured packets, in octets 
        uint32 network;        // data link type 
} pcap_hdr_t;

typedef struct pcaprec_hdr_s {
        uint32 ts_sec;         // timestamp seconds 
        uint32 ts_usec;        // timestamp microseconds 
        uint32 incl_len;       // number of octets of packet saved in file 
        uint32 orig_len;       // actual length of packet 
} pcaprec_hdr_t;

typedef unsigned short int u16;

u16 fcstab[256] = {
0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

u16 compute_fcs(unsigned char *data, int length)
{   u16 fcs;

    fcs = 0xffff;
    while (length--)
    {   fcs = (fcs >> 8) ^ fcstab[(fcs ^ ((u16)*data)) & 0xff];
        data++;
    }
    return (fcs^0xffff);
}



#define NPORTS 3
// Linksys is isip
// NEC is isip
BYTE PhoneIP[NPORTS][4] = {{192, 168, 5, 100}, {172, 20, 21, 79}, {192, 168, 1, 4}}; // NEC, Linksys, grandstream
//BYTE PhoneIP[NPORTS][4] = {{172, 20, 21, 79}, {192, 168, 5, 100}, {192, 168, 1, 4}}; // Linksys, NEC, grandstream
//BYTE PhoneIP[NPORTS][4] = {{192, 168, 1, 9}, {192, 168, 5, 100}, {192, 168, 1, 4}}; // Yealink, NEC, grandstream
//#define GRANDSTREAM
#ifdef GRANDSTREAM
// NOTE Grandstream uses port which is half that in SDP to transmit from and receive to
// Thus it will say its using port 25049 and actually use 12024 (subtract 1000 and halve?) 
BYTE PhoneIP[NPORTS][4] = {{192, 168, 1, 4}, {172, 20, 21, 79}, {192, 168, 5, 100}}; // grandstream, Linksys, NEC, 
#endif
WORD PhonePort[NPORTS] = {5060, 5060, 5060}; // server
//char *szPortMode[NPORTS] = {"isip", "isip", "nsip"};
//char *szPortMode[NPORTS] = {"isip", "isip", "nsip"};
char *szPortMode[NPORTS] = {"isip", "isip", "isip"};

DWORD WINAPI USBClientSlow(LPVOID pParam)
{
	CommsMessage Mess;
	Digi04MkIICommsEngineHostUSB *pCommsengine = (Digi04MkIICommsEngineHostUSB *)pParam;
	USBDevMap_t::iterator pos = USBDevMap.find(pCommsengine->m_szFilename);
	if (pos == USBDevMap.end())
	{
		return 0;
	}

	// Low Priority Thread

	// Remove any junk messages left in buffers
	int Reason = ReceiveAndDisgardAllMess(pos, pCommsengine, Mess);
	bool bBootLoader = (Reason == 3);
	if (bBootLoader)
	{
		printf("Booted into bootloader\n");
	} else printf("Booted into application\n");

	// Send Initialize Message to kick off
	Mess.m_Length = 3;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::INITIALIZE, 0, 0, Mess.m_pMess, Mess.m_Length); // Initialize
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);
	
	Mess.m_Length = 3;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::FirmwareVersion, Digi04MkIICommsDevice::Query, Mess.m_pMess, Mess.m_Length); // Query Firmware version
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	// Optionally load firmware if newer version available
//#define LOAD_FIRMWARE
#ifdef LOAD_FIRMWARE	
	char *szFirmware = "C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\Firmware\\IP_Tap_Bulk_0125_110726.hex";
	DWORD Len, ELAR, SLAR;
	BYTE *firmware = LoadIntelHexFile(szFirmware, Len, ELAR, SLAR);
	if (firmware != NULL)
	{
		DWORD fcs = compute_fcs(firmware, Len);
		BYTE StatusMess[3] = {Digi04MkIICommsDevice::FIRMWARE, 4, Digi04MkIICommsDevice::FirmwareBlock};

		Mess.m_Length = 15;
		memcpy(&(Mess.m_pMess[3]), &Len, sizeof(DWORD));
		memcpy(&(Mess.m_pMess[7]), &ELAR, sizeof(DWORD));
		memcpy(&(Mess.m_pMess[11]), &SLAR, sizeof(DWORD));
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::FIRMWARE, Digi04MkIICommsDevice::FirmwareInit, 0, Mess.m_pMess, Mess.m_Length); // Send firmware size, load address and start address
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);
		DWORD p=0;
		int l, q=0;
		printf("Len=%d\n", Len);
		bool bBlockOk=false;
		while (Len > 0)
		{		
			while (!(pCommsengine->HasExited()) // keep sending until we get back an ok
			{
				memcpy(&(Mess.m_pMess[3]), &p, sizeof(DWORD));
				if (Len > 512) l=512; else l=Len;
				memcpy(&(Mess.m_pMess[7]), &(firmware[p]), l);
				Mess.m_Length = 7+l;
				pCommsengine->EncodeMessage(Digi04MkIICommsDevice::FIRMWARE, Digi04MkIICommsDevice::FirmwareBlock, 0, Mess.m_pMess, Mess.m_Length); // Send firmware block
				pos->second.m_TxQueue.PushElement(Mess);
				printf("Block %d\n", ++q);
				ReceiveMess(pos, pCommsengine, Mess);
				while (!(pCommsengine->HasExited()) // wait for acknowledgement
				{
					if (memcmp(Mess.m_pMess, StatusMess, 3) == 0) 
					{
						bBlockOk = (Mess.m_pMess[3] == 1);
						break;
					}
				}
				if (bBlockOk) break;
			}
			bBlockOk=false;
			p += l;
			Len -= l;
		}
		ReceiveAllMess(pos, pCommsengine, Mess); // Get Load Complete message
		
		printf("Original Fw Checksum=0x%04x\n", fcs);

		free(firmware);

		Mess.m_Length = 3;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::FIRMWARE, Digi04MkIICommsDevice::FirmwareChecksum, 0, Mess.m_pMess, Mess.m_Length); // Send firmware size
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess); // Get Checksum message

		// Device should now reboot to application or boot loader if there was an error

		/*Mess.m_Length = 3;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::FIRMWARE, Digi04MkIICommsDevice::Reboot, 0, Mess.m_pMess, Mess.m_Length); // force a reboot
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);*/
	}
#endif

	if (bBootLoader)
	{
		// should not get here
		Mess.m_Length = 3;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::FIRMWARE, Digi04MkIICommsDevice::Reboot, 0, Mess.m_pMess, Mess.m_Length); // force a reboot
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);
	}

	Mess.m_Length = 3;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::SerialNumber, Digi04MkIICommsDevice::Query, Mess.m_pMess, Mess.m_Length); // Query Serial number
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 3;
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::NoChannels, Digi04MkIICommsDevice::Query, Mess.m_pMess, Mess.m_Length); // Query number of channels
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

#ifdef IPTAP
	//for(int j=1; j<NPORTS; j++)
	{
		int j=0;
		int k=j;
		// IP Tap specific configuration
		Mess.m_Length = 12;
		Mess.m_pMess[3] = k; // Port
		memset(&(Mess.m_pMess[4]), 255, 8);
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::MacAddressFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set MAC Address FF:FF:FF:FF:FF:FF:FF:FF
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 6;
		Mess.m_pMess[3] = k; // Port 
		Mess.m_pMess[4] = PhonePort[j] & 0xff;
		Mess.m_pMess[5] = (PhonePort[j] >> 8) & 0xff;
		//Mess.m_pMess[4] = 0x00; // all packets
		//Mess.m_pMess[5] = 0x00;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::SIPPortFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set SIP Port 5081
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 9;
		Mess.m_pMess[3] = k; // Port
		Mess.m_pMess[4] = PhoneIP[j][0]; Mess.m_pMess[5] = PhoneIP[j][1]; Mess.m_pMess[6] = PhoneIP[j][2]; Mess.m_pMess[7] = PhoneIP[j][3]; Mess.m_pMess[8] = 24;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::SIPIPv4AddressFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set SIP IP Address 192.168.5.102
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 6;
		Mess.m_pMess[3] = k; // VLan ID
		Mess.m_pMess[4] = 0xff;
		Mess.m_pMess[5] = 0xff;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::VLANFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set VLAN FFFF
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 5;
		Mess.m_pMess[3] = k; // Port
		Mess.m_pMess[4] = 0xff; // empty string, shouldn't need this byte!
		//strcpy((char *)&(Mess.m_pMess[4]), "sip:ian.spinks@172.20.21.14");
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::SIPURIFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set SIP URI
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 6;
		Mess.m_pMess[3] = k; // Port 
		Mess.m_pMess[4] = 0x00; // Port 0, ignore
		Mess.m_pMess[5] = 0x00;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTPPortFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTP Port 10020
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		Mess.m_Length = 6;
		Mess.m_pMess[3] = k; // Port 
		Mess.m_pMess[4] = 0x00; // Port 0 ignore
		Mess.m_pMess[5] = 0x00;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTCPPortFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTCP Port 10021
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);

		/*Mess.m_Length = 9;
		Mess.m_pMess[3] = k; // Port
		Mess.m_pMess[4] = PhoneIP[0]; Mess.m_pMess[5] = PhoneIP[1]; Mess.m_pMess[6] = PhoneIP[2]; Mess.m_pMess[7] = PhoneIP[3]; Mess.m_pMess[8] = 24;
		pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::RTPIPv4AddressFilter, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Set RTP IP Address 192.168.5.102
		pos->second.m_TxQueue.PushElement(Mess);
		ReceiveAllMess(pos, pCommsengine, Mess);*/
	}
	
#else
	// Digi04 mkII specific configuration
#endif

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 5; // All diagnostics to USB only
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::DiagnosticLevel, Digi04MkIICommsDevice::Set, Mess.m_pMess, Mess.m_Length); // Turn on diagnostics
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 1+4; // Enabled to USB
	//Mess.m_pMess[3] = 0; // disabled
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::SETDCHANCONF, 0, Digi04MkIICommsDevice::ToKeySet, Mess.m_pMess, Mess.m_Length); // Enable D Channel 0 to USB
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 1+4; // Enabled to USB
	//Mess.m_pMess[3] = 0; // disabled
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::SETDCHANCONF, 0, Digi04MkIICommsDevice::ToSwitch, Mess.m_pMess, Mess.m_Length); // Enable D Channel 128 to USB
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 1+2+4; // RX, TX Enabled to USB
	//Mess.m_pMess[3] = 0; // disabled
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::SETBCHANCONF, 0, Digi04MkIICommsDevice::ToKeySet, Mess.m_pMess, Mess.m_Length); // Enable B Channel 0 to USB
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 1+2+4; // RX, TX Enabled to USB
	//Mess.m_pMess[3] = 0; // disabled
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::SETBCHANCONF, 0, Digi04MkIICommsDevice::ToSwitch, Mess.m_pMess, Mess.m_Length); // Enable B Channel 128 to USB
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 0; // Port 0 
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::EthernetStatus, 0, Mess.m_pMess, Mess.m_Length); // Query Ether0 status
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	Mess.m_Length = 4;
	Mess.m_pMess[3] = 1; // Port 1 
	pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::EthernetStatus, 0, Mess.m_pMess, Mess.m_Length); // Query Ether1 status
	pos->second.m_TxQueue.PushElement(Mess);
	ReceiveAllMess(pos, pCommsengine, Mess);

	printf("Ready\n");
#ifdef DIAG
	if (hAppDiag != NULL) {fprintf(hAppDiag, "Ready\n"); fflush(hAppDiag);}
#endif


	// must do this as DLL can lose config...
	char szTmp[256];
	int j=0;
	//for(int j=1; j<2; j++)
	{
		sprintf(szTmp, "%d.%d.%d.%d", PhoneIP[j][0], PhoneIP[j][1], PhoneIP[j][2], PhoneIP[j][3]);
		MP_SetConfigEntry("pbx-ip", szTmp); // have swapped src/dst ip/port so this should be ok
		sprintf(szTmp, "%d", PhonePort[j]);
		MP_SetConfigEntry("sip-port", szTmp);
		//MP_SetConfigEntry("out-format", "US");
		MP_SetConfigEntry("out-format", "UK");
	}
	MP_SetConfigEntry("mode", szPortMode[j]); // isip for NEC in UK, nsip for Grandstream/Linksys
	MP_SetCallback(XtRCallback);
	MP_Open();
	pPacketFilter = (CUDPPacketFilter *)RegisterPacketFilter();
	RegisterRTPCallback(RTPPortCallback, (void *)pCommsengine);
#define SIMULATE 
#ifdef SIMULATE
	printf("SIMULATION!\n");
	pcap_hdr_t FileHeader;
	pcaprec_hdr_t RecHeader, LastHeader;
	clock_t tnow=0, tlast=0;
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\wireshark-linksys2.pcap", "rb");
	FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\wireshark-linksys3.pcap", "rb"); // Needs large packet handling to work!
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\wireshark-grandstream.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\NEC-110-fmware2.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\iSIP\\NEC-113-to-112-incoming.pcap", "rb"); 
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\random_traffic.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\sip_traffic.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-pcma.pcap", "rb"); // works
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-pcmu.pcap", "rb"); // works
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-g722.pcap", "rb"); // rubbish data
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-g723.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-g729.pcap", "rb"); // works, but needs large packet handling
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-g729-new3.pcap", "rb"); // ditto
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-gsm.pcap", "rb");
	//FILE *hPCap = fopen("C:\\Users\\Andrew Roberts\\Documents\\Work\\IPTap\\SampleCaptures\\yealink\\yealink-iLBC.pcap", "rb");
		
	if (hPCap == NULL)
	{
		printf("Unable to open file\n");
		int k=getchar();
		exit(1);
	}
	fread(&FileHeader, sizeof(pcap_hdr_t), 1, hPCap);
#else
	printf("REAL!\n");
#endif
#ifdef SIMULATE
	bool bFirst=true;
	int packet_no=0;
	while(!feof(hPCap) && !(pCommsengine->HasExited()))
	{
		if (fread(&RecHeader, sizeof(pcaprec_hdr_t), 1, hPCap) != 1)
		{
			break;
		}
		BYTE buf[1600];
		if (fread(buf, RecHeader.incl_len, 1, hPCap) != 1)
		{
			break;
		}
		packet_no++;
		printf("+++Packet %d\n", packet_no);
		if (packet_no >=100)
		{
			printf("\n");
		}
#ifdef GRANDSTREAM
		if (packet_no<1804)
		{
			continue;
		}
#endif

		if (!bFirst)
		{
			double t1=RecHeader.ts_sec;
			t1 += RecHeader.ts_usec/1000000.0;
			double t2=LastHeader.ts_sec;
			t2 += LastHeader.ts_usec/1000000.0;
			t1 -= t2;
			t1 *= 1000.0;
			tnow = clock();
			t2 = ((tnow-tlast)/(double)CLOCKS_PER_SEC)*1000.0;
			Sleep((DWORD)t1);
			if (t1 > t2)
			{	
				t1 -= t2;
				//printf("Sleeping %d\n", (int)t1);
				Sleep((DWORD)t1);
			}
		} else
		{
			bFirst = false;
			tnow = clock();
		}
		tlast = tnow;
		memcpy(&LastHeader, &RecHeader, sizeof(pcaprec_hdr_t));
		if (RecHeader.incl_len == RecHeader.orig_len)
		{
			
			int hdrlen = (buf[14] & 0x0f);
			uint32 ip=(PhoneIP[j][0]<<24) | (PhoneIP[j][1]<<16) | (PhoneIP[j][2]<<8) | PhoneIP[j][3];
			uint16 port=PhonePort[j];
			ip = htonl(ip);
			port = htons(port);
			uint32 srcip, dstip;
			uint16 srcport, dstport;

			if (buf[9+14] == 17) // UDP
			{
				/*srcip = ntohl(*((uint32 *)&(buf[12+14])));
				dstip = ntohl(*((uint32 *)&(buf[16+14])));
				srcport = ntohs(*((uint16 *)&(buf[hdrlen*4+14])));
				dstport = ntohs(*((uint16 *)&(buf[hdrlen*4+2+14])));
				printf("src=%d.%d.%d.%d:%d dst=%d.%d.%d.%d:%d\n", 
					(srcip>>24)&0xff, (srcip>>16)&0xff, (srcip>>8)&0xff, srcip&0xff, srcport,
					(dstip>>24)&0xff, (dstip>>16)&0xff, (dstip>>8)&0xff, dstip&0xff, dstport);*/
				if ((memcmp(&ip, &(buf[12+14]), sizeof(uint32)) == 0) || (memcmp(&ip, &(buf[16+14]), sizeof(uint32)) == 0)) 
				{
					if ((memcmp(&port, &(buf[hdrlen*4+14]), sizeof(uint16)) == 0) || (memcmp(&port, &(buf[hdrlen*4+2+14]), sizeof(uint16)) == 0))
					{
						// matching SIP packet
						int l=RecHeader.orig_len;
						int pos=0;
						while (l> 1020)
						{
							Mess.m_Length = 1023;
							memcpy(&(Mess.m_pMess[3]), &(buf[pos]), 1020);
							pos += 1020;
							l -= 1020;
							pCommsengine->EncodeMessage(Digi04MkIICommsDevice::DCHANDATA, 0, 0, Mess.m_pMess, Mess.m_Length);
							Mess.m_pMess[2] = Mess.m_pMess[2] | 0x40; // Set Extended bit
							pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
						}
						if (l > 0)
						{
							Mess.m_Length = l+3;
							memcpy(&(Mess.m_pMess[3]), &(buf[pos]), l);
							pCommsengine->EncodeMessage(Digi04MkIICommsDevice::DCHANDATA, 0, 0, Mess.m_pMess, Mess.m_Length);
							pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
						}
					} else
					{
						// matching RTP or RTCP packet
						int l=RecHeader.orig_len;
						int pos=0;
						while (l> 1020)
						{
							Mess.m_Length = 1023;
							memcpy(&(Mess.m_pMess[3]), &(buf[pos]), 1020);
							pos += 1020;
							l -= 1020;
							pCommsengine->EncodeMessage(Digi04MkIICommsDevice::BCHANDATA, 0, 0, Mess.m_pMess, Mess.m_Length);
							Mess.m_pMess[2] = Mess.m_pMess[2] | 0x40; // Set Extended bit
							pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
						}
						if (l > 0)
						{
							Mess.m_Length = l+3;
							memcpy(&(Mess.m_pMess[3]), &(buf[pos]), l);
							pCommsengine->EncodeMessage(Digi04MkIICommsDevice::BCHANDATA, 0, 0, Mess.m_pMess, Mess.m_Length);
							pCommsengine->DecodeBlock(Mess.m_pMess, Mess.m_Length);
						}
					}
					
					//int k = getchar();
				}
			}
		} else
		{
			printf("Short packet\n");
		}
		ReceiveAndDisgardAllMess(pos, pCommsengine, Mess);
	}
#else
clock_t start = clock();
	while(!(pCommsengine->HasExited()))
	{
		WaitForSingleObject(pos->second.m_hQueueEvent, 1000);
		ReceiveAllMess(pos, pCommsengine, Mess);
		/*clock_t end = clock();
		if ((end-start)>(10*CLOCKS_PER_SEC))
		{
			Mess.m_Length = 4;
			Mess.m_pMess[3] = 0; // Port 0 
			pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::EthernetStatus, 0, Mess.m_pMess, Mess.m_Length); // Query Ether0 status
			pos->second.m_TxQueue.PushElement(Mess);

			Mess.m_Length = 4;
			Mess.m_pMess[3] = 1; // Port 1 
			pCommsengine->EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::EthernetStatus, 0, Mess.m_pMess, Mess.m_Length); // Query Ether1 status
			pos->second.m_TxQueue.PushElement(Mess);

			start = end;
		}*/
	}
#endif

	MP_Close();
#ifdef SIMULATE
	fclose(hPCap);
#endif

	return 0;		
}

DWORD WINAPI USBClientFast(LPVOID pParam)
{
	CommsMessage Mess;
	Digi04MkIICommsEngineHostUSB *pCommsengine = (Digi04MkIICommsEngineHostUSB *)pParam;
	USBDevMap_t::iterator pos = USBDevMap.find(pCommsengine->m_szFilename);
	if (pos == USBDevMap.end())
	{
		return 0;
	}

	DWORD Len;

	// High Priority Thread
	while(!(pCommsengine->HasExited()))
	{
		// If there is a queued message to send do so
		if (pos->second.m_TxQueue.PopElement(Mess))
		{
			pCommsengine->SendMessage(Mess.m_pMess, Mess.m_Length);
		}
		// Check for and Queue Received Message
		Len=BUFSIZE;
		if (pCommsengine->ReceiveMessage(Mess.m_pMess, Len)) // Get Reply
		{
			Mess.m_Length = Len;
			pos->second.m_RxQueue.PushElement(Mess);
			SetEvent(pos->second.m_hQueueEvent);
			Len=BUFSIZE;
		}
	}
	
	return 0;
}

DWORD WINAPI USBClientIntFast(LPVOID pParam)
{
	CommsMessage Mess;
	Digi04MkIICommsEngineHostUSB *pCommsengine = (Digi04MkIICommsEngineHostUSB *)pParam;
	USBDevMap_t::iterator pos = USBDevMap.find(pCommsengine->m_szFilename);
	if (pos == USBDevMap.end())
	{
		return 0;
	}

	DWORD Len;

	// High Priority Thread
	while(!(pCommsengine->HasExited()))
	{
		// Check for and Queue Received Message
		Len=BUFSIZE;
		if (pCommsengine->ReceiveIntMessage(Mess.m_pMess, Len)) // Get Reply
		{
			Mess.m_Length = Len;
			pos->second.m_RxIntQueue.PushElement(Mess);
			SetEvent(pos->second.m_hQueueEvent);
			Len=BUFSIZE;
		}
	}
	
	return 0;
}

#else
int TCPClient(char *szTCPIPAddr, int Port)
{
	SOCKET *pConnectSoc = new SOCKET; 
	*pConnectSoc = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (*pConnectSoc == INVALID_SOCKET)
	{
		 int err = WSAGetLastError();
		 printf("\tFailed to create socket, err=%d\n", err);
		 WSACleanup();
		 return 1;
	}

	sockaddr_in service;
	service.sin_family = AF_INET;
	service.sin_addr.s_addr = inet_addr("127.0.0.1");
	service.sin_port = htons(51148);

	if (connect(*pConnectSoc, (sockaddr *)&service, sizeof(service)) == SOCKET_ERROR) 
	{
		printf("connect() failed.\n");
		closesocket(*pConnectSoc);
		WSACleanup();
		return 1;
	}
	printf("Connected to Device\n");

	{
		Digi04MkIICommsEngineHostEther commsengine(pConnectSoc);
		// Do Something ...
		// Send Initialize Message to kick off
		SleepEx(3000, TRUE);
		BYTE Mess[BUFSIZE];
		commsengine.EncodeMessage(Digi04MkIICommsDevice::INITIALIZE, 0, 0, Mess, 3); // Initialize
		commsengine.ReceiveMessage(Mess, 8); // Get Reply
		SleepEx(3000, TRUE);
		commsengine.EncodeMessage(Digi04MkIICommsDevice::CONFIG, Digi04MkIICommsDevice::FirmwareVersion, 0, Mess, 8); // Query Firmware version
		commsengine.ReceiveMessage(Mess, 8); // Get Reply

		SleepEx(3000, TRUE);
	   // Close Host prior to closing WinSock
	}
	return 0;
}

void UDPClient(int Port)
{
}
#endif

#endif

char * GetNetworkInfo(char *szAddress)
{
    SOCKET sd = WSASocket(AF_INET, SOCK_DGRAM, 0, 0, 0, 0);
    if (sd == SOCKET_ERROR) 
	{
        printf("Failed to get a socket. Error %d\n", WSAGetLastError()); 
		return "";
    }

    INTERFACE_INFO InterfaceList[20];
    unsigned long nBytesReturned;
    if (WSAIoctl(sd, SIO_GET_INTERFACE_LIST, 0, 0, &InterfaceList,
			sizeof(InterfaceList), &nBytesReturned, 0, 0) == SOCKET_ERROR) 
	{
        printf("Failed calling WSAIoctl: error %d\n", WSAGetLastError());
		return "";
    }

	bool bFound=false;
    int nNumInterfaces = nBytesReturned / sizeof(INTERFACE_INFO);
    for (int i = 0; i < nNumInterfaces; ++i) 
	{

        sockaddr_in *pAddress;
        pAddress = (sockaddr_in *) & (InterfaceList[i].iiAddress);
		if (strcmp(szAddress, inet_ntoa(pAddress->sin_addr)) == 0)
		{
			bFound=true;
		}

        pAddress = (sockaddr_in *) & (InterfaceList[i].iiNetmask);
		if (bFound)
		{
			return inet_ntoa(pAddress->sin_addr);
		}
    }

    return "";
}

// Use DLLMain in real version
//int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
int main(int argc, char **argv)
{
	HINSTANCE hInstance = GetModuleHandle(NULL);
#ifdef WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) 
	{
        printf("WSAStartup failed: %d\n", iResult);
        exit(1);
    }
#endif

	char szHost[256];
	if (gethostname(szHost, 255) == 0)
	{
		printf("Hostname = '%s'\n", szHost);
		struct addrinfo hint;
		struct addrinfo *addrlist=NULL;
		memset(&hint, 0, sizeof(hint));
		hint.ai_family = AF_INET;
		hint.ai_socktype = SOCK_STREAM;
		hint.ai_protocol = IPPROTO_TCP;

		if (getaddrinfo(szHost, "", &hint, &addrlist) == 0)
		{
			struct addrinfo *list = addrlist;
			while (list != NULL)
			{
				printf("\tAddr='%s'\n", inet_ntoa(((struct sockaddr_in *)list->ai_addr)->sin_addr));
				char * netmask = GetNetworkInfo(inet_ntoa(((struct sockaddr_in *)list->ai_addr)->sin_addr));
				printf("\tNetmask='%s'\n", netmask);
				unsigned long nmask = inet_addr(netmask);
				in_addr b;
				b.S_un.S_addr = ((struct sockaddr_in *)list->ai_addr)->sin_addr.S_un.S_addr;
				nmask = ~nmask;
				b.S_un.S_addr = b.S_un.S_addr | nmask;
				printf("\tBroadcast='%s'\n", inet_ntoa(b));
				
				list= list->ai_next;
				break;
			}
			freeaddrinfo(addrlist);
		}
	}

#ifdef HOST
	
#ifdef USB
	HANDLE hUSBDetectThread;
	hUSBDetectThread = CreateThread(0, 0, USBDetectThread, &hInstance , 0, 0);
	WaitForMultipleObjects(1, &hUSBDetectThread, TRUE, INFINITE);
#else
	TCPClient("127.0.0.1", 51148);
#endif

#else

	HANDLE hServers[2];
	hServers[0] = CreateThread(0, 0, TCPServerThread, NULL , 0, 0);

	hServers[1] = CreateThread(0, 0, UDPServerThread, NULL, 0, 0);

	WaitForMultipleObjects(2, hServers, TRUE, INFINITE);
	
#endif

#ifdef WIN32
	//RegisterDeviceNotification
	WSACleanup();
#endif

	return 0;
}

/* WinPcap structures for replaying wireshark capture 
typedef struct pcap_hdr_s {
        uint32 magic_number;   // magic number 
        uint16 version_major;  // major version number 
        uint16 version_minor;  // minor version number 
        int  thiszone;       // GMT to local correction 
        uint32 sigfigs;        // accuracy of timestamps 
        uint32 snaplen;        // max length of captured packets, in octets 
        uint32 network;        // data link type 
} pcap_hdr_t;
followed by

one or more
typedef struct pcaprec_hdr_s {
        uint32 ts_sec;         // timestamp seconds 
        uint32 ts_usec;        // timestamp microseconds 
        uint32 incl_len;       // number of octets of packet saved in file 
        uint32 orig_len;       // actual length of packet 
} pcaprec_hdr_t;

each followed by ethernet packet, packets may be short if incl_len != orig_len
*/