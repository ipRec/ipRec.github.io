// Digi04MkIICommsHost.cpp :
//
#ifndef _Digi04MkIICommsHost_h_Included
#define _Digi04MkIICommsHost_h_Included

#ifdef WIN32
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#pragma warning (disable:4100)
#include <stdio.h>
#include <string.h>
#include <windows.h>
typedef DWORD64 QWORD;
#else
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint64_t QWORD;
typedef uint32_t DWORD;
typedef uint16_t WORD;
typedef unsigned char BYTE;
#endif

#ifndef DIAG
#define DIAG 1
#endif


// Run on Host PC
class Digi04MkIICommsHost
{
public:
	enum {INITIALIZE=0, CONFIG=1, FIRMWARE=2, QUERYDCHANCONF=3, SETDCHANCONF=4, QUERYBCHANCONF=5, SETBCHANCONF=6, SDCARD=7, BCHANDATA=8, DCHANDATA=9, DCHANEVENT=10, DEBUGDATA=11, ERRORMESS=63 };
	enum {FirmwareVersion=0, FPGAHardwareType=1, FPGAProgramVersion=2, FPGAProgramType=3, SerialNumber=4, DaughterCards=5, RTC=6, MacAddress=7, TCPListenPort=8, 
	IPv4Address=9, IPv4Gateway=10, IPv4DNSServer=11, IPv6Address=12, IPv6Gateway=13, IPv6DNSServer=14, OperationMode=15, DiagnosticLevel=16, RunningServices=17, 
	LCDMessage=18, EnableLine=19, NoChannels=20, XTREncryption=21, SSLEncryption=22, TCPHosts=23, SMTPServer=24, SMTPLogin=25, SMTPPassword=26, SMTPDestAddr=27, 
	SNTPHostname=28, SNTPPollInterval=29, MacAddressFilter=30, SIPPortFilter=31, SIPIPv4AddressFilter=32, SIPIPv6AddressFilter=33, VLANFilter=34, SIPURIFilter=35,
	RTPPortFilter=36, RTCPPortFilter=37, RTPIPv4AddressFilter=38, RTPIPv6AddressFilter=39, EthernetStatus=40};
	enum {FirmwareInit=0, FirmwareBlock=1, FirmwareComplete=2, FirmwareChecksum=3, FPGAInit=4, FPGABlock=5, FPGAComplete=6, FPGAChecksum=7, Reboot=8, ReadNVInit=9, ReadNVAck=10, ReadNVBlock=11, ReadNVComplete=12,
		WriteNVInit=13, WriteNVBlock=14, WriteNVComplete=15};
	enum {SDCopyToCardInit=0, SDCopyToCardLength=1, SDCopyToCardBlock=2, SDCopyToCardComplete=3, SDCopyFromCardInit=4, SDCopyFromCardBlock=5, SDDeleteFile=6, SDIsCardInserted=7, SDFreeSpace=8};
	enum {Query=0, Set=1};
	enum {ToKeySet=0, ToSwitch=1};

	Digi04MkIICommsHost();
	virtual ~Digi04MkIICommsHost();

	bool DecodeBlock(BYTE *pData, DWORD Length); // true=ok, false=error

	virtual bool SendMessage(BYTE *pData, DWORD Length)=0;
	virtual bool ReceiveMessage(BYTE *pData, DWORD &Length)=0;

	virtual bool GotInitialize(BYTE RebootReason, char *szBootLoaderVersion)=0;

	virtual bool GotQueryFwVersion(char *szFirmwareVersion)=0;
	virtual bool GotQueryFPGAHwType(char *szFPGAHwType)=0;
	virtual bool GotQueryFPGAProgVersion(char *szFPGAProgVersion)=0;
	virtual bool GotQueryFPGAProgType(char *szFPGAProgType)=0;
	virtual bool GotQuerySerialNumber(char *szSerialNumber)=0;
	virtual bool GotQueryDaughterCards(BYTE DaughterCards[4])=0;

	virtual bool GotSendFirmwareInit()=0;
	virtual bool GotSendFirmwareBlock(BYTE Flag)=0;
	virtual bool GotSendFirmwareComplete(BYTE Flag)=0;

	virtual bool GotRequestFwChecksum(DWORD Checksum)=0;

	virtual bool GotSendFPGAInit(void)=0;
	virtual bool GotSendFPGABlock(BYTE Flag)=0;
	virtual bool GotSendFPGAComplete(BYTE Flag)=0;

	virtual bool GotRequestFPGAChecksum(DWORD Checksum)=0;

	virtual bool GotReadNVRAMInit(DWORD Checksum)=0;
	virtual bool GotReadNVRAMBlock(DWORD Offset, BYTE *pData, int nBytes)=0;

	virtual bool GotWriteNVRAMInit(void)=0;
	virtual bool GotWriteNVRAMBlock(BYTE Flag)=0;
	virtual bool GotWriteNVRAMComplete(BYTE Status)=0;

	//virtual bool GotRequestReboot(BYTE Reason)=0;

	virtual bool GotQueryRTC(char *szTime)=0;
	virtual bool GotSetRTC(BYTE Flag)=0;

	// IP Parameters
	virtual bool GotQueryMACAddress(BYTE MacAddress[8], int Length)=0;
	virtual bool GotSetMACAddress(BYTE Flag)=0;
	virtual bool GotQueryTCPListenPort(WORD Port)=0;
	virtual bool GotSetTCPListenPort(BYTE Flag)=0;
	virtual bool GotQueryEthernetStatus(BYTE Port, BYTE Status)=0;

	// IPv4 Parameters
	virtual bool GotQueryIPv4Address(BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetIPv4Address(BYTE Flag)=0; 
	virtual bool GotQueryIPv4Gateway(BYTE IPAddr[4])=0;
	virtual bool GotSetIPv4Gateway(BYTE Flag)=0; 
	virtual bool GotQueryIPv4DNSServer(BYTE IPAddr[4])=0;
	virtual bool GotSetIPv4DNSServer(BYTE Flag)=0; 

	// IPv6 Parameters
	virtual bool GotQueryIPv6Address(BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetIPv6Address(BYTE Flag)=0; 
	virtual bool GotQueryIPv6Gateway(BYTE IPAddr[16])=0;
	virtual bool GotSetIPv6Gateway(BYTE Flag)=0; 
	virtual bool GotQueryIPv6DNSServer(BYTE IPAddr[16])=0;
	virtual bool GotSetIPv6DNSServer(BYTE Flag)=0; 

	virtual bool GotQueryOperationMode(BYTE Flag)=0;
	virtual bool GotSetOperationMode(BYTE Flag)=0;

	virtual bool GotQueryDiagLevel(BYTE Level)=0;
	virtual bool GotSetDiagLevel(BYTE Flag)=0;

	virtual bool GotQueryRunningServices(BYTE Services)=0;
	virtual bool GotSetRunningServices(BYTE Flag)=0;

	virtual bool GotQueryDChannelStatus(BYTE Channel, BYTE Status)=0;
	virtual bool GotSetDChannelStatus(BYTE Channel, BYTE Flag)=0;

	virtual bool GotQueryBChannelStatus(BYTE Channel, BYTE Status)=0;
	virtual bool GotSetBChannelStatus(BYTE Channel, BYTE Flag)=0;

	virtual bool GotSetLCDMessage(BYTE Flag)=0;

	virtual bool GotQueryLineStatus(BYTE Enabled)=0;
	virtual bool GotSetLineStatus(BYTE Flag)=0;

	// SD Card Functions
	virtual bool GotCopyFileToSDCard(BYTE Flag)=0;
	virtual bool GotCopyFileToSDCardLen(BYTE Flag)=0;
	virtual bool GotCopyFileToSDCardBlock(BYTE Flag)=0;
	virtual bool GotCopyFileToSDCardComplete(BYTE Flag)=0;

	virtual bool GotCopyFileFromSDCard(BYTE Flag, QWORD Length)=0;
	virtual bool GotCopyFileFromSDCardBlock(QWORD Offset, BYTE Data[512])=0;

	virtual bool GotDeleteFileFromSDCard(BYTE Flag)=0;
	virtual bool GotIsSDCardInserted(BYTE Flag)=0;
	virtual bool GotQuerySDCardFreeSpace(QWORD FreeSpace)=0;

	virtual bool GotBChannelData(BYTE Channel, WORD Length, BYTE *pData, int Extended)=0;
	virtual bool GotDChannelData(BYTE Channel, WORD Length, BYTE *pData, int Extended)=0;
	virtual bool GotDChannelEvent(BYTE Channel, BYTE Event, char *szInfo)=0;
	virtual bool GotDebugData(BYTE Channel, WORD Length, BYTE *pData)=0;

	virtual bool GotQueryChannels(BYTE nChannels)=0;

	virtual bool GotSetXTREncryption(BYTE Flag)=0;
	virtual bool GotSetSSLEncryption(BYTE Flag)=0;
	virtual bool GotQueryAllowedHosts(char *szHostname)=0;
	virtual bool GotSetAllowedHosts(BYTE Flag)=0;

	// SMTP
	virtual bool GotQuerySMTPServer(WORD ServerPort, char *szServerName)=0;
	virtual bool GotSetSMTPServer(BYTE Flag)=0;
	virtual bool GotQuerySMTPLoginName(char *szLoginName)=0;
	virtual bool GotSetSMTPLoginName(BYTE Flag)=0;
	virtual bool GotQuerySMTPLoginPassword(char *szPassword)=0;
	virtual bool GotSetSMTPLoginPassword(BYTE Flag)=0;
	virtual bool GotQuerySMTPAddress(char *szAddress)=0;
	virtual bool GotSetSMTPAddress(BYTE Flag)=0;


	// SNTP
	virtual bool GotQuerySNTPHostname(char *szHostname)=0;
	virtual bool GotSetSNTPHostname(BYTE Flag)=0;
	virtual bool GotQuerySNTPPollInterval(WORD Interval)=0;
	virtual bool GotSetSNTPPollInterval(BYTE Flag)=0;

	// IPTAP Specific Parameters
	virtual bool GotQueryMACAddressFilter(BYTE Port, BYTE MacAddress[8], int Length)=0;
	virtual bool GotSetMACAddressFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQuerySIPPortFilter(BYTE Port, WORD SIPPort)=0;
	virtual bool GotSetSIPPortFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQuerySIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetSIPIPv4AddressFilter(BYTE Port, BYTE Flag)=0; 
	virtual bool GotQuerySIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetSIPIPv6AddressFilter(BYTE Port, BYTE Flag)=0; 
	virtual bool GotQueryVLANFilter(BYTE Port, WORD VLAN)=0;
	virtual bool GotSetVLANFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQuerySIPURIFilter(BYTE Port, char *szSIPURI)=0;
	virtual bool GotSetSIPURIFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQueryRTPPortFilter(BYTE Port, WORD RTPPort)=0;
	virtual bool GotSetRTPPortFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQueryRTCPPortFilter(BYTE Port, WORD RTCPPort)=0;
	virtual bool GotSetRTCPPortFilter(BYTE Port, BYTE Flag)=0;
	virtual bool GotQueryRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetRTPIPv4AddressFilter(BYTE Port, BYTE Flag)=0; 
	virtual bool GotQueryRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17])=0; // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetRTPIPv6AddressFilter(BYTE Port, BYTE Flag)=0; 

#ifdef DIAG
	FILE *hDiag;
#endif
};

#endif