// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS 1
#pragma warning (disable:4100)
#endif

#include <string.h>
#include "ProtocolTest.h"


