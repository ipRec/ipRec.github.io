#include "Digi04MkIICommsHost.h"


Digi04MkIICommsHost::Digi04MkIICommsHost()
{
#ifdef DIAG
	hDiag = fopen("hostdiag.txt", "w");
	//hDiag = stdout;
#endif
}

Digi04MkIICommsHost::~Digi04MkIICommsHost()
{
#ifdef DIAG
	if (hDiag != NULL)
	{
		fclose(hDiag);
		hDiag=NULL;
	}
#endif
}

bool Digi04MkIICommsHost::DecodeBlock(BYTE *pAllData, DWORD Length)
{
	if ((pAllData == NULL) || (Length < 3))
	{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Invalid block, pAllData=%p, MessageLen=%d\n", pAllData, Length);
#endif
		return false;
	}
	int StartPos=0;
	BYTE *pData = pAllData;
	int MessageType = pData[0] & 0x3f; 
	int MessageLen = ((pData[0] & 0xC0)<<2) | pData[1];
	BYTE Channel = pData[2] & 0x3f;
	int Direction = (pData[2] & 0x80) >> 7;
	int Extended = (pData[2] & 0x40) >> 6;
	int Set=Direction;
	bool bRes=false;

	do
	{
		if ((MessageLen > Length) && (Extended == 0))
		{
	#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Short Message, MessageLength=%d, PacketLength=%d\n", MessageLen,  Length);
	#endif
		}
		if ((StartPos+MessageLen) < Length)
		{
	#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Block with multiple messages, StartPos=%d, Buffer Len=%d, Mess Len=%d\n", StartPos, Length, MessageLen);
	#endif
		}

		if (Extended)
		{
	#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Extended block\n");
	#endif
		}

		switch (MessageType)
		{
		case INITIALIZE:
			if (MessageLen == 9)
			{
				char szBootLoaderVer[6];
				strncpy(szBootLoaderVer, (const char *)&(pData[4]), MessageLen-4);
				szBootLoaderVer[MessageLen-4] = '\0';
				bRes = GotInitialize(pData[3], szBootLoaderVer);
			}
			break;
		case CONFIG:
			switch (Channel)
			{
			case FirmwareVersion:
				if (MessageLen == 8)
				{
					char szFirmwareVer[6];
					strncpy(szFirmwareVer, (const char *)&(pData[3]), MessageLen-3);
					szFirmwareVer[MessageLen-3] = '\0';
					bRes = GotQueryFwVersion(szFirmwareVer);
				}
				break;
			case FPGAHardwareType:
				if (MessageLen >= 4)
				{
					char *szFPGAHwType = (char *)malloc(MessageLen-3+1);
					if (szFPGAHwType != NULL)
					{
						strncpy(szFPGAHwType, (const char *)&(pData[3]), MessageLen-3);
						szFPGAHwType[MessageLen-3] = '\0';
						bRes = GotQueryFPGAHwType(szFPGAHwType); 
						free(szFPGAHwType);
					}
				}
				break;
			case FPGAProgramVersion:
				if (MessageLen == 8)
				{
					char szFPGAVer[6];
					strncpy(szFPGAVer, (const char *)&(pData[3]), MessageLen-3);
					szFPGAVer[MessageLen-3] = '\0';
					bRes = GotQueryFPGAProgVersion(szFPGAVer);
				}
				break;
			case FPGAProgramType:
				if (MessageLen == 8)
				{
					char szFPGAType[6];
					strncpy(szFPGAType, (const char *)&(pData[3]), MessageLen-3);
					szFPGAType[MessageLen-3] = '\0';
					bRes = GotQueryFPGAProgType(szFPGAType);
				}
				break;
			case SerialNumber:
				if (MessageLen == 13)
				{
					char szSerialNo[11];
					strncpy(szSerialNo, (const char *)&(pData[3]), MessageLen-3);
					szSerialNo[MessageLen-3] = '\0';
					bRes = GotQuerySerialNumber(szSerialNo);
				}
				break;
			case DaughterCards:
				if (MessageLen == 7)
					{
						BYTE Cards[4];
						memcpy(Cards, &(pData[3]), MessageLen-3);
						bRes = GotQueryDaughterCards(Cards); 
					}
				break;
			case RTC:
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetRTC(pData[3]);
					}		
				} else 
				{
					if (MessageLen == 17)
					{
						char szMessage[15];
						strncpy(szMessage, (const char *)&(pData[3]), 14);
						szMessage[14] = '\0';
						bRes = GotQueryRTC(szMessage); 
					}
				}
				break;
			case MacAddress:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetMACAddress(pData[3]);
					}
				} else 
				{
					if ((MessageLen == 9) || (MessageLen == 11))
					{
						BYTE MacAddr[8];
						memcpy(MacAddr, &(pData[3]), MessageLen-3);
						bRes = GotQueryMACAddress(MacAddr, MessageLen-3); 
					}
				}
				break;
			case TCPListenPort:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetTCPListenPort(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 5)
					{
						WORD Port;
						memcpy(&Port, &(pData[3]), sizeof(WORD));
						bRes = GotQueryTCPListenPort(Port);
					}
				}
				break;
			case EthernetStatus:
				if (Set) 
				{
				} else 
				{
					if (MessageLen == 5)
					{
						bRes = GotQueryEthernetStatus(pData[3], pData[4]); 
					}
				}
				break;
			case IPv4Address:
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv4Address(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 8)
					{
						BYTE IP[5];
						memcpy(IP, &(pData[3]), 5);
						bRes = GotQueryIPv4Address(IP); 
					}
				}
				break;
			case IPv4Gateway:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv4Gateway(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 7)
					{
						BYTE GW[4];
						memcpy(GW, &(pData[3]), 4);
						bRes = GotQueryIPv4Gateway(GW); 
					}
				}
				break;
			case IPv4DNSServer:
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv4DNSServer(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 7)
					{
						BYTE DNS[4];
						memcpy(DNS, &(pData[3]), 4);
						bRes = GotQueryIPv4DNSServer(DNS); 
					}
				}
				break;
			case IPv6Address:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv6Address(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 20)
					{
						BYTE IP[17];
						memcpy(IP, &(pData[3]), 17);
						bRes = GotQueryIPv6Address(IP); 
					}
				}
				break;
			case IPv6Gateway:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv6Gateway(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 19)
					{
						BYTE IP[16];
						memcpy(IP, &(pData[3]), 16);
						bRes = GotQueryIPv6Gateway(IP); 
					}
				}
				break;
			case IPv6DNSServer:
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetIPv6DNSServer(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 19)
					{
						BYTE IP[16];
						memcpy(IP, &(pData[3]), 16);
						bRes = GotQueryIPv6DNSServer(IP); 
					}
				}
				break;
			case OperationMode:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetOperationMode(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 4)
					{
						bRes = GotQueryOperationMode(pData[3]); 
					}
				}
				break;
			case DiagnosticLevel:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetDiagLevel(pData[3]); 
					}
				} else
				{
					if (MessageLen == 4)
					{
						bRes = GotQueryDiagLevel(pData[3]); 
					}
				}
				break;
			case RunningServices:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetRunningServices(pData[3]); 
					}
				} else 
				{
					if (MessageLen == 4)
					{
						bRes = GotQueryRunningServices(pData[3]);
					}
				}
				break;
			case LCDMessage:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetLCDMessage(pData[3]); 
					}
				}
				break;
			case EnableLine:
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetLineStatus(pData[3]);
					}
				} else 
				{
					if (MessageLen == 4)
					{
						bRes = GotQueryLineStatus(pData[3]);
					}
				}
				break;
			case NoChannels:
				if (Set==0)
				{
					if (MessageLen == 4)
					{
						bRes = GotQueryChannels(pData[3]);
					}
				}
				break;
			case XTREncryption:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetXTREncryption(pData[3]); 
					}
				}
				break;
			case SSLEncryption:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSSLEncryption(pData[3]); 
					}
				}
				break;
			case TCPHosts:
				if (Set) 
				{
					if (MessageLen == 4)
					{			
						bRes = GotSetAllowedHosts(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szHostname = (char *)malloc(MessageLen-3+1);
						if (szHostname != NULL)
						{
							strncpy(szHostname, (const char *)&(pData[3]), MessageLen-3);
							szHostname[MessageLen-3] = '\0';
							bRes = GotQueryAllowedHosts(szHostname); 
							free(szHostname);
						}
					}
				}
				break;
			case SMTPServer:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSMTPServer(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 5)
					{
						char *szHostname = (char *)malloc(MessageLen-5+1);
						if (szHostname != NULL)
						{
							WORD Port;
							memcpy(&Port, &(pData[3]), sizeof(WORD));
							strncpy(szHostname, (const char *)&(pData[5]), MessageLen-5);
							szHostname[MessageLen-5] = '\0';
							bRes = GotQuerySMTPServer(Port, szHostname); 
							free(szHostname);
						}
					}
				}
				break;
			case SMTPLogin: 
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSMTPLoginName(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szLogin = (char *)malloc(MessageLen-3+1);
						if (szLogin != NULL)
						{
							strncpy(szLogin, (const char *)&(pData[3]), MessageLen-3);
							szLogin[MessageLen-3] = '\0';
							bRes = GotQuerySMTPLoginName(szLogin); 
							free(szLogin);
						}
					}
				}
				break;
			case SMTPPassword: 
				if (Set)
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSMTPLoginPassword(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szPassword = (char *)malloc(MessageLen-3+1);
						if (szPassword != NULL)
						{
							strncpy(szPassword, (const char *)&(pData[3]), MessageLen-3);
							szPassword[MessageLen-3] = '\0';
							bRes = GotQuerySMTPLoginPassword(szPassword); 
							free(szPassword);
						}
					}
				}
				break;
			case SMTPDestAddr:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSMTPAddress(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szAddress = (char *)malloc(MessageLen-3+1);
						if (szAddress != NULL)
						{
							strncpy(szAddress, (const char *)&(pData[3]), MessageLen-3);
							szAddress[MessageLen-3] = '\0';
							bRes = GotQuerySMTPAddress(szAddress); 
							free(szAddress);
						}
					}
				}
				break;
			case SNTPHostname:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSNTPHostname(pData[3]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szAddress = (char *)malloc(MessageLen-3+1);
						if (szAddress != NULL)
						{
							strncpy(szAddress, (const char *)&(pData[3]), MessageLen-3);
							szAddress[MessageLen-3] = '\0';
							bRes = GotQuerySNTPHostname(szAddress); 
							free(szAddress);
						}
					}
				}
				break;
			case SNTPPollInterval:
				if (Set) 
				{
					if (MessageLen == 4)
					{
						bRes = GotSetSNTPPollInterval(pData[3]);
					}
				} else
				{
					if (MessageLen == 5)
					{
						WORD Interval;
						memcpy(&Interval, &(pData[3]), sizeof(WORD));
						bRes = GotQuerySNTPPollInterval(Interval);
					}
				}
				break;
			case MacAddressFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetMACAddressFilter(pData[3], pData[4]);
					}
				} else 
				{
					if ((MessageLen == 10) || (MessageLen == 12))
					{
						BYTE MacAddr[8];
						memcpy(MacAddr, &(pData[4]), MessageLen-4);
						bRes = GotQueryMACAddressFilter(pData[3], MacAddr, MessageLen-3); 
					}
				}
				break;
			case SIPPortFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetSIPPortFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 6)
					{
						WORD SIPPort;
						memcpy(&SIPPort, &(pData[4]), sizeof(WORD));
						bRes = GotQuerySIPPortFilter(pData[3], SIPPort);
					}
				}
				break;
			case SIPIPv4AddressFilter:
				if (Set)
				{
					if (MessageLen == 5)
					{
						bRes = GotSetSIPIPv4AddressFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 9)
					{
						BYTE IP[5];
						memcpy(IP, &(pData[4]), 5);
						bRes = GotQuerySIPIPv4AddressFilter(pData[3], IP); 
					}
				}
				break;
			case SIPIPv6AddressFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetSIPIPv6AddressFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 21)
					{
						BYTE IP[17];
						memcpy(IP, &(pData[4]), 17);
						bRes = GotQuerySIPIPv6AddressFilter(pData[3], IP); 
					}
				}
				break;
			case VLANFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetVLANFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 6)
					{
						WORD TCPPort;
						memcpy(&TCPPort, &(pData[4]), sizeof(WORD));
						bRes = GotQueryVLANFilter(pData[3], pData[4]);
					}
				}
				break;
			case SIPURIFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetSIPURIFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen >= 4)
					{
						char *szSIPFilter = (char *)malloc(MessageLen-4+1);
						if (szSIPFilter != NULL)
						{
							strncpy(szSIPFilter, (const char *)&(pData[4]), MessageLen-4);
							szSIPFilter[MessageLen-4] = '\0';
							bRes = GotQuerySIPURIFilter(pData[3], szSIPFilter); 
							free(szSIPFilter);
						}
					}
				}
				break;
				case RTPPortFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetRTPPortFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 6)
					{
						WORD RTPPort;
						memcpy(&RTPPort, &(pData[4]), sizeof(WORD));
						bRes = GotQueryRTPPortFilter(pData[3], RTPPort);
					}
				}
				break;
				case RTCPPortFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetRTCPPortFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 6)
					{
						WORD RTCPPort;
						memcpy(&RTCPPort, &(pData[4]), sizeof(WORD));
						bRes = GotQueryRTCPPortFilter(pData[3], RTCPPort);
					}
				}
				break;
			case RTPIPv4AddressFilter:
				if (Set)
				{
					if (MessageLen == 5)
					{
						bRes = GotSetRTPIPv4AddressFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 9)
					{
						BYTE IP[5];
						memcpy(IP, &(pData[4]), 5);
						bRes = GotQueryRTPIPv4AddressFilter(pData[3], IP); 
					}
				}
				break;
			case RTPIPv6AddressFilter:
				if (Set) 
				{
					if (MessageLen == 5)
					{
						bRes = GotSetRTPIPv6AddressFilter(pData[3], pData[4]); 
					}
				} else 
				{
					if (MessageLen == 21)
					{
						BYTE IP[17];
						memcpy(IP, &(pData[4]), 17);
						bRes = GotQueryRTPIPv6AddressFilter(pData[3], IP); 
					}
				}
				break;
			default:
				break;
			}
			break;
		case FIRMWARE:
			switch (Channel)
			{
				case FirmwareInit:
					bRes = GotSendFirmwareInit();
					break;
				case FirmwareBlock: 
					if (MessageLen == 4)
					{
						bRes = GotSendFirmwareBlock(pData[3]);
					}
					break;
				case FirmwareComplete:
					if (MessageLen == 4)
					{
						bRes = GotSendFirmwareComplete(pData[3]);
					}
				case FirmwareChecksum: 
					if (MessageLen == 7)
					{
						DWORD Len;
						memcpy(&Len, &(pData[3]), sizeof(DWORD));
						bRes = GotRequestFwChecksum(Len);
					}
					break;
				case FPGAInit:
					bRes = GotSendFPGAInit();
					break;
				case FPGABlock: 
					if (MessageLen == 4)
					{
						bRes = GotSendFPGABlock(pData[3]);
					}
					break;
				case FPGAChecksum: 
					if (MessageLen == 7)
					{
						DWORD Len;
						memcpy(&Len, &(pData[3]), sizeof(DWORD));
						bRes = GotRequestFPGAChecksum(Len);
					}
					break;
				case Reboot:
					break;
				case ReadNVInit:
					if (MessageLen == 7)
					{
						DWORD CheckSum;
						memcpy(&CheckSum, &(pData[3]), sizeof(DWORD));
						bRes = GotReadNVRAMInit(CheckSum);
					}
					break;
				case ReadNVBlock:
					if (MessageLen > 8)
					{
						DWORD Offset;
						memcpy(&Offset, &(pData[4]), sizeof(DWORD));
						bRes = GotReadNVRAMBlock(Offset, &(pData[8]), MessageLen-8);
					}
					break;
				case WriteNVInit:
					if (MessageLen == 3)
					{
						bRes = GotWriteNVRAMInit();
					}
					break;
				case WriteNVBlock:
					if (MessageLen == 4)
					{
						bRes = GotWriteNVRAMBlock(pData[3]);
					}
					break;
				case WriteNVComplete:
					if (MessageLen == 4)
					{
						bRes = GotWriteNVRAMComplete(pData[3]);
					}
					break;
				default:
					break;
			}
			break;
		case QUERYDCHANCONF:
			if (MessageLen == 4)
			{
				bRes = GotQueryDChannelStatus(Channel, pData[3]);
			}
			break;
		case SETDCHANCONF:
			if (MessageLen == 4)
			{
				bRes = GotSetDChannelStatus(Channel, pData[3]);
			}
			break;
		case QUERYBCHANCONF:
			if (MessageLen == 4)
			{
				bRes = GotQueryBChannelStatus(Channel, pData[3]);
			}
			break;
		case SETBCHANCONF:
			if (MessageLen == 4)
			{
				bRes = GotSetBChannelStatus(Channel, pData[3]);
			}
			break;
		case SDCARD:
			switch (Channel)
			{
			case SDCopyToCardInit:
				if (MessageLen == 4)
				{
					bRes = GotCopyFileToSDCard(pData[3]); 
				}
				break;
			case SDCopyToCardLength:
				if (MessageLen == 4)
				{
					bRes = GotCopyFileToSDCardLen(pData[3]);
				}
				break;
			case SDCopyToCardBlock:
				if (MessageLen == 4)
				{
					bRes = GotCopyFileToSDCardBlock(pData[3]);
				}
				break;
			case SDCopyFromCardInit:
				if (MessageLen == 12)
				{
					QWORD Len;
					memcpy(&Len, &(pData[4]), sizeof(QWORD));
					bRes = GotCopyFileFromSDCard(pData[3], Len); 
				}
				break;
			case SDCopyFromCardBlock:
				if (MessageLen == 523)
				{
					QWORD Offset;
					BYTE Block[512];
					memcpy(&Offset, &(pData[3]), sizeof(QWORD));
					memcpy(Block, &(pData[11]), 512);
					bRes = GotCopyFileFromSDCardBlock(Offset, Block);
				}
				break;
			case SDDeleteFile:
				if (MessageLen == 4)
				{
					bRes = GotDeleteFileFromSDCard(pData[3]); 
				}
				break;
			case SDIsCardInserted:
				if (MessageLen == 4)
				{
					bRes = GotIsSDCardInserted(pData[3]);
				}
				break;
			case SDFreeSpace:
				if (MessageLen == 11)
				{
					QWORD FreeSpace;
					memcpy(&FreeSpace, &(pData[3]), sizeof(QWORD));
					bRes = GotQuerySDCardFreeSpace(FreeSpace);
				}
				break;
			default:
				break;
			}
			break;
		case BCHANDATA:
			bRes = GotBChannelData(Channel, (WORD)(MessageLen-3), &(pData[3]), Extended);	
			break;
		case DCHANDATA:
			bRes = GotDChannelData(Channel, (WORD)(MessageLen-3), &(pData[3]), Extended);
			break;
		case DCHANEVENT:
			if (MessageLen > 4)
			{
				char *szInfo = (char *)malloc(MessageLen-4+1);
				if (szInfo != NULL)
				{
					strncpy(szInfo, (const char *)&(pData[4]), MessageLen-4);
					szInfo[MessageLen-4] = '\0';
					bRes = GotDChannelEvent(Channel, pData[3], szInfo);
					free(szInfo);
				}
				
			}
			break;
		case DEBUGDATA:
			bRes = GotDebugData(Channel, (WORD)(MessageLen-3), &(pData[3]));
			break;
		case ERRORMESS:
	#ifdef DIAG
			if (hDiag != NULL)
			{
				fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Error Message\n");
			}
	#endif
			break;
		default:
			break;
		}
		if (!bRes)
		{
	#ifdef DIAG
			if (hDiag != NULL)
			{
				fprintf(hDiag, "Digi04MkIICommsHost::DecodeBlock: Error decoding block, MessageLen=%d:\n\t", MessageLen);
				for(int i=0; i<MessageLen; i++)
				{
					fprintf(hDiag, "%02x ", pData[i]);
					if ((i%16)==15)
					{
						fprintf(hDiag, "\n\t");
					}
				}
				fprintf(hDiag, "\n");
			}
	#endif
		}
		StartPos += MessageLen;
		if (StartPos < Length)
		{
			// Move on to next message
			pData += MessageLen;
			MessageType = pData[0] & 0x3f; 
			MessageLen = ((pData[0] & 0xC0)<<2) | pData[1];
			Channel = pData[2] & 0x3f;
			Direction = (pData[2] & 0x80) >> 7;
			Extended = (pData[2] & 0x40) >> 6;
			Set=Direction;
			bRes = false;
		}
	} while (StartPos < Length);

	return bRes;
}