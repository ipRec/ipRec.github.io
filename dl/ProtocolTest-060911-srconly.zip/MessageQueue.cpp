#include "MessageQueue.h"

#ifdef DIAG
extern FILE *hAppDiag;
#endif

CommsMessage::CommsMessage()
{
	m_Length=0;
}

CommsMessage::CommsMessage(const CommsMessage &other)
{
	m_Length = other.m_Length;
	memcpy(m_pMess, other.m_pMess, m_Length);
}

CommsMessage::CommsMessage(BYTE *pMess, unsigned int Length)
{
	m_Length = Length;
	memcpy(m_pMess, pMess, m_Length);
}

CommsMessage::~CommsMessage()
{
}

CommsMessage& CommsMessage::operator=(const CommsMessage& other)
{
	m_Length = other.m_Length;
	memcpy(m_pMess, other.m_pMess, m_Length);
	return *this;
}

MessageQueue::MessageQueue()
{
	m_MessageQueue.resize(m_Size);
	m_Read=0;
	m_Write=0;
}

MessageQueue::~MessageQueue()
{
	m_MessageQueue.clear();
}

MessageQueue::MessageQueue(const MessageQueue &other)
{
	m_MessageQueue = other.m_MessageQueue;
	m_Read = other.m_Read;
	m_Write = other.m_Write;
}

MessageQueue& MessageQueue::operator=(const MessageQueue& other)
{
	m_MessageQueue = other.m_MessageQueue;
	m_Read = other.m_Read;
	m_Write = other.m_Write;
	return *this;
}

bool MessageQueue::PushElement(const CommsMessage &Element)
{
	int nextElement = (m_Write + 1) % m_Size;
	if(nextElement != m_Read) 
	{
		m_MessageQueue[m_Write] = Element;
		m_Write = nextElement;
		return true;
	}
	else
	{
#ifdef DIAG
		if (hAppDiag != NULL) fprintf(hAppDiag, "MessageQueue::PushElement Queue Full\n");
#endif
		return false;
	}
}

bool MessageQueue::PopElement(CommsMessage &Element)
{
	if(m_Read == m_Write)
		return false;

	int nextElement = (m_Read + 1) % m_Size;

	Element = m_MessageQueue[m_Read];
	m_Read = nextElement;
	return true;
}
