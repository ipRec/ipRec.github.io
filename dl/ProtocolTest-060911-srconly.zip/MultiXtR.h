//
// FILENAME: MultiXtR.h
// PROJECT:  Xtension Recorder (All variants)
//
// PURPOSE:
//	This file is the include file specifying the interface for 
// the Xtension recorder Multiple interface software library.
//
// Copyright 2010 Intelligent Recording Ltd. Worksop. UK.
// www.usbcallrecord.com
//
// HISTORY:
// 03-Nov-2003	Nigel Gaunt		File created.
// 30-Mar-2004	Nigel Gaunt		Separate audio gains
// 21-Sep-2004	Nigel Gaunt		Add NULL status return for Null devices
// 03-Aug-2010  Andrew Roberts  Added MP_GetCallInfo
// 09-Aug-2010  Andrew Roberts  Added MPC_ routines using Windows calling convention
//                              (extern "C" and __cdecl). The callback must be declared
//                              stdcall, when using the MPC_SetCallback function.
//

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the LOWLEVEL_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// LOWLEVEL_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
//
// NOTE for Non-MFC programmers.
// MULTIXTR_API functions are __cdecl.
// MULTIXTR_WINAPI functions are __cdecl.
#ifdef COMVURGENTTEST
#define	MULTIXTR_API
#else
#ifdef MULTIXTR_EXPORTS
#define MULTIXTR_API extern "C++" __declspec(dllexport) 
#define MULTIXTR_WINAPI extern "C" __declspec(dllexport) 
#else
#define MULTIXTR_API extern "C++" __declspec(dllimport)
#define MULTIXTR_WINAPI extern "C" __declspec(dllimport)
#endif
#endif

// Define standard types
#ifndef BOOLEAN
#define	BOOLEAN	int
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE	0
#endif

#ifndef STATUS_GOOD
// Possible Callback Events
#define	MP_STATUS					1
#define	MP_BCHANNELDATA				2
#define	MP_DCHANNELDATAPBX			3
#define MP_DCHANNELDATAPHONE		4
#define MP_BCHANNELOVERFLOW			5
#define MP_DCHANNELOVERFLOWPBX		6
#define MP_DCHANNELOVERFLOWPHONE	7
#define MP_CALLSTATE				8
#define MP_CALLERIDUPDATE			9
#define MP_UUIUPDATE			   10
#define MP_CALLEDPARTYIDUPDATE	   11
#define MP_CONNECTEDNODUPDATE	   12
#define MP_WARNING				   13
#define MP_RINGTIMEUPDATE		14
#define MP_ISDN_SETUP			15
#define MP_ISDN_ALERTING		16
#define MP_ISDN_CONNECT			17
#define MP_ISDN_DISCONNECT		18
#define MP_ISDN_CHANNELNO		19
#define MP_VOIP_TERMINAL_IP		20
#define MP_VOID_TERMINAL_URI	21
#define MP_VOIP_SESSION_ENCODING 22

// Possible status reports, either from GetStatus(), or a MP_STATUS callback
#define	STATUS_GOOD				 0		// Interface and telephone OK
#define STATUS_NOTPRESENT		-1		// Interface not connected
#define STATUS_UNLICENSED		-2		// The device is connected, but is for different keysets to the current software.
#define	STATUS_NOPHONE			-3		// Device present, Exchange detected, no response from phone
#define STATUS_NOEXCHANGE		-4		// Device present. Exchange not detected
#define STATUS_UNKNOWNERROR		-5		// Device present. No communication. Unable to determine if phone or exchange is at fault.
#define STATUS_NOTINITIALISED	-6		// You have not initialised the DLL
#define STATUS_INTERNALERROR	-7		// Failure during device initialisation
#define STATUS_TOOMANY			-8		// This device is connected, but cannot be used as there are too many devices connected
#define STATUS_NULLDEVICE		-9		// Using a NULL DLL. No devices possible
#define STATUS_HWFAILURE        -10      // A Hardware failure has been detected
// May also be 1-100, initialising %, will count up as the device initialises

// Possible call states. Either from GetCallState(), or MP_CALLSTATE callback
// The DLL will give you as much information as possible
// Please handle all of these, as different phone types will give different levels of information
#define	CALL_IDLE				0
#define CALL_ACTIVE				1
#define CALL_INCOMING			2
#define CALL_OUTGOING			3
#define CALL_INCOMING_INTERNAL	4
#define CALL_INCOMING_EXTERNAL	5
#define CALL_OUTGOING_INTERNAL	6
#define CALL_OUTGOING_EXTERNAL	7
#define CALL_PAGE				8
#define CALL_SILENCED           9

// Determine what information is required from the audio or auto-audio
// You can always ask for everything, but asking for less may reduce
// the bandwidth used by the USB device.
#define	AUDIO_OFF		0
#define	AUDIO_MONO		1
#define	AUDIO_STEREO	2
#define	AUDIO_ON		3
#define	AUDIO_MIC		4	// Record from separate mic (for UA)

// Determine what information is required from the MP_GetCallInfo
// routine.
#define INFO_CALLERID     0
#define INFO_UUI          1
#define INFO_CALLEDPARTY  2
#define INFO_CONNECTEDNO  3
#define INFO_WARNING 4
#define INFO_RINGTIME	  5
#define INFO_CHANNELNO    6
#define INFO_VOIP_TERM_IP 7
#define INFO_VOIP_TERM_URI 8
#define INFO_VOIP_SESS_ENC 9

// Typedef which may be used for callback functions
// Note for Non-MFC programmers.
// This function is __cdecl
typedef void MULTIXTRCALLBACK( int Port, int Event, int Data );
typedef void __stdcall MPC_MULTIXTRCALLBACK( int Port, int Event, int Data );
#endif

// Interface Functions
// See Comvurgent API specification for details

// Functions which affect the entire DLL
MULTIXTR_API	void	MP_Open( void );
MULTIXTR_API	void	MP_Close( void );
MULTIXTR_API	LPCSTR  MP_GetSwType( void );
MULTIXTR_API	LPCSTR  MP_GetSwVersion( void );
MULTIXTR_API	void	MP_SetCallback( MULTIXTRCALLBACK *MyProc );
MULTIXTR_API	int		MP_GetDataFormat( void );
MULTIXTR_API	short	MP_ConvertData( const char Data8bit );

// Functions to determine Port numbers of connected devices
MULTIXTR_API	int		MP_GetMaxNumPorts( void );
MULTIXTR_API	int		MP_GetIfSerialNo( int PortNumber );	// 0=No device

// Functions which affect a single connected port
MULTIXTR_API	int		MP_GetStatus( int Port );
MULTIXTR_API	int		MP_GetCallState( int Port );
MULTIXTR_API	LPCSTR	MP_GetIfType( int Port );
MULTIXTR_API	void	MP_SetAudioGain( int Port, BOOL Remote, int Gain );		// Gain = fixed point / 256
MULTIXTR_API	int		MP_GetAudioData( int Port, int MaxLength, char *pPBXData, char *pPhoneData, char *pMergedData );
MULTIXTR_API	void	MP_AudioMonitor( int Port, int Active );
MULTIXTR_API	void	MP_AutoRecord( int Port, int ActivateAutoRecord );

MULTIXTR_API	void	MP_ControlMonitor( int Port, BOOLEAN Active );
MULTIXTR_API	int		MP_GetControlDataPBX( int Port, int MaxLength, char *pPBXData);
MULTIXTR_API	int		MP_GetControlDataPhone( int Port, int MaxLength, char *pPhoneData);
MULTIXTR_API	LPCSTR	MP_GetCallerID( int Port );

// Functions which must be dynamically loaded to determine if they exist
MULTIXTR_API	LPCSTR	MP_GetCallInfo( int Port, int Info );
typedef LPCSTR	(*MP_GetCallInfo_t)( int Port, int Info );
MULTIXTR_API	LPCSTR  MP_GetHwVersion( int Port );
typedef LPCSTR	(*MP_GetHwVersion_t)( int Port );
MULTIXTR_API	LPCSTR  MP_GetConfigEntry( LPCSTR Key );
typedef LPCSTR	(*MP_GetConfigEntry_t)( LPCSTR Key );
MULTIXTR_API	int  MP_SetConfigEntry( LPCSTR Key, LPCSTR Value );
typedef int	(*MP_SetConfigEntry_t)( LPCSTR Key, LPCSTR Value );


// ********************************************
// Functions which only affect Analog recorders
// ********************************************

MULTIXTR_API void	MP_ControlAGC( int Port, int Active );
MULTIXTR_API void	MP_ControlSpeaker( int Port, int Active );
	
// Sets the MIC boost value 1 (TRUE) or 0 (FALSE)
MULTIXTR_API void    MP_SetMicLevelBoost(int Port, int OnOff);
	
// Sets the EAR boost value 1 (TRUE) or 0 (FALSE)
MULTIXTR_API void    MP_SetEarLevelBoost(int Port, int OnOff);
		
// Sets the start recording trigger threshold (voice trigger) value (range value)
MULTIXTR_API void    MP_SetStartThreshold(int Port, int Threshold);

MULTIXTR_API int     MP_GetMicLevelBoost(int Port);
MULTIXTR_API int     MP_GetEarLevelBoost(int Port);
MULTIXTR_API int     MP_GetStartThreshold(int Port);
MULTIXTR_API int     MP_GetIdleThreshold(int Port);
MULTIXTR_API int     MP_GetIdleTimeout(int Port);
MULTIXTR_API int     MP_GetMicTrigger(int Port);
MULTIXTR_API int     MP_GetEarTrigger(int Port);

// line mode - Set/Get Gain (0 to -79 dB) (only one gain control)
MULTIXTR_API void	MP_SetLineGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_API int	MP_GetLineGain (int Port);
	
// handset mode - Set/Get Gain (0 to -79 dB) (there are two gain control(ear and mic))
MULTIXTR_API void	MP_SetEarGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_API void	MP_SetMicGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_API int	MP_GetEarGain (int Port);
MULTIXTR_API int	MP_GetMicGain (int Port);
	
// Set/Get Playback Gain (0 to -79 dB)
MULTIXTR_API void	MP_SetPlaybackGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_API int	MP_GetPlaybackGain (int Port);
	
// Set/Get the Ear threshold (0 to -79 dB) 
MULTIXTR_API int	MP_GetEarThreshold (int Port);
	
// Set/Get the Mic threshold (0 to -79 dB)
MULTIXTR_API int	MP_GetMicThreshold (int Port);
	
	
// Get the detect Ear/Mic trigger (TRUE or FALSE)
MULTIXTR_API int	MP_GetDetectEarTrigger (int Port);
MULTIXTR_API int	MP_GetDetectMicTrigger (int Port);

MULTIXTR_API void	MP_SetMicTrigger(int Port, int OnOff, int Threshold); // Threshold = 0 to 79
MULTIXTR_API void	MP_SetEarTrigger(int Port, int OnOff, int Threshold); // Threshold = 0 to 79
MULTIXTR_API void	MP_SetIdle(int Port, int Timeout, int Threshold); // Threshold = 0 to 79

// *********************************************
// WINAPI Varients callable from other languages
// *********************************************

// Functions which affect the entire DLL
MULTIXTR_WINAPI	void	 MPC_Open( void );
MULTIXTR_WINAPI	void	 MPC_Close( void );
MULTIXTR_WINAPI	LPCSTR   MPC_GetSwType( void );
MULTIXTR_WINAPI	LPCSTR   MPC_GetSwVersion( void );
MULTIXTR_WINAPI	void	 MPC_SetCallback( MPC_MULTIXTRCALLBACK *MyProc );
MULTIXTR_WINAPI	int		 MPC_GetDataFormat( void );
MULTIXTR_WINAPI	short	 MPC_ConvertData( const char Data8bit );

// Functions to determine Port numbers of connected devices
MULTIXTR_WINAPI	int		 MPC_GetMaxNumPorts( void );
MULTIXTR_WINAPI	int		 MPC_GetIfSerialNo( int PortNumber );	// 0=No device

// Functions which affect a single connected port
MULTIXTR_WINAPI	int		 MPC_GetStatus( int Port );
MULTIXTR_WINAPI	int		 MPC_GetCallState( int Port );
MULTIXTR_WINAPI	LPCSTR	 MPC_GetIfType( int Port );
MULTIXTR_WINAPI	void	 MPC_SetAudioGain( int Port, BOOL Remote, int Gain );		// Gain = fixed point / 256
MULTIXTR_WINAPI	int		 MPC_GetAudioData( int Port, int MaxLength, char *pPBXData, char *pPhoneData, char *pMergedData );
MULTIXTR_WINAPI	void	 MPC_AudioMonitor( int Port, int Active );
MULTIXTR_WINAPI	void	 MPC_AutoRecord( int Port, int ActivateAutoRecord );

MULTIXTR_WINAPI	void	 MPC_ControlMonitor( int Port, BOOLEAN Active );
MULTIXTR_WINAPI	int		 MPC_GetControlDataPBX( int Port, int MaxLength, char *pPBXData);
MULTIXTR_WINAPI	int		 MPC_GetControlDataPhone( int Port, int MaxLength, char *pPhoneData);
MULTIXTR_WINAPI	LPCSTR	 MPC_GetCallerID( int Port );

// Functions which must be dynamically loaded to determine if they exist
MULTIXTR_WINAPI	LPCSTR	 MPC_GetCallInfo( int Port, int Info );
typedef LPCSTR (__stdcall *MPC_GetCallInfo_t)( int Port, int Info );
MULTIXTR_WINAPI	LPCSTR  MPC_GetHwVersion( int Port );
typedef LPCSTR (__stdcall *MPC_GetHwVersion_t)( int Port );

// ********************************************
// Functions which only affect Analog recorders
// ********************************************

MULTIXTR_WINAPI void	MPC_ControlAGC( int Port, int Active );
MULTIXTR_WINAPI void	MPC_ControlSpeaker( int Port, int Active );
	
// Sets the MIC boost value 1 (TRUE) or 0 (FALSE)
MULTIXTR_WINAPI void    MPC_SetMicLevelBoost(int Port, int OnOff);
	
// Sets the EAR boost value 1 (TRUE) or 0 (FALSE)
MULTIXTR_WINAPI void    MPC_SetEarLevelBoost(int Port, int OnOff);
		
// Sets the start recording trigger threshold (voice trigger) value (range value)
MULTIXTR_WINAPI void    MPC_SetStartThreshold(int Port, int Threshold);

MULTIXTR_WINAPI int     MPC_GetMicLevelBoost(int Port);
MULTIXTR_WINAPI int     MPC_GetEarLevelBoost(int Port);
MULTIXTR_WINAPI int     MPC_GetStartThreshold(int Port);
MULTIXTR_WINAPI int     MPC_GetIdleThreshold(int Port);
MULTIXTR_WINAPI int     MPC_GetIdleTimeout(int Port);
MULTIXTR_WINAPI int     MPC_GetMicTrigger(int Port);
MULTIXTR_WINAPI int     MPC_GetEarTrigger(int Port);

// line mode - Set/Get Gain (0 to -79 dB) (only one gain control)
MULTIXTR_WINAPI void	MPC_SetLineGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_WINAPI int		MPC_GetLineGain (int Port);
	
// handset mode - Set/Get Gain (0 to -79 dB) (there are two gain control(ear and mic))
MULTIXTR_WINAPI void	MPC_SetEarGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_WINAPI void	MPC_SetMicGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_WINAPI int		MPC_GetEarGain (int Port);
MULTIXTR_WINAPI int		MPC_GetMicGain (int Port);
	
// Set/Get Playback Gain (0 to -79 dB)
MULTIXTR_WINAPI void	MPC_SetPlaybackGain (int Port, int Gain); // Gain = 0 to 79
MULTIXTR_WINAPI int		MPC_GetPlaybackGain (int Port);
	
// Set/Get the Ear threshold (0 to -79 dB) 
MULTIXTR_WINAPI int		MPC_GetEarThreshold (int Port);
	
// Set/Get the Mic threshold (0 to -79 dB)
MULTIXTR_WINAPI int		MPC_GetMicThreshold (int Port);
	
	
// Get the detect Ear/Mic trigger (TRUE or FALSE)
MULTIXTR_WINAPI int		MPC_GetDetectEarTrigger (int Port);
MULTIXTR_WINAPI int		MPC_GetDetectMicTrigger (int Port);

MULTIXTR_WINAPI void	MPC_SetMicTrigger(int Port, int OnOff, int Threshold); // Threshold = 0 to 79
MULTIXTR_WINAPI void	MPC_SetEarTrigger(int Port, int OnOff, int Threshold); // Threshold = 0 to 79
MULTIXTR_WINAPI void	MPC_SetIdle(int Port, int Timeout, int Threshold); // Threshold = 0 to 79


