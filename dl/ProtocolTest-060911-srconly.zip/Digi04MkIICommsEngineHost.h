// ProtocolTest.cpp : Defines the entry point for the console application.
//
#ifndef _Digi04MkIICommsEngine_h_Included
#define _Digi04MkIICommsEngine_h_Included

#include <time.h>
#include "Digi04MkIICommsHost.h"

// Run on Host PC
class Digi04MkIICommsEngineHost : public Digi04MkIICommsHost
{
public:

	Digi04MkIICommsEngineHost();
	virtual ~Digi04MkIICommsEngineHost();

	virtual bool GotInitialize(BYTE RebootReason, char *szBootLoaderVersion);

	virtual bool GotQueryFwVersion(char *szFirmwareVersion);
	virtual bool GotQueryFPGAHwType(char *szFPGAHwType);
	virtual bool GotQueryFPGAProgVersion(char *szFPGAProgVersion);
	virtual bool GotQueryFPGAProgType(char *szFPGAProgType);
	virtual bool GotQuerySerialNumber(char *szSerialNumber);
	virtual bool GotQueryDaughterCards(BYTE DaughterCards[4]);

	virtual bool GotSendFirmwareInit();
	virtual bool GotSendFirmwareBlock(BYTE Flag);
	virtual bool GotSendFirmwareComplete(BYTE Flag);

	virtual bool GotRequestFwChecksum(DWORD Checksum);

	virtual bool GotSendFPGAInit(void);
	virtual bool GotSendFPGABlock(BYTE Flag);
	virtual bool GotSendFPGAComplete(BYTE Flag);

	virtual bool GotRequestFPGAChecksum(DWORD Checksum);

	virtual bool GotReadNVRAMInit(DWORD Checksum);
	virtual bool GotReadNVRAMBlock(DWORD Offset, BYTE *pData, int nBytes);

	virtual bool GotWriteNVRAMInit(void);
	virtual bool GotWriteNVRAMBlock(BYTE Flag);
	virtual bool GotWriteNVRAMComplete(BYTE Status);

	//virtual bool GotRequestReboot(BYTE Reason);

	virtual bool GotQueryRTC(char *szTime);
	virtual bool GotSetRTC(BYTE Flag);

	// IP Parameters
	virtual bool GotQueryMACAddress(BYTE MacAddress[8], int Length);
	virtual bool GotSetMACAddress(BYTE Flag);
	virtual bool GotQueryTCPListenPort(WORD Port);
	virtual bool GotSetTCPListenPort(BYTE Flag);
	virtual bool GotQueryEthernetStatus(BYTE Port, BYTE Status);

	// IPv4 Parameters
	virtual bool GotQueryIPv4Address(BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetIPv4Address(BYTE Flag); 
	virtual bool GotQueryIPv4Gateway(BYTE IPAddr[4]);
	virtual bool GotSetIPv4Gateway(BYTE Flag); 
	virtual bool GotQueryIPv4DNSServer(BYTE IPAddr[4]);
	virtual bool GotSetIPv4DNSServer(BYTE Flag); 

	// IPv6 Parameters
	virtual bool GotQueryIPv6Address(BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetIPv6Address(BYTE Flag); 
	virtual bool GotQueryIPv6Gateway(BYTE IPAddr[16]);
	virtual bool GotSetIPv6Gateway(BYTE Flag); 
	virtual bool GotQueryIPv6DNSServer(BYTE IPAddr[16]);
	virtual bool GotSetIPv6DNSServer(BYTE Flag); 

	virtual bool GotQueryOperationMode(BYTE Flag);
	virtual bool GotSetOperationMode(BYTE Flag);

	virtual bool GotQueryDiagLevel(BYTE Level);
	virtual bool GotSetDiagLevel(BYTE Flag);

	virtual bool GotQueryRunningServices(BYTE Services);
	virtual bool GotSetRunningServices(BYTE Flag);

	virtual bool GotQueryDChannelStatus(BYTE Channel, BYTE Status);
	virtual bool GotSetDChannelStatus(BYTE Channel, BYTE Flag);

	virtual bool GotQueryBChannelStatus(BYTE Channel, BYTE Status);
	virtual bool GotSetBChannelStatus(BYTE Channel, BYTE Flag);

	virtual bool GotSetLCDMessage(BYTE Flag);

	virtual bool GotQueryLineStatus(BYTE Enabled);
	virtual bool GotSetLineStatus(BYTE Flag);

	// SD Card Functions
	virtual bool GotCopyFileToSDCard(BYTE Flag);
	virtual bool GotCopyFileToSDCardLen(BYTE Flag);
	virtual bool GotCopyFileToSDCardBlock(BYTE Flag);
	virtual bool GotCopyFileToSDCardComplete(BYTE Flag);

	virtual bool GotCopyFileFromSDCard(BYTE Flag, QWORD Length);
	virtual bool GotCopyFileFromSDCardBlock(QWORD Offset, BYTE Data[512]);

	virtual bool GotDeleteFileFromSDCard(BYTE Flag);
	virtual bool GotIsSDCardInserted(BYTE Flag);
	virtual bool GotQuerySDCardFreeSpace(QWORD FreeSpace);

	virtual bool GotBChannelData(BYTE Channel, WORD Length, BYTE *pData, int Extended);
	virtual bool GotDChannelData(BYTE Channel, WORD Length, BYTE *pData, int Extended);
	virtual bool GotDChannelEvent(BYTE Channel, BYTE Event, char *szInfo);
	virtual bool GotDebugData(BYTE Channel, WORD Length, BYTE *pData);

	virtual bool GotQueryChannels(BYTE nChannels);

	virtual bool GotSetXTREncryption(BYTE Flag);
	virtual bool GotSetSSLEncryption(BYTE Flag);
	virtual bool GotQueryAllowedHosts(char *szHostname);
	virtual bool GotSetAllowedHosts(BYTE Flag);

	// SMTP
	virtual bool GotQuerySMTPServer(WORD ServerPort, char *szServerName);
	virtual bool GotSetSMTPServer(BYTE Flag);
	virtual bool GotQuerySMTPLoginName(char *szLoginName);
	virtual bool GotSetSMTPLoginName(BYTE Flag);
	virtual bool GotQuerySMTPLoginPassword(char *szPassword);
	virtual bool GotSetSMTPLoginPassword(BYTE Flag);
	virtual bool GotQuerySMTPAddress(char *szAddress);
	virtual bool GotSetSMTPAddress(BYTE Flag);


	// SNTP
	virtual bool GotQuerySNTPHostname(char *szHostname);
	virtual bool GotSetSNTPHostname(BYTE Flag);
	virtual bool GotQuerySNTPPollInterval(WORD Interval);
	virtual bool GotSetSNTPPollInterval(BYTE Flag);

	// IPTAP Specific Parameters
	virtual bool GotQueryMACAddressFilter(BYTE Port, BYTE MacAddress[8], int Length);
	virtual bool GotSetMACAddressFilter(BYTE Port, BYTE Flag);
	virtual bool GotQuerySIPPortFilter(BYTE Port, WORD SIPPort);
	virtual bool GotSetSIPPortFilter(BYTE Port, BYTE Flag);
	virtual bool GotQuerySIPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetSIPIPv4AddressFilter(BYTE Port, BYTE Flag); 
	virtual bool GotQuerySIPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetSIPIPv6AddressFilter(BYTE Port, BYTE Flag); 
	virtual bool GotQueryVLANFilter(BYTE Port, WORD VLAN);
	virtual bool GotSetVLANFilter(BYTE Port, BYTE Flag);
	virtual bool GotQuerySIPURIFilter(BYTE Port, char *szSIPURI);
	virtual bool GotSetSIPURIFilter(BYTE Port, BYTE Flag);
	virtual bool GotQueryRTPPortFilter(BYTE Port, WORD RTPPort);
	virtual bool GotSetRTPPortFilter(BYTE Port, BYTE Flag);
	virtual bool GotQueryRTCPPortFilter(BYTE Port, WORD RTCPPort);
	virtual bool GotSetRTCPPortFilter(BYTE Port, BYTE Flag);
	virtual bool GotQueryRTPIPv4AddressFilter(BYTE Port, BYTE IPAddr[5]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetRTPIPv4AddressFilter(BYTE Port, BYTE Flag); 
	virtual bool GotQueryRTPIPv6AddressFilter(BYTE Port, BYTE IPAddr[17]); // Final byte is routing prefix (number of bits in netmask)
	virtual bool GotSetRTPIPv6AddressFilter(BYTE Port, BYTE Flag); 
	
	bool EncodeMessage(int MessageType, int Channel, int Dir, BYTE *pData, int Length);

	BYTE GetRebootReason() { return m_RebootReason; }
	char *GetFirmwareVersion(void);
	char *GetSerialNo(void) { return m_szSerialNo;  }
	int GetNoChannels(void) { return m_nChannels; }
	void Enable(void) { m_bEnabled = true; }
	void Disable(void) { m_bEnabled = false; }

private:
	bool bFirstPacket;
	clock_t InitialPacket, ThisPacket;
	int LastBFlag;
	int LastDFlag;
	int BPos, DPos;
	BYTE BData[1600];
	BYTE DData[1600];
	BYTE m_RebootReason;
	char m_szFirmwareVersion[6];
	char m_szSerialNo[11];
	int m_nChannels;
	bool m_bEnabled;
};


#endif