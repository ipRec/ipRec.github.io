
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Digi04MkIICommsEngineHostUSB.h"

Digi04MkIICommsEngineHostUSB::Digi04MkIICommsEngineHostUSB(struct usb_device *pDev)
{
#ifdef DIAG
	fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Found Device: %s\n", pDev->filename);
#endif

	m_IntReadCont= -1;
	m_ReadCont= -1;
	m_WriteCont= -1;
	m_hStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL); // Unsignalled, manual reset
				
	int res=0;
	m_szFilename = pDev->filename;
	m_pDev = usb_open(pDev);
	if (m_pDev != NULL)
	{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Device Opened\n");
#endif
		
		if ((res = usb_set_configuration(m_pDev, CONFIGURATION)) < 0)
		{
#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error setting config #%d: %d, %s\n", CONFIG, res, usb_strerror());
#endif
			usb_close(m_pDev);
			m_pDev = NULL;
		} else
		{
			if ((res = usb_claim_interface(m_pDev, INTFACE)) < 0)
			{
#ifdef DIAG
				if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error claiming interface #%d: %d, %s\n", INTFACE, res, usb_strerror());
#endif
				usb_close(m_pDev);
				m_pDev = NULL;
			} else
			{
				for(int i=0; i<NBUFFERS; i++)
				{
					res = usb_interrupt_setup_async(m_pDev, &(m_IntReadContext[i]), INT_EP_IN);
					if (res < 0)
					{
	#ifdef DIAG
						if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error setting up interrupt pipe[%d] #%d: %d, %s\n", i, INT_EP_IN, res, usb_strerror());	
	#endif
					}
					
					res = usb_bulk_setup_async(m_pDev, &(m_ReadContext[i]), BULK_EP_IN);
					if (res < 0)
					{
	#ifdef DIAG
						if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error setting up bulk pipe[%d] #%d: %d, %s\n", i, BULK_EP_IN, res, usb_strerror());	
	#endif
					}
				}
				res = usb_bulk_setup_async(m_pDev, &(m_WriteContext[0]), BULK_EP_OUT);
				if (res < 0)
				{
#ifdef DIAG
					if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error setting up bulk pipe[%d] #%d: %d, %s\n", 0, BULK_EP_OUT, res, usb_strerror());	
#endif
				}
				res = usb_bulk_setup_async(m_pDev, &(m_WriteContext[1]), BULK_EP_OUT);
				if (res < 0)
				{
#ifdef DIAG
					if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error setting up bulk pipe[%d] #%d: %d, %s\n", 1, BULK_EP_OUT, res, usb_strerror());	
#endif
				}
				
				// submit initial reads so result is ready when we want it
				m_ReadCont=0;
				m_IntReadCont=0;
				for (int i=0; i<(NBUFFERS-1); i++)
				{
					int nbytes = usb_submit_async(m_ReadContext[i], (char *)(m_ReadBuffer[i]), BUFSIZE);
					if (nbytes < 0)
					{
	#ifdef DIAG
						if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error reading bulk pipe[%d] #%d: %d, %s\n", i, BULK_EP_IN, nbytes, usb_strerror());	
	#endif
					}

					nbytes = usb_submit_async(m_IntReadContext[i], (char *)(m_IntReadBuffer[i]), BUFSIZE);
					if (nbytes < 0)
					{
	#ifdef DIAG
						if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Error reading interrupt pipe[%d] #%d: %d, %s\n", i, INT_EP_IN, nbytes, usb_strerror());	
	#endif
					}
				}
			}
		}
	} else
	{
#ifdef DIAG
		if (hDiag != NULL) fprintf(hDiag, "Digi04MkIICommsEngineHostUSB: Failed to open device\n");
#endif
	}
}

Digi04MkIICommsEngineHostUSB::~Digi04MkIICommsEngineHostUSB()
{
#ifdef DIAG
	if (hDiag != NULL)
	{
		fprintf(hDiag, "~Digi04MkIICommsEngineHostUSB\n");
		fflush(hDiag);
	}
#endif
	if (m_pDev != NULL)
	{
		if (m_WriteCont >= 0)
		{
			usb_cancel_async(m_WriteContext[m_WriteCont]); // returns -5 on device disconnect (or suspend)
		}
		for(int i=0; i<(NBUFFERS-1); i++)
		{
			if (m_ReadCont >=0)
			{
				usb_cancel_async(m_ReadContext[m_ReadCont++]);
				if (m_ReadCont == NBUFFERS) m_ReadCont = 0;
			}
			if (m_IntReadCont >=0)
			{
				usb_cancel_async(m_IntReadContext[m_IntReadCont++]); // returns -116 on timeout
				if (m_IntReadCont == NBUFFERS) m_IntReadCont = 0;
			}
		}
		usb_free_async(&(m_WriteContext[0]));
		usb_free_async(&(m_WriteContext[1]));
		for(int i=0; i<NBUFFERS; i++)
		{			
			usb_free_async(&(m_ReadContext[i]));
			usb_free_async(&(m_IntReadContext[i]));
		}

		int res=0;
		if ((res = usb_release_interface(m_pDev, INTFACE)) < 0)
		{
#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "~Digi04MkIICommsEngineHostUSB: error releasing interface #%d: %d, %s\n", INTFACE, res, usb_strerror());
#endif
		}
		usb_close(m_pDev); // don't close device on suspend, only on unplug 
		m_pDev = NULL;
	}
	CloseHandle(m_hStopEvent);
}

void Digi04MkIICommsEngineHostUSB::ExitThread(void)
{
	if (SetEvent(m_hStopEvent)==0)
	{
		if (SetEvent(m_hStopEvent)==0)
		{
#ifdef DIAG
			DWORD Err = GetLastError();
			if (hDiag != NULL) { fprintf(hDiag, "Digi04MkIICommsEngineHostUSB::ExitThread SetEvent Failed Err=0x%04x\n", Err); fflush(hDiag); }
#endif
		}
	}
}

bool Digi04MkIICommsEngineHostUSB::HasExited(void)
{
	DWORD dwWaitResult = WaitForSingleObject(m_hStopEvent, 0);  // return immediately
	bool bRes = (dwWaitResult == WAIT_OBJECT_0);
	if (dwWaitResult == WAIT_FAILED)
	{	
#ifdef DIAG
		dwWaitResult = GetLastError();
		if (hDiag != NULL) { fprintf(hDiag, "Digi04MkIICommsEngineHostUSB::HasExited Wait Failed Err=0x%04x\n", dwWaitResult);  fflush(hDiag); }
#endif
	}
	return bRes;
}

extern volatile int bSuspending;

bool Digi04MkIICommsEngineHostUSB::SendMessage(BYTE *pData, DWORD Length)
{
	if (m_pDev != NULL)
	{
#ifdef DIAG
		//if (hDiag != NULL) fprintf(hDiag, "SendMessage: %02x, Length=%d\n", pData[0], Length);
#endif
		int nbytes = 0;
		if (m_WriteCont >= 0)
		{
			nbytes = usb_reap_async(m_WriteContext[m_WriteCont], TIMEOUT); // returns -116 on timeout
			if (nbytes < 0)
			{
#ifdef DIAG
				if (hDiag != NULL)
				{
					if (nbytes != ERRTIMEOUT) fprintf(hDiag, "SendMessage: Error reaping write bulk pipe #%d: %d, %s\n", BULK_EP_OUT, nbytes, usb_strerror());
				}
#endif
			}
		}
		m_WriteCont++;
		if (m_WriteCont == 2) m_WriteCont = 0; // alternate contexts
		memcpy(m_WriteBuffer[m_WriteCont], pData, Length);
		int res = usb_submit_async(m_WriteContext[m_WriteCont], (char *)(m_WriteBuffer[m_WriteCont]), Length);
		if (res < 0)
		{
#ifdef DIAG
			if (hDiag != NULL)
			{
				fprintf(hDiag, "SendMessage: Error writing bulk pipe #%d: %d, %s\n", BULK_EP_OUT, res, usb_strerror());
				fflush(hDiag);
			}
#endif
			if ((res == ERRNOTFOUND) && (!bSuspending)) // device removal
			{
#ifdef DIAG
				if (hDiag != NULL) fprintf(hDiag, "SendMessage: Terminating Comms, device unplugged\n");
#endif
				printf("SendMessage: Terminating Comms, device unplugged\n");
				ExitThread();
			}
			return false;
		}
#ifdef DIAG
		if (hDiag != NULL)
		{
			fflush(hDiag);
		}
#endif
		return true;
	} else
	{
		return false;
	}
}


bool Digi04MkIICommsEngineHostUSB::ReceiveMessage(BYTE *pData, DWORD &Length)
{
	if (m_pDev != NULL)
	{
		int nbytes = 0;
		if (m_ReadCont >=0) nbytes = usb_reap_async_nocancel(m_ReadContext[m_ReadCont], TIMEOUT); // returns -116 on timeout
		if (nbytes < 0)
		{
#ifdef DIAG
			if (hDiag != NULL)
			{
				if (nbytes != ERRTIMEOUT) fprintf(hDiag, "ReceiveMessage: Error reaping read bulk pipe[%d] #%d: %d, %s\n", m_ReadCont, BULK_EP_IN, nbytes, usb_strerror());	
			}
#endif
			if (nbytes == ERRTIMEOUT)
			{
				// request isn't cancelled on timeout, so don't resubmit
				return false;
			}
		} else
		{
			if (nbytes > 0) memcpy(pData, m_ReadBuffer[m_ReadCont], (nbytes<=Length)?nbytes:Length);
#ifdef DIAG
			if ((nbytes > Length) && (hDiag != NULL)) fprintf(hDiag, "ReceiveMessage: Error reaping read bulk pipe[%d] #%d: nbytes %d > Length %d\n", m_ReadCont, BULK_EP_IN, nbytes, Length);	
#endif		
		}
		m_ReadCont++;
		if (m_ReadCont == NBUFFERS) m_ReadCont = 0; // alternate contexts
		// queue next read ready for next time
		int NextReadContext = (m_ReadCont + NBUFFERS-2) % NBUFFERS;
		int res = usb_submit_async(m_ReadContext[NextReadContext], (char *)(m_ReadBuffer[NextReadContext]), BUFSIZE);
		if (res < 0)
		{
#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: Error reading bulk pipe[%d] #%d: %d, %s\n", NextReadContext, BULK_EP_IN, res, usb_strerror());	
#endif
		}
#ifdef DIAG
		if (hDiag != NULL) fflush(hDiag);
#endif
		if (nbytes <= 0)
		{
			if ((res == ERRNOTFOUND) && (!bSuspending)) // device removal
			{
#ifdef DIAG
				if (hDiag != NULL) fprintf(hDiag, "ReceiveMessage: Terminating Comms, device unplugged\n");
#endif
				printf("ReceiveMessage: Terminating Comms, device unplugged\n");
				ExitThread();
			}
			return false;
		}
#ifdef DIAG
		if (hDiag != NULL)
		{
			//fprintf(hDiag, "ReceiveMessage: %02x, Length=%d\n", pData[0], nbytes);
			fflush(hDiag);
		}
#endif
		Length = nbytes;
		return true; 
	} else
	{
		return false;
	}
}

bool Digi04MkIICommsEngineHostUSB::ReceiveIntMessage(BYTE *pData, DWORD &Length)
{
	if (m_pDev != NULL)
	{
		int nbytes = 0;
		if (m_IntReadCont >=0) nbytes = usb_reap_async_nocancel(m_IntReadContext[m_IntReadCont], TIMEOUT); // returns -116 on timeout
		if (nbytes < 0)
		{
#ifdef DIAG
			if (hDiag != NULL)
			{
				if (nbytes != ERRTIMEOUT) fprintf(hDiag, "ReceiveIntMessage: Error reaping read interrupt pipe[%d] #%d: %d, %s\n", m_IntReadCont, INT_EP_IN, nbytes, usb_strerror());	
			}
#endif
			if (nbytes == ERRTIMEOUT)
			{
				// request isn't cancelled on timeout, so don't resubmit
				return false;
			}
		} else
		{
			if (nbytes > 0) memcpy(pData, m_IntReadBuffer[m_IntReadCont], (nbytes<=Length)?nbytes:Length);
#ifdef DIAG
			if ((nbytes > Length) && (hDiag != NULL)) fprintf(hDiag, "ReceiveIntMessage: Error reaping read interrupt pipe[%d] #%d: nbytes %d > Length %d\n", m_IntReadCont, INT_EP_IN, nbytes, Length);	
#endif		
		}
		m_IntReadCont++;	
		if (m_IntReadCont == NBUFFERS) m_IntReadCont = 0; // alternate contexts
		int NextReadContext = (m_IntReadCont + NBUFFERS-2) % NBUFFERS;
		// queue next read ready for next time
		int res = usb_submit_async(m_IntReadContext[NextReadContext], (char *)(m_IntReadBuffer[NextReadContext]), BUFSIZE);
		if (res < 0)
		{
#ifdef DIAG
			if (hDiag != NULL) fprintf(hDiag, "ReceiveIntMessage: Error reading interrupt pipe[%d] #%d: %d, %s\n", NextReadContext, INT_EP_IN, res, usb_strerror());	
#endif
		}
#ifdef DIAG
		if (hDiag != NULL) fflush(hDiag);
#endif
		if (nbytes <= 0)
		{
			if ((res == ERRNOTFOUND) && (!bSuspending)) // device removal
			{
#ifdef DIAG
				if (hDiag != NULL) fprintf(hDiag, "ReceiveIntMessage: Terminating Comms, device unplugged\n");
#endif
				printf("ReceiveIntMessage: Terminating Comms, device unplugged\n");
				ExitThread();
			}
			return false;
		}
#ifdef DIAG
		if (hDiag != NULL)
		{
			//fprintf(hDiag, "ReceiveIntMessage: %02x, Length=%d\n", pData[0], nbytes);
			fflush(hDiag);
		}
#endif
		Length = nbytes;
		return true; 
	} else
	{
		return false;
	}
}

